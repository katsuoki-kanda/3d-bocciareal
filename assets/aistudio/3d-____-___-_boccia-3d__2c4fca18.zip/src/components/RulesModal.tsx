/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Target, ShieldCheck, Users, Keyboard } from 'lucide-react';
import { sound } from '../game/audio';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-6 text-slate-100">
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-full transition-colors cursor-pointer"
          aria-label="閉じる"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6 border-b border-slate-800 pb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-wide">ボッチャの公式競技ルール＆操作方法</h2>
            <p className="text-xs text-slate-400">パラリンピック正式種目 • 公式競技規格・投球ボックス・フルマッチ準拠</p>
          </div>
        </div>

        {/* Content sections */}
        <div className="space-y-5 text-sm text-slate-300 leading-relaxed">
          {/* Official Match Formats & Boxes */}
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-2 font-bold text-white mb-2">
              <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 flex items-center justify-center text-xs">1</span>
              <span>公式フルマッチ形式・投球ボックス配置（全6モード）</span>
            </div>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <strong className="text-white block mb-0.5">■ 1人プレイ / 1人対戦（個人戦 4エンド）</strong>
                <span>赤チーム：ボックス3（6球） / 青チーム：ボックス4（6球）</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <strong className="text-white block mb-0.5">■ ペアプレイ / ペア対戦（ペア戦 4エンド）</strong>
                <span>赤チーム：ボックス2（3球）, ボックス4（3球） / 青チーム：ボックス3（3球）, ボックス5（3球）</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <strong className="text-white block mb-0.5">■ チームプレイ / チーム対戦（チーム戦 6エンド）</strong>
                <span>赤チーム：ボックス1, 3, 5（各2球） / 青チーム：ボックス2, 4, 6（各2球）</span>
              </div>
            </div>
          </div>

          {/* Box Controls & Chord */}
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-2 font-bold text-white mb-2">
              <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center text-xs">2</span>
              <span>スローイングボックスの移動と同時押し決定</span>
            </div>
            <p className="text-xs mb-2">
              投球する場面となった際、投球するボックスを選択します：
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <strong className="text-amber-300 block mb-0.5">← と → キーでボックス移動</strong>
                <span>左右方向へ投球ボックスを切り替えます。</span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                <strong className="text-emerald-300 block mb-0.5">← と → 同時押しでボックス決定 / 解除</strong>
                <span>2つのキーの同時押しでボックスを決定（ロック）。決定済みの状態で再度同時押しすると選択解除されます。</span>
              </div>
            </div>
            <div className="mt-2 text-[11px] text-slate-400">
              ※ キーの同時押しタイミングの微小なズレ（85ms以内）による誤移動を防止する自動緩衝バッファを搭載しています。画面上のボタンでも操作可能です。
            </div>
          </div>

          {/* Turn Order Rule */}
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-2 font-bold text-white mb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center text-xs">3</span>
              <span>「遠い方が投げる」投球順ルール</span>
            </div>
            <p className="text-xs leading-relaxed">
              各エンドの第1投はジャックボール（白球）を投げ、続けて同チームがカラーボール1球目を投げます。次に相手チームが1球目を投げます。
              以後は<strong className="text-white">「ジャックボールから現在最も遠いチーム」</strong>が順番に投球します。相手より近づけるまで（または持ち球が無くなるまで）連続で投球します。
            </p>
          </div>

          {/* Scoring */}
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-2 font-bold text-white mb-2">
              <span className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center text-xs">4</span>
              <span>得点の計算方法（全12球終了時）</span>
            </div>
            <p className="text-xs leading-relaxed">
              両チームの全12球終了時、ジャックボールに最も近いボールを持つチームが勝利します。
              得点は<strong className="text-emerald-400">「相手チームの最も近いボールより内側にある自チームのボール数（1〜6点）」</strong>となります。
            </p>
          </div>

          {/* Key Bindings */}
          <div className="bg-blue-950/40 border border-blue-800/50 rounded-xl p-4">
            <h3 className="font-bold text-blue-300 text-xs uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Keyboard className="w-4 h-4" /> キーボード操作一覧
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
              <div>• <strong>← / → キー：</strong> ボックス移動（決定時は角度微調整）</div>
              <div>• <strong>← + → 同時押し：</strong> ボックス決定 / 選択解除</div>
              <div>• <strong>↑ / ↓ キー：</strong> 投球パワー調整（常時有効）</div>
              <div>• <strong>Enter / Space：</strong> 投球スロー</div>
              <div>• <strong>* キー：</strong> 投球操作盤の表示 / 非表示</div>
              <div>• <strong>/ キー：</strong> 視点の順次切り替え（投球・真上・全体・自由）</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
          >
            理解した（閉じる）
          </button>
        </div>
      </div>
    </div>
  );
};
