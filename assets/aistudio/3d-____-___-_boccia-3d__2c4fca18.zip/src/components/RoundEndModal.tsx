/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Trophy, ChevronRight, RotateCcw, Eye, FileText } from 'lucide-react';
import { RoundScore } from '../game/types';
import { sound } from '../game/audio';

interface RoundEndModalProps {
  isOpen: boolean;
  roundScore: RoundScore | null;
  currentEnd: number;
  totalEnds: number;
  totalRedScore: number;
  totalBlueScore: number;
  isMatchOver: boolean;
  onNextEnd: () => void;
  onRestartMatch: () => void;
  onInspectCourt: () => void;
}

export const RoundEndModal: React.FC<RoundEndModalProps> = ({
  isOpen,
  roundScore,
  currentEnd,
  totalEnds,
  totalRedScore,
  totalBlueScore,
  isMatchOver,
  onNextEnd,
  onRestartMatch,
  onInspectCourt
}) => {
  const [isInspecting, setIsInspecting] = useState(false);

  useEffect(() => {
    setIsInspecting(false);
  }, [currentEnd, isMatchOver]);

  if (!isOpen || !roundScore) return null;

  const isFinal = isMatchOver || currentEnd >= totalEnds;
  const matchWinner =
    totalRedScore > totalBlueScore
      ? 'red'
      : totalBlueScore > totalRedScore
      ? 'blue'
      : 'tie';

  // Opponent cutoff distance for scoring circle
  const winnerType = roundScore.winner;
  const opponentBall = roundScore.ballRankings.find((b) => b.type !== winnerType);
  const cutoffDist = opponentBall ? opponentBall.distance : 0;

  // If inspecting court, show non-intrusive bottom HUD bar
  if (isInspecting) {
    return (
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-wrap items-center justify-center gap-3 bg-slate-900/95 border border-slate-700/80 px-5 py-3 rounded-2xl shadow-2xl pointer-events-auto animate-fadeIn max-w-[92vw]">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50 inline-block" />
          <span className="text-xs font-bold text-white">
            ★ 得点圏内サークル表示中
            {cutoffDist > 0 && (
              <span className="text-emerald-400 font-mono ml-1.5">
                (半径: {cutoffDist.toFixed(2)}m 以内の球が得点)
              </span>
            )}
          </span>
        </div>
        <div className="h-5 w-px bg-slate-700 hidden sm:block" />
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playClick();
              setIsInspecting(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>スコアカードに戻る</span>
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setIsInspecting(false);
              if (isFinal) onRestartMatch();
              else onNextEnd();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
          >
            <span>{isFinal ? 'もう一度遊ぶ' : '次のエンドへ'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-6 text-slate-100 overflow-hidden">
        {/* Subtle decorative glow */}
        <div
          className={`absolute -top-24 -left-24 w-64 h-64 rounded-full blur-3xl opacity-20 pointer-events-none ${
            roundScore.winner === 'red'
              ? 'bg-red-500'
              : roundScore.winner === 'blue'
              ? 'bg-blue-500'
              : 'bg-amber-500'
          }`}
        />

        {/* Modal Header */}
        <div className="text-center mb-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 text-xs font-semibold text-slate-300 border border-slate-700 mb-2">
            <span>{isFinal ? '試合終了 (MATCH COMPLETE)' : `エンド ${currentEnd} / ${totalEnds} 終了`}</span>
          </div>

          {!isFinal ? (
            <div>
              <h2 className="text-2xl font-black text-white tracking-wide">
                {roundScore.winner === 'red' ? (
                  <span className="text-red-500">赤チームのエンド勝利！</span>
                ) : roundScore.winner === 'blue' ? (
                  <span className="text-blue-500">青チームのエンド勝利！</span>
                ) : (
                  <span className="text-slate-300">引き分け（0点）</span>
                )}
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                {roundScore.winner === 'tie'
                  ? '両チーム同点のため加点はありません'
                  : `ジャックボールに最も近づき、+${roundScore.points} 点を獲得！`}
              </p>
            </div>
          ) : (
            <div>
              <h2 className="text-3xl font-black text-white tracking-wide flex items-center justify-center gap-2">
                <Trophy className="w-8 h-8 text-amber-400 animate-bounce" />
                {matchWinner === 'red' ? (
                  <span className="text-red-500">赤チームの総合優勝！</span>
                ) : matchWinner === 'blue' ? (
                  <span className="text-blue-500">青チームの総合優勝！</span>
                ) : (
                  <span className="text-slate-200">総合引き分け！</span>
                )}
              </h2>
              <p className="text-sm text-slate-400 mt-1">全エンドが終了しました！素晴らしいゲームでした！</p>
            </div>
          )}
        </div>

        {/* Total Scoreboard Card */}
        <div className="grid grid-cols-2 gap-3 bg-slate-950/70 border border-slate-800 rounded-xl p-4 mb-5">
          {/* Red Team */}
          <div className="text-center border-r border-slate-800 pr-3">
            <div className="flex items-center justify-center gap-2 mb-1">
              <span className="w-3 h-3 rounded-full bg-red-500 inline-block"></span>
              <span className="text-xs font-bold text-slate-400 tracking-wider">RED TEAM</span>
            </div>
            <div className="text-4xl font-black text-red-500 tabular-nums">
              {totalRedScore}
              {!isFinal && roundScore.winner === 'red' && (
                <span className="text-xs ml-1 text-red-400 font-normal">(+{roundScore.points})</span>
              )}
            </div>
          </div>

          {/* Blue Team */}
          <div className="text-center pl-3">
            <div className="flex items-center justify-center gap-2 mb-1">
              <span className="w-3 h-3 rounded-full bg-blue-500 inline-block"></span>
              <span className="text-xs font-bold text-slate-400 tracking-wider">BLUE TEAM</span>
            </div>
            <div className="text-4xl font-black text-blue-500 tabular-nums">
              {totalBlueScore}
              {!isFinal && roundScore.winner === 'blue' && (
                <span className="text-xs ml-1 text-blue-400 font-normal">(+{roundScore.points})</span>
              )}
            </div>
          </div>
        </div>

        {/* Referee Distance Ranking List */}
        <div className="mb-5">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2 px-1">
            <span className="font-semibold text-slate-300">審判判定（ジャックからの距離順）</span>
            <span className="text-slate-500">上位ボール抜粋</span>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {roundScore.ballRankings.slice(0, 5).map((ball, idx) => (
              <div
                key={ball.ballId}
                className={`flex items-center justify-between px-3 py-2 rounded-lg text-xs border ${
                  ball.scoresPoint
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-white font-medium'
                    : ball.type === 'red'
                    ? 'bg-slate-800/40 border-slate-700/40 text-slate-300'
                    : 'bg-slate-800/40 border-slate-700/40 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      idx === 0
                        ? 'bg-amber-500 text-slate-950 font-black'
                        : 'bg-slate-700 text-slate-300'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        ball.type === 'red' ? 'bg-red-500' : 'bg-blue-500'
                      }`}
                    />
                    <span>{ball.type === 'red' ? '赤球' : '青球'}</span>
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono text-slate-200 tabular-nums">
                    {ball.distance.toFixed(3)} m
                  </span>
                  {ball.scoresPoint ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
                      ★ 1点獲得
                    </span>
                  ) : idx === 0 || roundScore.ballRankings[idx - 1]?.scoresPoint ? (
                    <span className="text-[10px] text-slate-400">（得点圏境界）</span>
                  ) : (
                    <span className="text-[10px] text-slate-500">-</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800">
          <button
            onClick={() => {
              sound.playClick();
              setIsInspecting(true);
              onInspectCourt();
            }}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer border border-slate-700"
          >
            <Eye className="w-4 h-4 text-emerald-400" />
            <span>コートを確認（得点圏サークル）</span>
          </button>

          {!isFinal ? (
            <button
              onClick={() => {
                sound.playClick();
                onNextEnd();
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-500/25 transition-all cursor-pointer"
            >
              <span>次のエンドへ</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => {
                sound.playClick();
                onRestartMatch();
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm rounded-xl shadow-lg shadow-amber-500/25 transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>もう一度遊ぶ</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
