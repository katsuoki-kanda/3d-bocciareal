/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, BookOpen, Users, Cpu, Trophy, Sparkles, Volume2, VolumeX, Shield, User } from 'lucide-react';
import { GameMode, AIDifficulty } from '../game/types';
import { sound } from '../game/audio';

interface TitleScreenProps {
  onStartGame: (mode: GameMode, difficulty: AIDifficulty, totalEnds: number) => void;
  onOpenRules: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  onOpenRules,
  isMuted,
  onToggleMute
}) => {
  const [mode, setMode] = useState<GameMode>('solo_ai');
  const [difficulty, setDifficulty] = useState<AIDifficulty>('medium');
  const [matchType, setMatchType] = useState<'official' | 'quick'>('official');

  const isTeam = mode === 'team_ai' || mode === 'team_pvp';
  const officialEnds = isTeam ? 6 : 4;
  const totalEnds = matchType === 'official' ? officialEnds : 1;

  const isAiMode = mode === 'solo_ai' || mode === 'pairs_ai' || mode === 'team_ai';

  const handleSelectMode = (newMode: GameMode) => {
    sound.playClick();
    setMode(newMode);
  };

  const handleStart = () => {
    sound.playThrow(0.8);
    onStartGame(mode, difficulty, totalEnds);
  };

  const AI_MODES: { id: GameMode; title: string; subtitle: string; ends: number; icon: typeof User }[] = [
    { id: 'solo_ai', title: '1人プレイ（vs AI）', subtitle: '4エンド • 赤(B3) vs 青(B4) 各6球', ends: 4, icon: User },
    { id: 'pairs_ai', title: 'ペアプレイ（vs AI）', subtitle: '4エンド • 赤(B2,4) vs 青(B3,5) 各3球', ends: 4, icon: Users },
    { id: 'team_ai', title: 'チームプレイ（vs AI）', subtitle: '6エンド • 赤(B1,3,5) vs 青(B2,4,6) 各2球', ends: 6, icon: Shield }
  ];

  const PVP_MODES: { id: GameMode; title: string; subtitle: string; ends: number; icon: typeof User }[] = [
    { id: 'solo_pvp', title: '1人対戦（赤 vs 青）', subtitle: '4エンド • 赤(B3) vs 青(B4) 各6球', ends: 4, icon: User },
    { id: 'pairs_pvp', title: 'ペア対戦（赤 vs 青）', subtitle: '4エンド • 赤(B2,4) vs 青(B3,5) 各3球', ends: 4, icon: Users },
    { id: 'team_pvp', title: 'チーム対戦（赤 vs 青）', subtitle: '6エンド • 赤(B1,3,5) vs 青(B2,4,6) 各2球', ends: 6, icon: Shield }
  ];

  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-between p-4 sm:p-8 pointer-events-auto bg-gradient-to-t from-slate-950 via-slate-950/85 to-slate-950/40 overflow-y-auto">
      {/* Top Header / Audio Toggle */}
      <div className="flex items-center justify-between shrink-0">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/60 text-xs font-semibold text-slate-300">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Three.js &amp; Cannon.js 本格3Dボッチャ物理演算</span>
        </div>

        <button
          onClick={onToggleMute}
          className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer"
          title={isMuted ? 'ミュート解除' : 'ミュート'}
        >
          {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
        </button>
      </div>

      {/* Center Hero Lockup */}
      <div className="max-w-2xl my-auto text-left mx-auto w-full py-4">
        {/* Decorative Badge */}
        <div className="flex items-center gap-2 text-xs font-bold tracking-widest text-blue-400 uppercase mb-2">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block shadow-sm shadow-red-500/50" />
          <span className="w-2.5 h-2.5 rounded-full bg-white inline-block shadow-sm shadow-white/50" />
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block shadow-sm shadow-blue-500/50" />
          <span>Official Boccia Tournament Simulation</span>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-none mb-2">
          BOCCIA <span className="bg-gradient-to-r from-red-500 via-amber-300 to-blue-500 bg-clip-text text-transparent">3D</span>
        </h1>
        <p className="text-base font-bold text-slate-200 mb-1">公式競技ルール対応 3Dボッチャ</p>
        <p className="text-xs text-slate-400 leading-relaxed mb-4">
          公式フルマッチ形式（チーム戦6エンド・他4エンド）対応。← → キーで投球ボックスを選択し、2キー同時押しでボックス決定！
        </p>

        {/* Configuration Panel */}
        <div className="space-y-4 bg-slate-900/95 border border-slate-800 p-4 sm:p-5 rounded-2xl shadow-2xl backdrop-blur-md">
          {/* 6 Game Modes */}
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>ゲームモード（全6種）</span>
              <span className="text-[11px] text-amber-400 font-semibold">公式ボックス配分・球数完全準拠</span>
            </label>

            {/* Mode selection columns: vs AI & 2-Player Local */}
            <div className="space-y-3">
              {/* vs AI Section */}
              <div>
                <div className="text-[11px] font-bold text-blue-400 flex items-center gap-1.5 mb-1.5">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>AI対戦モード (vs PC)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {AI_MODES.map((m) => {
                    const Icon = m.icon;
                    const isSelected = mode === m.id;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => handleSelectMode(m.id)}
                        className={`text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-blue-600/30 border-blue-500 text-white shadow-md shadow-blue-500/20 ring-1 ring-blue-500/50'
                            : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold text-xs mb-0.5">
                          <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-blue-400' : 'text-slate-400'}`} />
                          <span className={isSelected ? 'text-white' : 'text-slate-300'}>{m.title}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 leading-tight">{m.subtitle}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* PvP Section */}
              <div>
                <div className="text-[11px] font-bold text-red-400 flex items-center gap-1.5 mb-1.5">
                  <Users className="w-3.5 h-3.5" />
                  <span>対戦モード (赤 vs 青)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {PVP_MODES.map((m) => {
                    const Icon = m.icon;
                    const isSelected = mode === m.id;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => handleSelectMode(m.id)}
                        className={`text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-red-600/30 border-red-500 text-white shadow-md shadow-red-500/20 ring-1 ring-red-500/50'
                            : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 font-bold text-xs mb-0.5">
                          <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-red-400' : 'text-slate-400'}`} />
                          <span className={isSelected ? 'text-white' : 'text-slate-300'}>{m.title}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 leading-tight">{m.subtitle}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* AI Difficulty (shown when playing vs AI) */}
          {isAiMode && (
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                AI 強さレベル
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['easy', 'medium', 'hard'] as AIDifficulty[]).map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setDifficulty(d);
                    }}
                    className={`py-2 px-2 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                      difficulty === d
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm shadow-amber-500/20'
                        : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {d === 'easy' ? '初級 (ビギナー)' : d === 'medium' ? '中級 (標準)' : '上級 (マスター)'}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Match Ends (Official full match vs Quick match) */}
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              試合形式（エンド数）
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setMatchType('official');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                  matchType === 'official'
                    ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300 shadow-sm shadow-emerald-500/20 ring-1 ring-emerald-500/40'
                    : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:text-slate-200'
                }`}
              >
                公式フルマッチ（{officialEnds}エンド）
              </button>

              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setMatchType('quick');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-bold border text-center transition-all cursor-pointer ${
                  matchType === 'quick'
                    ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300 shadow-sm shadow-emerald-500/20'
                    : 'bg-slate-800/50 border-slate-700/50 text-slate-400 hover:text-slate-200'
                }`}
              >
                1エンド（クイック戦）
              </button>
            </div>
          </div>

          {/* Start CTA and Rules buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={handleStart}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-extrabold text-sm sm:text-base shadow-xl shadow-blue-600/30 active:scale-98 transition-all cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>ゲームスタート ({totalEnds}エンド)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                onOpenRules();
              }}
              className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-slate-400" />
              <span>公式ルール</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Hint */}
      <div className="text-center text-xs text-slate-500 shrink-0 py-1">
        <span>【操作】← → でボックス移動 • ←+→ 同時押しでボックス決定/解除 • ↑↓ でパワー • Enter/Space で投球 • * で操作盤開閉 • / でカメラ切替</span>
      </div>
    </div>
  );
};
