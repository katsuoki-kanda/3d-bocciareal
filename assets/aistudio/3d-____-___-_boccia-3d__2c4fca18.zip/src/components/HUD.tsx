/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Compass,
  Zap,
  Target,
  ChevronDown,
  ChevronUp,
  Volume2,
  VolumeX,
  RotateCcw,
  BookOpen,
  Ruler,
  ArrowLeft,
  ArrowRight,
  Lock,
  Unlock,
  CheckCircle2
} from 'lucide-react';
import { GameSnapshot } from '../game/BocciaGame';
import { CameraPreset, GameMode, MAX_AIM_ANGLE } from '../game/types';
import { sound } from '../game/audio';

interface HUDProps {
  snapshot: GameSnapshot;
  onSetAngle: (angle: number) => void;
  onSetPower: (power: number) => void;
  onSetSpin: (spin: number) => void;
  onSetLoft: (loft: number) => void;
  onSetStartX: (x: number) => void;
  onThrow: () => void;
  onMoveBox: (direction: 'left' | 'right') => void;
  onToggleBoxSelection: () => void;
  onSelectBoxDirectly: (boxNumber: number) => void;
  onSetCameraPreset: (preset: CameraPreset) => void;
  onToggleMeasurement: (show: boolean) => void;
  onOpenRules: () => void;
  onResetMatch: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  snapshot,
  onSetAngle,
  onSetPower,
  onSetSpin,
  onSetLoft,
  onSetStartX,
  onThrow,
  onMoveBox,
  onToggleBoxSelection,
  onSelectBoxDirectly,
  onSetCameraPreset,
  onToggleMeasurement,
  onOpenRules,
  onResetMatch,
  isMuted,
  onToggleMute
}) => {
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [showMeasure, setShowMeasure] = useState(false);

  // Keep latest snapshot in a ref to avoid recreating keyboard listeners on every angle/power step
  const snapshotRef = useRef(snapshot);
  snapshotRef.current = snapshot;

  // Power charging meter state for hold-to-throw
  const [isCharging, setIsCharging] = useState(false);
  const chargePowerRef = useRef(0.2);
  const chargeDirRef = useRef(1);
  const chargeAnimRef = useRef<number | null>(null);

  // Simultaneous chord tracking for ArrowLeft + ArrowRight
  const keysDownRef = useRef<Set<string>>(new Set());
  const chordTimerRef = useRef<number | null>(null);
  const chordFiredRef = useRef<boolean>(false);

  // Toggle measurement
  const handleToggleMeasure = () => {
    sound.playClick();
    const next = !showMeasure;
    setShowMeasure(next);
    onToggleMeasurement(next);
  };

  // Hold-to-charge detection: regular clicks throw immediately at the exact set power (no unintended variance)
  const chargeTimeoutRef = useRef<number | null>(null);
  const didStartChargingRef = useRef(false);

  // Charging animation loop
  const startCharging = () => {
    if (snapshot.phase !== 'aiming' || snapshot.isAiTurn) return;
    sound.playClick();
    setIsCharging(true);
    chargePowerRef.current = snapshot.aimParams.power;
    chargeDirRef.current = 1;

    const animateCharge = () => {
      chargePowerRef.current += chargeDirRef.current * 0.022;
      if (chargePowerRef.current >= 1.0) {
        chargePowerRef.current = 1.0;
        chargeDirRef.current = -1;
      } else if (chargePowerRef.current <= 0.15) {
        chargePowerRef.current = 0.15;
        chargeDirRef.current = 1;
      }
      onSetPower(chargePowerRef.current);
      chargeAnimRef.current = requestAnimationFrame(animateCharge);
    };

    chargeAnimRef.current = requestAnimationFrame(animateCharge);
  };

  const handlePointerDown = () => {
    if (snapshot.phase !== 'aiming' || snapshot.isAiTurn) return;
    didStartChargingRef.current = false;
    // Delay charging start: normal clicks under 220ms execute exact throw without mutating power
    chargeTimeoutRef.current = window.setTimeout(() => {
      didStartChargingRef.current = true;
      startCharging();
    }, 220);
  };

  const handlePointerUp = () => {
    if (chargeTimeoutRef.current !== null) {
      clearTimeout(chargeTimeoutRef.current);
      chargeTimeoutRef.current = null;
    }
    if (didStartChargingRef.current) {
      // Release held charge
      if (chargeAnimRef.current) cancelAnimationFrame(chargeAnimRef.current);
      setIsCharging(false);
      onThrow();
    } else {
      // Standard click/tap: throw with exact current slider power!
      onThrow();
    }
  };

  const handlePointerCancel = () => {
    if (chargeTimeoutRef.current !== null) {
      clearTimeout(chargeTimeoutRef.current);
      chargeTimeoutRef.current = null;
    }
    if (didStartChargingRef.current) {
      if (chargeAnimRef.current) cancelAnimationFrame(chargeAnimRef.current);
      setIsCharging(false);
    }
  };

  useEffect(() => {
    return () => {
      if (chargeAnimRef.current) cancelAnimationFrame(chargeAnimRef.current);
      if (chargeTimeoutRef.current !== null) clearTimeout(chargeTimeoutRef.current);
    };
  }, []);

  // Keyboard shortcut handlers:
  // - * to toggle dock and box frame
  // - / to cycle camera presets
  // - Enter or Space to throw
  // - ArrowUp / ArrowDown for power (regardless of dock state)
  // - ArrowLeft / ArrowRight:
  //   * If holding down (e.repeat = true) when box is locked: continuously adjust angle smoothly without limit
  //   * If both pressed simultaneously (within 55ms window): toggle box selection (lock / unlock)
  //   * If single key and unlocked: move box laterally (skips opponent boxes)
  //   * If single key and locked: fine-tune throw angle (-40° to +40°)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 1. Toggle dock and box frame with * key
      if (e.key === '*' || e.code === 'NumpadMultiply') {
        e.preventDefault();
        sound.playClick();
        setIsDockCollapsed((prev) => !prev);
        return;
      }

      // 2. Cycle camera presets sequentially with / key
      if (e.code === 'Slash' || e.key === '/') {
        e.preventDefault();
        const CAM_PRESETS: CameraPreset[] = ['throw', 'jack_topdown', 'court_overview', 'free_orbit'];
        const currentIdx = CAM_PRESETS.indexOf(snapshotRef.current.cameraPreset);
        const nextPreset = CAM_PRESETS[(currentIdx + 1) % CAM_PRESETS.length];
        sound.playClick();
        onSetCameraPreset(nextPreset);
        return;
      }

      // 3. Throw with Enter or Space
      if (
        (e.code === 'Enter' || e.key === 'Enter' || e.code === 'Space') &&
        snapshotRef.current.phase === 'aiming' &&
        !snapshotRef.current.isAiTurn &&
        !isCharging
      ) {
        e.preventDefault();
        onThrow();
        return;
      }

      // 4. Power adjust with ArrowUp and ArrowDown (regardless of whether dock is collapsed)
      if (e.code === 'ArrowUp' && snapshotRef.current.phase === 'aiming' && !snapshotRef.current.isAiTurn) {
        e.preventDefault();
        onSetPower(Math.min(1.0, snapshotRef.current.aimParams.power + 0.03));
        return;
      }
      if (e.code === 'ArrowDown' && snapshotRef.current.phase === 'aiming' && !snapshotRef.current.isAiTurn) {
        e.preventDefault();
        onSetPower(Math.max(0.12, snapshotRef.current.aimParams.power - 0.03));
        return;
      }

      // 5. ArrowLeft and ArrowRight
      if (
        (e.code === 'ArrowLeft' || e.code === 'ArrowRight') &&
        snapshotRef.current.phase === 'aiming' &&
        !snapshotRef.current.isAiTurn
      ) {
        e.preventDefault();
        const snap = snapshotRef.current;
        keysDownRef.current.add(e.code);

        // Check for simultaneous dual press
        if (keysDownRef.current.has('ArrowLeft') && keysDownRef.current.has('ArrowRight')) {
          if (chordTimerRef.current !== null) {
            clearTimeout(chordTimerRef.current);
            chordTimerRef.current = null;
          }
          if (!chordFiredRef.current) {
            chordFiredRef.current = true;
            onToggleBoxSelection();
          }
          return;
        }

        // If box is locked: adjust aim angle
        if (snap.isBoxLocked) {
          // If key is being held down (repeat = true): directly update angle on each event smoothly
          if (e.repeat) {
            const curAngle = snap.aimParams.angle;
            if (e.code === 'ArrowLeft') {
              onSetAngle(Math.max(-MAX_AIM_ANGLE, curAngle - 0.0125));
            } else if (e.code === 'ArrowRight') {
              onSetAngle(Math.min(MAX_AIM_ANGLE, curAngle + 0.0125));
            }
            return;
          }

          // Initial press: short 55ms window to detect if user was pressing both keys together
          if (!chordFiredRef.current && chordTimerRef.current === null) {
            const singleKey = e.code;
            chordTimerRef.current = window.setTimeout(() => {
              chordTimerRef.current = null;
              if (keysDownRef.current.has('ArrowLeft') && keysDownRef.current.has('ArrowRight')) {
                return;
              }
              const curAngle = snapshotRef.current.aimParams.angle;
              if (singleKey === 'ArrowLeft') {
                onSetAngle(Math.max(-MAX_AIM_ANGLE, curAngle - 0.0125));
              } else if (singleKey === 'ArrowRight') {
                onSetAngle(Math.min(MAX_AIM_ANGLE, curAngle + 0.0125));
              }
            }, 55);
          }
          return;
        }

        // If box is unlocked: move box laterally (skipping opponent boxes)
        if (!snap.isBoxLocked) {
          if (e.repeat) return;

          if (!chordFiredRef.current && chordTimerRef.current === null) {
            const singleKey = e.code;
            chordTimerRef.current = window.setTimeout(() => {
              chordTimerRef.current = null;
              if (keysDownRef.current.has('ArrowLeft') && keysDownRef.current.has('ArrowRight')) {
                return;
              }
              if (singleKey === 'ArrowLeft') {
                onMoveBox('left');
              } else if (singleKey === 'ArrowRight') {
                onMoveBox('right');
              }
            }, 55);
          }
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'ArrowRight') {
        keysDownRef.current.delete(e.code);
        if (!keysDownRef.current.has('ArrowLeft') && !keysDownRef.current.has('ArrowRight')) {
          chordFiredRef.current = false;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      if (chordTimerRef.current !== null) clearTimeout(chordTimerRef.current);
    };
  }, [
    isCharging,
    onThrow,
    onSetAngle,
    onSetPower,
    onMoveBox,
    onToggleBoxSelection,
    onSetCameraPreset
  ]);

  const isCurrentRed = snapshot.currentTeam === 'red';
  const isCurrentBlue = snapshot.currentTeam === 'blue';
  const isCurrentJack = snapshot.currentTeam === 'jack';

  const canThrow = snapshot.phase === 'aiming' && !snapshot.isAiTurn;

  const getModeLabel = (mode: GameMode) => {
    switch (mode) {
      case 'solo_ai':
        return '1人プレイ（vs AI）';
      case 'pairs_ai':
        return 'ペアプレイ（vs AI）';
      case 'team_ai':
        return 'チームプレイ（vs AI）';
      case 'solo_pvp':
        return '1人対戦（赤 vs 青）';
      case 'pairs_pvp':
        return 'ペア対戦（赤 vs 青）';
      case 'team_pvp':
        return 'チーム対戦（赤 vs 青）';
      default:
        return 'ボッチャ 3D';
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-2 sm:p-4 z-20">
      {/* ─── TOP STATUS BAR ─── */}
      <header
        onPointerDown={(e) => e.stopPropagation()}
        onPointerMove={(e) => e.stopPropagation()}
        className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pointer-events-auto"
      >
        {/* Left: Scoreboard & Match Mode */}
        <div className="flex items-center gap-3 bg-slate-900/95 border border-slate-700/80 rounded-2xl px-3.5 py-2 shadow-xl">
          <div className="flex items-center gap-3">
            {/* Red Score */}
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded-full bg-red-500 shadow-sm shadow-red-500/50 inline-block" />
              <span className="text-xs font-bold text-slate-400">RED</span>
              <span className="text-xl font-black text-white tabular-nums">{snapshot.redScore}</span>
            </div>

            <span className="text-xs font-bold text-slate-600">vs</span>

            {/* Blue Score */}
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black text-white tabular-nums">{snapshot.blueScore}</span>
              <span className="text-xs font-bold text-slate-400">BLUE</span>
              <span className="w-3.5 h-3.5 rounded-full bg-blue-500 shadow-sm shadow-blue-500/50 inline-block" />
            </div>
          </div>

          <div className="h-6 w-px bg-slate-700 mx-1" />

          {/* End & Mode Badge */}
          <div className="flex flex-col text-left">
            <span className="text-[10px] font-semibold text-slate-400">{getModeLabel(snapshot.mode)}</span>
            <span className="text-xs font-bold text-slate-200">
              End <strong className="text-amber-400">{snapshot.currentEnd}</strong> / {snapshot.totalEnds}
            </span>
          </div>
        </div>

        {/* Center: Current Turn Banner & Ball Inventory */}
        <div className="flex flex-col items-center">
          <div
            className={`px-4 py-1.5 rounded-full text-xs font-black tracking-wider uppercase border shadow-lg transition-all ${
              isCurrentJack
                ? 'bg-slate-800 border-white/60 text-white shadow-white/10'
                : isCurrentRed
                ? 'bg-red-950 border-red-500 text-red-300 shadow-red-500/20'
                : 'bg-blue-950 border-blue-500 text-blue-300 shadow-blue-500/20'
            }`}
          >
            {isCurrentJack ? (
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-white inline-block shadow-sm" />
                ジャックボール（白球）投球
              </span>
            ) : isCurrentRed ? (
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block shadow-sm shadow-red-500/50" />
                赤チームのターン
              </span>
            ) : (
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block shadow-sm shadow-blue-500/50" />
                {snapshot.isAiTurn ? '青チーム (AI) の思考・投球' : '青チームのターン'}
              </span>
            )}
          </div>

          {/* Ball inventory dots */}
          <div className="flex items-center gap-4 mt-1 bg-slate-950/85 px-3 py-0.5 rounded-full border border-slate-800/80 text-[11px]">
            {/* Red remaining */}
            <div className="flex items-center gap-1">
              <span className="text-slate-400 font-bold text-[10px] mr-0.5">赤残球:</span>
              {Array.from({ length: 6 }).map((_, i) => (
                <span
                  key={`red-dot-${i}`}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    i < snapshot.redRemaining
                      ? 'bg-red-500 shadow-sm shadow-red-500/50'
                      : 'bg-slate-800 border border-slate-700'
                  }`}
                />
              ))}
            </div>

            <span className="text-slate-700">|</span>

            {/* Blue remaining */}
            <div className="flex items-center gap-1">
              <span className="text-slate-400 font-bold text-[10px] mr-0.5">青残球:</span>
              {Array.from({ length: 6 }).map((_, i) => (
                <span
                  key={`blue-dot-${i}`}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    i < snapshot.blueRemaining
                      ? 'bg-blue-500 shadow-sm shadow-blue-500/50'
                      : 'bg-slate-800 border border-slate-700'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Right: Quick actions (Rules, Reset, Audio) */}
        <div className="flex items-center gap-2 bg-slate-900/95 border border-slate-700/80 rounded-2xl p-1.5 shadow-xl">
          <button
            onClick={() => {
              sound.playClick();
              onOpenRules();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="公式ルール説明"
          >
            <BookOpen className="w-4 h-4" />
          </button>

          <button
            onClick={onToggleMute}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title={isMuted ? 'ミュート解除' : 'ミュート'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={() => {
              sound.playClick();
              if (confirm('ゲームをリセットしてタイトル画面に戻りますか？')) {
                onResetMatch();
              }
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors cursor-pointer"
            title="タイトルに戻る / リセット"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* ─── LIVE PROMPT & DISTANCE PILL ─── */}
      <div className="flex flex-col items-center gap-1 pointer-events-none mb-auto mt-1.5">
        {snapshot.lastMessage && (
          <div className="px-3.5 py-1 bg-slate-900/90 border border-slate-700/70 rounded-full text-xs font-semibold text-slate-200 shadow-lg animate-fadeIn text-center max-w-xl">
            {snapshot.lastMessage}
          </div>
        )}

        {/* Distance comparison pill */}
        {snapshot.closestDistance.red > 0 || snapshot.closestDistance.blue > 0 ? (
          <div className="flex items-center gap-2 bg-slate-950/85 px-3 py-0.5 rounded-full border border-slate-800 text-[11px] text-slate-400 font-mono shadow-sm">
            <span>ジャック最接近:</span>
            <span className="text-red-400 font-bold">赤 {snapshot.closestDistance.red}m</span>
            <span>/</span>
            <span className="text-blue-400 font-bold">青 {snapshot.closestDistance.blue}m</span>
          </div>
        ) : null}
      </div>

      {/* ─── CONSOLIDATED BOTTOM DOCK (COLLAPSIBLE VIA * KEY) ─── */}
      <div className="w-full max-w-4xl mx-auto pointer-events-auto flex flex-col items-center">
        {/* Collapse Toggle Tab */}
        <button
          onClick={() => {
            sound.playClick();
            setIsDockCollapsed((prev) => !prev);
          }}
          className="flex items-center gap-1.5 px-4 py-1 rounded-t-xl bg-slate-900/95 border-t border-x border-slate-700 text-[11px] font-bold text-slate-400 hover:text-white transition-colors cursor-pointer shadow-lg"
        >
          {isDockCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          <span>{isDockCollapsed ? '投球パネル・ボックス枠を表示 (*)' : '投球パネル・ボックス枠を隠す (*)'}</span>
        </button>

        {/* Collapsed Mini Status HUD (Unobstructed View) */}
        {isDockCollapsed && snapshot.phase === 'aiming' && !snapshot.isAiTurn && (
          <div className="bg-slate-900/95 border border-slate-700/80 rounded-b-xl px-4 py-1.5 text-xs font-semibold text-slate-300 shadow-xl flex flex-wrap items-center justify-center gap-3 animate-fadeIn">
            <span>
              ボックス: <strong className="text-white font-mono">{snapshot.currentBox}</strong> (
              {snapshot.isBoxLocked ? '決定済' : '未決定・←+→で決定'})
            </span>
            <span className="text-slate-600">|</span>
            <span>
              方向: <strong className="text-white font-mono">{((snapshot.aimParams.angle * 180) / Math.PI).toFixed(1)}°</strong> (←→長押し可)
            </span>
            <span className="text-slate-600">|</span>
            <span>
              パワー: <strong className="text-amber-400 font-mono">{Math.round(snapshot.aimParams.power * 100)}%</strong> (↑↓)
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-400 text-[11px]">Enter投球 • /視点切替 • *キーで枠/パネル表示</span>
          </div>
        )}

        {/* Expanded: Throwing Box Selector Bar AND Control Dock Panel */}
        {!isDockCollapsed && (
          <div
            onPointerDown={(e) => e.stopPropagation()}
            onPointerMove={(e) => e.stopPropagation()}
            onPointerUp={(e) => e.stopPropagation()}
            className="w-full space-y-2"
          >
            {/* THROWING BOX SELECTOR BAR (スローイングボックス 1〜6) */}
            {(() => {
              const targetTeam =
                snapshot.currentTeam === 'jack'
                  ? (snapshot.boxes.find((b) => b.boxNumber === snapshot.currentBox)?.team || 'red')
                  : snapshot.currentTeam;

              const eligibleBoxes = (snapshot.boxes || [])
                .filter(
                  (b) =>
                    b.team === targetTeam &&
                    (snapshot.currentTeam === 'jack' ? b.ballsTotal > 0 : b.ballsLeft > 0)
                )
                .sort((a, b) => a.boxNumber - b.boxNumber);

              const curEligibleIdx = eligibleBoxes.findIndex((b) => b.boxNumber === snapshot.currentBox);
              const canMoveLeft = !snapshot.isBoxLocked && curEligibleIdx > 0;
              const canMoveRight =
                !snapshot.isBoxLocked && curEligibleIdx !== -1 && curEligibleIdx < eligibleBoxes.length - 1;

              return (
                <div className="w-full bg-slate-900/95 border border-slate-700/90 rounded-2xl p-2.5 shadow-2xl backdrop-blur-md">
                  {/* Top row: Box Status & Action Buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-300">スローイングボックス:</span>
                      {snapshot.isBoxLocked ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-sm shadow-amber-500/20">
                          <CheckCircle2 className="w-3 h-3 text-amber-400" />
                          ボックス {snapshot.currentBox} 決定済（投球可能）
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/50 animate-pulse">
                          <Unlock className="w-3 h-3 text-blue-400" />
                          ボックス {snapshot.currentBox} 選択中（←+→ で決定）
                        </span>
                      )}
                    </div>

                    {/* Quick lateral move and chord buttons for touch/mouse */}
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={!canThrow || !canMoveLeft}
                        onClick={() => {
                          sound.playClick();
                          onMoveBox('left');
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 border border-slate-700 cursor-pointer transition-all"
                        title="左の自チームボックスへ移動 (←キー・相手チームはスキップ)"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">左へ (←)</span>
                      </button>

                      <button
                        type="button"
                        disabled={!canThrow}
                        onClick={() => {
                          onToggleBoxSelection();
                        }}
                        className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-black border transition-all cursor-pointer shadow-md ${
                          snapshot.isBoxLocked
                            ? 'bg-amber-600/30 hover:bg-amber-600/40 border-amber-500 text-amber-300 shadow-amber-500/20'
                            : 'bg-emerald-600/30 hover:bg-emerald-600/40 border-emerald-500 text-emerald-300 shadow-emerald-500/20'
                        }`}
                        title="2キー同時押しで決定/解除 (← + →)"
                      >
                        {snapshot.isBoxLocked ? (
                          <>
                            <Unlock className="w-3.5 h-3.5 text-amber-400" />
                            <span>選択解除 (←+→)</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3.5 h-3.5 text-emerald-400" />
                            <span>ボックス決定 (←+→)</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        disabled={!canThrow || !canMoveRight}
                        onClick={() => {
                          sound.playClick();
                          onMoveBox('right');
                        }}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 border border-slate-700 cursor-pointer transition-all"
                        title="右の自チームボックスへ移動 (→キー・相手チームはスキップ)"
                      >
                        <span className="hidden sm:inline">右へ (→)</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Bottom row: The 6 Boxes (1 to 6 from left to right) */}
                  <div className="grid grid-cols-6 gap-1.5 sm:gap-2">
                    {(snapshot.boxes && snapshot.boxes.length === 6
                      ? snapshot.boxes
                      : [1, 2, 3, 4, 5, 6].map((i) => ({
                          boxNumber: i,
                          team: (i % 2 === 1 ? 'red' : 'blue') as 'red' | 'blue',
                          playerLabel: `Box ${i}`,
                          ballsTotal: 2,
                          ballsLeft: 2,
                          ballIds: [],
                          isAi: false
                        }))
                    ).map((b) => {
                      const isFocused = snapshot.currentBox === b.boxNumber;
                      const isLocked = isFocused && snapshot.isBoxLocked;
                      const isRed = b.team === 'red';
                      const isOpponentTeam = b.team !== targetTeam;
                      const isEligible = !isOpponentTeam && b.ballsLeft > 0;

                      return (
                        <button
                          key={`box-item-${b.boxNumber}`}
                          type="button"
                          disabled={!canThrow || b.ballsTotal === 0 || isOpponentTeam}
                          onClick={() => {
                            sound.playClick();
                            onSelectBoxDirectly(b.boxNumber);
                          }}
                          title={
                            isOpponentTeam
                              ? '相手チームのボックス（投球時はスキップされます）'
                              : b.ballsTotal === 0
                              ? 'このモードでは未使用'
                              : b.ballsLeft === 0
                              ? 'ボールを投げ終わりました'
                              : `ボックス ${b.boxNumber} を選択`
                          }
                          className={`relative flex flex-col items-center justify-between p-1.5 sm:p-2 rounded-xl border text-center transition-all ${
                            isOpponentTeam
                              ? 'bg-slate-950/40 border-slate-900/60 text-slate-600 opacity-35 cursor-not-allowed'
                              : b.ballsTotal === 0
                              ? 'bg-slate-900/40 border-slate-800/50 opacity-30 cursor-not-allowed'
                              : isLocked
                              ? 'bg-amber-500/25 border-amber-400 ring-2 ring-amber-400/50 shadow-lg shadow-amber-500/25 text-white cursor-pointer'
                              : isFocused
                              ? 'bg-slate-800 border-white ring-2 ring-white/50 shadow-md text-white cursor-pointer'
                              : isEligible
                              ? 'bg-slate-800/60 border-slate-700 hover:border-slate-500 text-slate-300 cursor-pointer'
                              : 'bg-slate-900/60 border-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          {/* Top indicator: Box number & team color */}
                          <div className="flex items-center gap-1 text-[11px] font-black">
                            <span
                              className={`w-2 h-2 rounded-full inline-block ${
                                b.ballsTotal === 0
                                  ? 'bg-slate-600'
                                  : isOpponentTeam
                                  ? 'bg-slate-700'
                                  : isRed
                                  ? 'bg-red-500'
                                  : 'bg-blue-500'
                              }`}
                            />
                            <span>{b.boxNumber}</span>
                          </div>

                          {/* Player Label */}
                          <div className="text-[10px] font-bold truncate max-w-full my-0.5 text-slate-300">
                            {isOpponentTeam ? '相手チーム' : b.playerLabel.split(' ')[0]}
                          </div>

                          {/* Remaining Balls */}
                          <div className="text-[10px] font-mono tabular-nums">
                            {b.ballsTotal === 0 ? (
                              <span className="text-slate-600">-</span>
                            ) : isOpponentTeam ? (
                              <span className="text-slate-600">スキップ</span>
                            ) : (
                              <span
                                className={
                                  b.ballsLeft > 0
                                    ? isRed
                                      ? 'text-red-400'
                                      : 'text-blue-400'
                                    : 'text-slate-600'
                                }
                              >
                                {b.ballsLeft}球
                              </span>
                            )}
                          </div>

                          {/* Status chip */}
                          {isLocked && (
                            <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 rounded-full p-0.5 shadow-sm">
                              <Lock className="w-2.5 h-2.5" />
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })()}

            {/* CONTROLS DOCK PANEL */}
            <div className="w-full bg-slate-900/95 border border-slate-700/80 rounded-2xl p-3.5 sm:p-4 shadow-2xl space-y-2.5">
              {/* Row 1: Camera Presets & Measurement Tool */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                {/* Camera Presets */}
                <div className="flex items-center gap-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase mr-1">視点 (/切替):</span>
                  {[
                    { id: 'throw', label: '投球視点' },
                    { id: 'jack_topdown', label: 'ジャック見下ろし' },
                    { id: 'court_overview', label: '全体俯瞰' },
                    { id: 'free_orbit', label: '自由操作' }
                  ].map((cam) => (
                    <button
                      key={cam.id}
                      onClick={() => {
                        sound.playClick();
                        onSetCameraPreset(cam.id as CameraPreset);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                        snapshot.cameraPreset === cam.id
                          ? 'bg-blue-600/30 border-blue-500 text-white shadow-sm'
                          : 'bg-slate-800/60 border-slate-700/50 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {cam.label}
                    </button>
                  ))}
                </div>

                {/* Referee Measurement Tool */}
                <button
                  onClick={handleToggleMeasure}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                    showMeasure
                      ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300'
                      : 'bg-slate-800/60 border-slate-700/50 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>審判メジャー表示</span>
                </button>
              </div>

              {/* Row 2: Throwing Controls (Angle, Power, Spin, Throw Button) */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
                {/* Angle Control (4 cols) -40° to +40° */}
                <div className="sm:col-span-4 bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                    <span className="font-semibold text-slate-300 flex items-center gap-1">
                      <Compass className="w-3.5 h-3.5 text-blue-400" /> 投球角度 (←→長押し可)
                    </span>
                    <span className="font-mono text-slate-200 tabular-nums font-bold">
                      {((snapshot.aimParams.angle * 180) / Math.PI).toFixed(1)}°
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      disabled={!canThrow}
                      onClick={() => {
                        sound.playClick();
                        onSetAngle(Math.max(-MAX_AIM_ANGLE, snapshot.aimParams.angle - 0.0125));
                      }}
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 cursor-pointer"
                      title="左へ微調整 (-0.0125rad)"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>

                    <input
                      type="range"
                      min={-MAX_AIM_ANGLE}
                      max={MAX_AIM_ANGLE}
                      step={0.005}
                      disabled={!canThrow}
                      value={snapshot.aimParams.angle}
                      onChange={(e) => onSetAngle(parseFloat(e.target.value))}
                      className="flex-1 accent-blue-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />

                    <button
                      disabled={!canThrow}
                      onClick={() => {
                        sound.playClick();
                        onSetAngle(Math.min(MAX_AIM_ANGLE, snapshot.aimParams.angle + 0.0125));
                      }}
                      className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 cursor-pointer"
                      title="右へ微調整 (+0.0125rad)"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              {/* Power Control (4 cols) */}
              <div className="sm:col-span-4 bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="font-semibold text-slate-300 flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5 text-amber-400" /> 投球パワー (↑↓キー)
                  </span>
                  <span className="font-mono text-amber-400 font-bold tabular-nums">
                    {Math.round(snapshot.aimParams.power * 100)}%
                  </span>
                </div>

                <input
                  type="range"
                  min={0.15}
                  max={1.0}
                  step={0.01}
                  disabled={!canThrow}
                  value={snapshot.aimParams.power}
                  onChange={(e) => onSetPower(parseFloat(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Spin / Height & Big Throw Action (4 cols) */}
              <div className="sm:col-span-4 flex items-center gap-2">
                {/* Spin / Curve Buttons */}
                <div className="flex flex-col gap-1 flex-1">
                  <div className="text-[10px] font-bold text-slate-400">スピン (回転)</div>
                  <div className="grid grid-cols-3 gap-1">
                    {[
                      { id: -0.6, label: '左' },
                      { id: 0, label: '直進' },
                      { id: 0.6, label: '右' }
                    ].map((s) => (
                      <button
                        key={s.label}
                        disabled={!canThrow}
                        onClick={() => {
                          sound.playClick();
                          onSetSpin(s.id);
                        }}
                        className={`py-1 text-[11px] font-bold rounded border transition-colors cursor-pointer ${
                          snapshot.aimParams.spin === s.id
                            ? 'bg-purple-600/30 border-purple-500 text-purple-300'
                            : 'bg-slate-800/40 border-slate-700/50 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Primary Throw Button */}
                <button
                  disabled={!canThrow}
                  onPointerDown={handlePointerDown}
                  onPointerUp={handlePointerUp}
                  onPointerCancel={handlePointerCancel}
                  className={`flex-1 py-3 px-3 rounded-xl font-black text-sm tracking-wide shadow-xl transition-all cursor-pointer flex flex-col items-center justify-center ${
                    !canThrow
                      ? 'bg-slate-800 text-slate-500 border border-slate-700/50 cursor-not-allowed opacity-60'
                      : isCharging
                      ? 'bg-gradient-to-r from-amber-500 to-red-500 text-slate-950 scale-102 ring-4 ring-amber-400/40 animate-pulse'
                      : isCurrentRed
                      ? 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-red-600/30 active:scale-98'
                      : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-blue-600/30 active:scale-98'
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    <Target className="w-4 h-4" />
                    <span>{isCharging ? '離して投げる!' : '投球 (Enter)'}</span>
                  </span>
                  <span className="text-[10px] font-normal opacity-75">
                    {isCharging ? 'パワーチャージ中...' : 'クリックで即投球・長押しでパワー可変'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  </div>
  );
};
