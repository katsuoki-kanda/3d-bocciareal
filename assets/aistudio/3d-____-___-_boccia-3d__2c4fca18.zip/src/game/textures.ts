/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

/**
 * Generate procedural leather ball texture with stitched panels
 */
export function createBallTexture(baseColor: string, seamColor: string = '#d1d5db', label?: string): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Fill base color
  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, size, size);

  // Add subtle leather noise/grain
  const imgData = ctx.getImageData(0, 0, size, size);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const grain = (Math.random() - 0.5) * 18;
    data[i] = Math.min(255, Math.max(0, data[i] + grain));
    data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + grain));
    data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + grain));
  }
  ctx.putImageData(imgData, 0, 0);

  // Draw Boccia panel seam lines (6-lobe / cubical stitched pattern projection)
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';

  const drawSeams = () => {
    // Horizontal equator
    ctx.beginPath();
    ctx.moveTo(0, size * 0.5);
    ctx.lineTo(size, size * 0.5);
    ctx.stroke();

    // Two curved meridians
    ctx.beginPath();
    ctx.ellipse(size * 0.25, size * 0.5, size * 0.2, size * 0.45, 0, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.ellipse(size * 0.75, size * 0.5, size * 0.2, size * 0.45, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Vertical quarter lines
    ctx.beginPath();
    ctx.moveTo(size * 0.5, 0);
    ctx.lineTo(size * 0.5, size);
    ctx.stroke();
  };

  // Shadow seam line
  drawSeams();

  // White/cream stitch dashes
  ctx.strokeStyle = seamColor;
  ctx.lineWidth = 2.5;
  ctx.setLineDash([4, 6]);
  drawSeams();
  ctx.setLineDash([]);

  // Ball branding / badge in center
  if (label) {
    ctx.save();
    ctx.translate(size * 0.5, size * 0.5);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.beginPath();
    ctx.arc(0, 0, 36, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.font = 'bold 22px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, 0, 0);
    ctx.restore();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

/**
 * Procedural normal/bump map for leather seams
 */
export function createBallBumpMap(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, size, size);

  // Pebble noise
  const imgData = ctx.getImageData(0, 0, size, size);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const n = Math.floor((Math.random() - 0.5) * 30);
    const val = Math.min(255, Math.max(0, 128 + n));
    data[i] = val;
    data[i + 1] = val;
    data[i + 2] = val;
  }
  ctx.putImageData(imgData, 0, 0);

  // Dark grooves for seams
  ctx.strokeStyle = '#202020';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(0, size * 0.5);
  ctx.lineTo(size, size * 0.5);
  ctx.moveTo(size * 0.5, 0);
  ctx.lineTo(size * 0.5, size);
  ctx.stroke();

  ctx.beginPath();
  ctx.ellipse(size * 0.25, size * 0.5, size * 0.2, size * 0.45, 0, 0, Math.PI * 2);
  ctx.ellipse(size * 0.75, size * 0.5, size * 0.2, size * 0.45, 0, 0, Math.PI * 2);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

/**
 * Generate regulation Boccia court texture
 * Dimensions: 6m wide x 12.5m long (mapped to canvas aspect ratio 6:12.5)
 */
export function createCourtTexture(): THREE.CanvasTexture {
  const width = 1024;
  const height = 2133; // 1024 * (12.5 / 6.0) ≈ 2133
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;

  // Base court floor: Sports blue (darker near throwing boxes, rich blue in target zone)
  const grad = ctx.createLinearGradient(0, height, 0, 0);
  grad.addColorStop(0, '#1e3a8a'); // dark blue at throwing boxes
  grad.addColorStop(0.5, '#2563eb'); // rich athletic blue in target zone
  grad.addColorStop(1, '#1d4ed8'); // far end
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Subtle sports floor grain / micro-lines
  ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
  for (let y = 0; y < height; y += 8) {
    ctx.fillRect(0, y, width, 2);
  }

  // World court: Z=0 (back of boxes), Z=2.5m (throwing line), Z=3.0m (V-line apex), Z=7.5m (Cross), Z=12.5m (far end)
  // In canvas coordinates (with mesh rotated): Y=height is Z=0, Y=0 is Z=12.5m
  const throwLineY = height * (1 - 2.5 / 12.5); // height * 0.8
  const vLineApexY = height * (1 - 3.0 / 12.5); // height * 0.76 (apex points toward thrower)
  const vLineSideY = height * (1 - 4.3 / 12.5); // height * 0.656 (arms flare forward into court)

  // Throwing box area shading
  ctx.fillStyle = 'rgba(15, 23, 42, 0.18)';
  ctx.fillRect(0, throwLineY, width, height - throwLineY);

  // Line drawing styles
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 10;
  ctx.lineCap = 'square';
  ctx.lineJoin = 'miter';

  // 1. Outer boundary lines
  const pad = 12;
  ctx.strokeRect(pad, pad, width - pad * 2, height - pad * 2);

  // 2. Throwing line (Z = 2.5m)
  ctx.beginPath();
  ctx.moveTo(pad, throwLineY);
  ctx.lineTo(width - pad, throwLineY);
  ctx.stroke();

  // 3. Throwing boxes 1-6 (divided into 6 equal 1m wide lanes, ordered 1 to 6 from left to right)
  const boxWidth = (width - pad * 2) / 6;
  ctx.lineWidth = 6;
  for (let i = 1; i < 6; i++) {
    const x = pad + i * boxWidth;
    ctx.beginPath();
    ctx.moveTo(x, throwLineY);
    ctx.lineTo(x, height - pad);
    ctx.stroke();
  }

  // Box Numbers (1 to 6 from left to right, drawn upright)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const boxLabels = ['1', '2', '3 (RED)', '4 (BLUE)', '5', '6'];
  for (let i = 0; i < 6; i++) {
    const cx = pad + (i + 0.5) * boxWidth;
    const cy = (throwLineY + height - pad) * 0.5;
    ctx.font = i === 2 || i === 3 ? 'bold 24px system-ui, sans-serif' : 'bold 36px system-ui, sans-serif';
    ctx.fillText(boxLabels[i], cx, cy);
  }

  // 4. V-Line (Non-valid line for Jack ball)
  // Vertex points toward the thrower (apex at vLineApexY, sides at vLineSideY)
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(pad, vLineSideY);
  ctx.lineTo(width * 0.5, vLineApexY);
  ctx.lineTo(width - pad, vLineSideY);
  ctx.stroke();

  // Label "▲ JACK VALID AREA (ジャック有効エリア) ▲"
  ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
  ctx.font = 'bold 22px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.fillText('▲ JACK VALID AREA (ジャック有効エリア) ▲', width * 0.5, vLineApexY - 35);

  // 5. Center Cross (+) at Z = 7.5m
  const crossY = height * (1 - 7.5 / 12.5);
  const crossSize = 38;
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(width * 0.5 - crossSize, crossY);
  ctx.lineTo(width * 0.5 + crossSize, crossY);
  ctx.moveTo(width * 0.5, crossY - crossSize);
  ctx.lineTo(width * 0.5, crossY + crossSize);
  ctx.stroke();

  // Center cross label
  ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
  ctx.font = 'bold 18px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'bottom';
  ctx.fillText('CROSS (+)', width * 0.5, crossY - crossSize - 16);

  // 6. Sideline distance marks measured FROM THE THROWING BOX / LINE (0m at throw line up to 10m at far end)
  const distanceMarks = [
    { d: 0, label: '0m (投球線)', isMajor: true },
    { d: 1, label: '1m', isMajor: false },
    { d: 2, label: '2m', isMajor: true },
    { d: 3, label: '3m', isMajor: false },
    { d: 4, label: '4m', isMajor: true },
    { d: 5, label: '5m (クロス)', isMajor: true },
    { d: 6, label: '6m', isMajor: true },
    { d: 7, label: '7m', isMajor: false },
    { d: 8, label: '8m', isMajor: true },
    { d: 9, label: '9m', isMajor: false },
    { d: 10, label: '10m (エンド)', isMajor: true }
  ];

  distanceMarks.forEach((m) => {
    const y = height * (1 - (2.5 + m.d) / 12.5);
    const tickLen = m.isMajor ? 28 : 16;
    ctx.lineWidth = m.isMajor ? 6 : 3;
    ctx.strokeStyle = '#ffffff';

    // Left tick
    ctx.beginPath();
    ctx.moveTo(pad, y);
    ctx.lineTo(pad + tickLen, y);
    ctx.stroke();

    // Right tick
    ctx.beginPath();
    ctx.moveTo(width - pad, y);
    ctx.lineTo(width - pad - tickLen, y);
    ctx.stroke();

    if (m.isMajor) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.font = m.d === 0 || m.d === 5 || m.d === 10 ? 'bold 20px system-ui, sans-serif' : 'bold 18px system-ui, sans-serif';
      ctx.textBaseline = 'middle';

      // Left sideline label
      ctx.textAlign = 'left';
      ctx.fillText(m.label, pad + tickLen + 10, y);

      // Right sideline label
      ctx.textAlign = 'right';
      ctx.fillText(m.label, width - pad - tickLen - 10, y);
    }
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/**
 * Arena surround floor texture (polished wood gym floor)
 */
export function createSurroundTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Warm maple gym floor
  ctx.fillStyle = '#b45309';
  ctx.fillRect(0, 0, size, size);

  // Wood planks
  const plankH = 32;
  for (let y = 0; y < size; y += plankH) {
    const tone = Math.floor(Math.random() * 30);
    ctx.fillStyle = `rgb(${180 + tone}, ${120 + tone * 0.6}, ${50 + tone * 0.4})`;
    ctx.fillRect(0, y, size, plankH - 2);

    // Plank seam
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.fillRect(0, y + plankH - 2, size, 2);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(6, 12);
  return texture;
}
