/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as CANNON from 'cannon-es';
import { sound } from './audio';

export interface PhysicsBall {
  id: string;
  body: CANNON.Body;
  radius: number;
}

export class PhysicsWorld {
  public world: CANNON.World;
  public ballMaterial: CANNON.Material;
  public courtMaterial: CANNON.Material;
  public wallMaterial: CANNON.Material;
  private balls: Map<string, PhysicsBall> = new Map();

  constructor() {
    this.world = new CANNON.World({
      gravity: new CANNON.Vec3(0, -9.82, 0)
    });

    // Materials
    this.ballMaterial = new CANNON.Material('ball');
    this.courtMaterial = new CANNON.Material('court');
    this.wallMaterial = new CANNON.Material('wall');

    // Ball to Court Contact
    const ballCourtContact = new CANNON.ContactMaterial(this.ballMaterial, this.courtMaterial, {
      friction: 0.32,
      restitution: 0.18,
      contactEquationStiffness: 1e7,
      contactEquationRelaxation: 3
    });
    this.world.addContactMaterial(ballCourtContact);

    // Ball to Ball Contact (elastic, tactile collision)
    const ballBallContact = new CANNON.ContactMaterial(this.ballMaterial, this.ballMaterial, {
      friction: 0.35,
      restitution: 0.62,
      contactEquationStiffness: 1e8,
      contactEquationRelaxation: 2
    });
    this.world.addContactMaterial(ballBallContact);

    // Ball to Wall Contact (soft cushions)
    const ballWallContact = new CANNON.ContactMaterial(this.ballMaterial, this.wallMaterial, {
      friction: 0.2,
      restitution: 0.3
    });
    this.world.addContactMaterial(ballWallContact);

    this.createStaticSurfaces();
  }

  private createStaticSurfaces() {
    // 1. Court floor (infinite plane)
    const floorBody = new CANNON.Body({
      type: CANNON.Body.STATIC,
      shape: new CANNON.Plane(),
      material: this.courtMaterial
    });
    // Rotate plane so its normal points +Y
    floorBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
    floorBody.position.set(0, 0, 0);
    this.world.addBody(floorBody);

    // 2. Soft Perimeter Bumpers around the 6m x 12.5m court
    // Court center in Z is 6.25m
    const wallHeight = 0.4;
    const wallThickness = 0.2;

    // Left wall (X = -3.1)
    const leftWall = new CANNON.Body({
      type: CANNON.Body.STATIC,
      shape: new CANNON.Box(new CANNON.Vec3(wallThickness, wallHeight, 7.0)),
      position: new CANNON.Vec3(-3.1, wallHeight * 0.5, 6.25),
      material: this.wallMaterial
    });
    this.world.addBody(leftWall);

    // Right wall (X = 3.1)
    const rightWall = new CANNON.Body({
      type: CANNON.Body.STATIC,
      shape: new CANNON.Box(new CANNON.Vec3(wallThickness, wallHeight, 7.0)),
      position: new CANNON.Vec3(3.1, wallHeight * 0.5, 6.25),
      material: this.wallMaterial
    });
    this.world.addBody(rightWall);

    // Back wall behind throwing boxes (Z = -0.3)
    const backWall = new CANNON.Body({
      type: CANNON.Body.STATIC,
      shape: new CANNON.Box(new CANNON.Vec3(3.5, wallHeight, wallThickness)),
      position: new CANNON.Vec3(0, wallHeight * 0.5, -0.3),
      material: this.wallMaterial
    });
    this.world.addBody(backWall);

    // Far end wall (Z = 12.8)
    const farWall = new CANNON.Body({
      type: CANNON.Body.STATIC,
      shape: new CANNON.Box(new CANNON.Vec3(3.5, wallHeight, wallThickness)),
      position: new CANNON.Vec3(0, wallHeight * 0.5, 12.8),
      material: this.wallMaterial
    });
    this.world.addBody(farWall);
  }

  /**
   * Spawn or register a ball in physics
   */
  public addBall(id: string, initialPos: { x: number; y: number; z: number }, radius: number = 0.08): CANNON.Body {
    // If existing, remove first
    if (this.balls.has(id)) {
      this.removeBall(id);
    }

    const mass = 0.275; // kg
    const shape = new CANNON.Sphere(radius);
    const body = new CANNON.Body({
      mass,
      shape,
      material: this.ballMaterial,
      linearDamping: 0.35, // tuned deceleration for Boccia balls on sports court
      angularDamping: 0.38
    });

    body.position.set(initialPos.x, initialPos.y, initialPos.z);
    body.sleepSpeedLimit = 0.03;
    body.sleepTimeLimit = 0.5;

    // Collision sound listener
    body.addEventListener('collide', (event: { body: CANNON.Body; target: CANNON.Body; contact: CANNON.ContactEquation }) => {
      const relVelocity = event.contact.getImpactVelocityAlongNormal();
      if (Math.abs(relVelocity) > 0.12) {
        if (event.body.material === this.ballMaterial) {
          sound.playBallCollision(Math.abs(relVelocity));
        } else if (event.body.material === this.courtMaterial) {
          sound.playFloorBounce(Math.abs(relVelocity));
        }
      }
    });

    this.world.addBody(body);
    this.balls.set(id, { id, body, radius });
    return body;
  }

  public getBall(id: string): CANNON.Body | undefined {
    return this.balls.get(id)?.body;
  }

  public removeBall(id: string) {
    const item = this.balls.get(id);
    if (item) {
      this.world.removeBody(item.body);
      this.balls.delete(id);
    }
  }

  public clearAllBalls() {
    this.balls.forEach((item) => {
      this.world.removeBody(item.body);
    });
    this.balls.clear();
  }

  private timeAccumulator: number = 0;
  private readonly fixedTimeStep: number = 1 / 60;
  private readonly maxSubSteps: number = 10;

  /**
   * Apply throw impulse to a ball body with exact calibrated physics
   */
  public applyThrow(
    id: string,
    forwardDir: { x: number; z: number },
    power: number, // 0.1 to 1.0
    loft: number = 0,
    spin: number = 0
  ) {
    const body = this.getBall(id);
    if (!body) return;

    body.wakeUp();
    // Calibrated speed: power 0.1 -> ~2.1m, power 0.5 -> ~5.7m, power 1.0 -> ~10.2m (back court line)
    const clampedPower = Math.max(0.08, Math.min(1.0, power));
    const speed = 0.55 + clampedPower * 4.05;

    // Linear velocity vector
    const vx = forwardDir.x * speed;
    const vz = forwardDir.z * speed;
    const vy = loft > 0.01 ? loft * speed * 0.5 : 0; // Pure floor roll has vy = 0 for 100% deterministic trajectory

    body.velocity.set(vx, vy, vz);

    // Natural forward rolling angular velocity (v / r) around X/Z
    // When rolling in +Z direction, rotation is around +X axis (positive wx by right-hand rule)
    // When rolling in +X direction, rotation is around -Z axis (negative wz by right-hand rule)
    const r = 0.08;
    const rollAngularSpeed = speed / r;
    const spinAngularSpeed = spin * 10.0; // side spin (hook/slice)

    const wx = forwardDir.z * rollAngularSpeed;
    const wz = -forwardDir.x * rollAngularSpeed;
    const wy = spinAngularSpeed; // yaw spin torque

    body.angularVelocity.set(wx, wy, wz);
  }

  /**
   * Check if any ball is currently moving fast enough
   */
  public isAnythingMoving(threshold: number = 0.03): boolean {
    for (const item of this.balls.values()) {
      const v = item.body.velocity;
      const speed = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
      if (speed > threshold) {
        return true;
      }
    }
    return false;
  }

  /**
   * Step physics world with deterministic fixed time-step accumulator (zero frame-rate variance)
   */
  public step(dt: number) {
    const clampedDt = Math.min(dt, 0.06);
    this.timeAccumulator += clampedDt;
    let steps = 0;
    while (this.timeAccumulator >= this.fixedTimeStep && steps < this.maxSubSteps) {
      this.world.step(this.fixedTimeStep);
      this.timeAccumulator -= this.fixedTimeStep;
      steps++;
    }
  }
}
