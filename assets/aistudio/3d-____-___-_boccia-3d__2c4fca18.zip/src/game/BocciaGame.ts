/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { PhysicsWorld } from './physics';
import { createBocciaCourt } from './court';
import { BallManager } from './balls';
import { BocciaRules, BallState } from './rules';
import { BocciaAI } from './ai';
import { sound } from './audio';
import {
  Team,
  GamePhase,
  GameMode,
  AIDifficulty,
  ThrowParams,
  RoundScore,
  CameraPreset,
  BoxInfo,
  MAX_AIM_ANGLE
} from './types';

export interface GameSnapshot {
  phase: GamePhase;
  mode: GameMode;
  difficulty: AIDifficulty;
  currentTeam: Team | 'jack';
  activeBallId: string | null;
  redRemaining: number;
  blueRemaining: number;
  redScore: number;
  blueScore: number;
  currentEnd: number;
  totalEnds: number;
  isAiTurn: boolean;
  aimParams: ThrowParams;
  closestDistance: { red: number; blue: number };
  lastMessage: string | null;
  roundScore: RoundScore | null;
  cameraPreset: CameraPreset;
  currentBox: number;
  isBoxLocked: boolean;
  boxes: BoxInfo[];
}

export class BocciaGame {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private physics: PhysicsWorld;
  private ballManager: BallManager;

  // Game configuration
  private mode: GameMode = 'solo_ai';
  private difficulty: AIDifficulty = 'medium';
  private totalEnds: number = 4;
  private currentEnd: number = 1;
  private matchScores = { red: 0, blue: 0 };

  // Box tracking and team rotation
  private boxes: BoxInfo[] = [];
  private currentBox: number = 3;
  private isBoxLocked: boolean = false;
  private currentJackTeam: Team = 'red';
  private boxHighlightGroup: THREE.Group = new THREE.Group();
  private boxHighlightPlane: THREE.Mesh;
  private boxHighlightOutline: THREE.LineSegments;
  private boxBadgeMesh: THREE.Mesh | null = null;
  private boxBadgeCanvas: HTMLCanvasElement | null = null;
  private boxBadgeTexture: THREE.CanvasTexture | null = null;

  // Turn and ball state
  private phase: GamePhase = 'aiming';
  private currentTeam: Team | 'jack' = 'jack';
  private activeBallId: string | null = 'jack';
  private activeThrowParams: ThrowParams = {
    angle: 0,
    power: 0.52,
    loft: 0,
    spin: 0,
    startX: 0.5 // Box 3 (Red) center is X = +0.5
  };

  // Balls data
  private jackState: BallState = {
    id: 'jack',
    type: 'jack',
    index: 0,
    thrown: false,
    x: 0.5,
    y: 0.08,
    z: 2.1,
    inBounds: true,
    distanceToJack: 0
  };
  private redBallsState: BallState[] = [];
  private blueBallsState: BallState[] = [];

  // Camera animation: positioned to frame all throwing boxes nicely in the lower portion of the screen
  private cameraPreset: CameraPreset = 'throw';
  private targetCameraPos = new THREE.Vector3(0.5 * 0.45, 1.95, -1.35);
  private targetCameraLookAt = new THREE.Vector3(0, 0.15, 6.0);
  private currentLookAt = new THREE.Vector3(0, 0.15, 6.0);
  private followingBallId: string | null = null;

  // Animation and physics loop
  private animFrameId: number = 0;
  private clock = new THREE.Clock();
  private isDisposed: boolean = false;
  private rollingTimeoutId: number | null = null;
  private rollCheckCount: number = 0;
  private isAiThinking: boolean = false;
  private aiTimeout1: number | null = null;
  private aiTimeout2: number | null = null;
  private statusMessage: string | null = 'ジャックボール（白球）を投げてください';
  private currentRoundScore: RoundScore | null = null;

  // Callback to React
  private onStateChangeCallback: ((snapshot: GameSnapshot) => void) | null = null;

  constructor(container: HTMLElement) {
    this.container = container;

    // Detect software WebGL as per guidelines
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.95; // Balanced exposure to prevent white washout
    this.renderer.shadowMap.enabled = !isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 2. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x090d16);
    this.scene.fog = new THREE.FogExp2(0x090d16, 0.022);

    // Procedural Studio Environment Reflection
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    // 3. Camera
    this.camera = new THREE.PerspectiveCamera(
      52,
      container.clientWidth / container.clientHeight,
      0.1,
      60
    );
    this.camera.position.copy(this.targetCameraPos);

    // 4. OrbitControls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.02; // prevent going below ground
    this.controls.minDistance = 1.0;
    this.controls.maxDistance = 25.0;
    this.controls.target.copy(this.targetCameraLookAt);
    this.controls.enabled = false; // enabled only in 'free_orbit' mode

    this.controls.addEventListener('start', () => {
      this.cameraPreset = 'free_orbit';
      this.notifyState();
    });

    // 5. Lighting
    this.setupLighting(isSoftwareGl);

    // 6. Court & Balls
    const court = createBocciaCourt(this.renderer);
    this.scene.add(court);

    // Box highlight on court floor
    const hlGeom = new THREE.PlaneGeometry(0.96, 2.4);
    const hlMat = new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.25,
      depthWrite: false
    });
    this.boxHighlightPlane = new THREE.Mesh(hlGeom, hlMat);
    this.boxHighlightPlane.rotation.x = -Math.PI / 2;

    const outlineGeom = new THREE.EdgesGeometry(new THREE.PlaneGeometry(0.98, 2.42));
    const outlineMat = new THREE.LineBasicMaterial({
      color: 0xfacc15,
      transparent: true,
      opacity: 0.8
    });
    this.boxHighlightOutline = new THREE.LineSegments(outlineGeom, outlineMat);
    this.boxHighlightOutline.rotation.x = -Math.PI / 2;

    this.boxHighlightGroup.add(this.boxHighlightPlane);
    this.boxHighlightGroup.add(this.boxHighlightOutline);

    // Selected Box 3D Floor Badge (rendered on court floor at entrance of box, local Z = -0.75, world Z = 0.5)
    this.boxBadgeCanvas = document.createElement('canvas');
    this.boxBadgeCanvas.width = 512;
    this.boxBadgeCanvas.height = 128;
    this.boxBadgeTexture = new THREE.CanvasTexture(this.boxBadgeCanvas);
    const badgeGeom = new THREE.PlaneGeometry(0.88, 0.22);
    const badgeMat = new THREE.MeshBasicMaterial({
      map: this.boxBadgeTexture,
      transparent: true,
      depthWrite: false
    });
    this.boxBadgeMesh = new THREE.Mesh(badgeGeom, badgeMat);
    this.boxBadgeMesh.rotation.x = -Math.PI / 2;
    this.boxBadgeMesh.position.set(0, 0.008, -0.75);
    this.boxHighlightGroup.add(this.boxBadgeMesh);

    this.boxHighlightGroup.position.set(0.5, 0.005, 1.25);
    this.scene.add(this.boxHighlightGroup);

    this.ballManager = new BallManager();
    this.scene.add(this.ballManager.group);

    // 7. Physics
    this.physics = new PhysicsWorld();

    // Resize handler
    window.addEventListener('resize', this.onResize);

    // Initialize round
    this.resetRound();

    // Start loop
    this.startLoop();
  }

  private setupLighting(isSoftwareGl: boolean) {
    // Soft Warm Key Directional Light (angled from side-back so it does not bounce into camera)
    const keyLight = new THREE.DirectionalLight(0xfff7ed, 1.2);
    keyLight.position.set(-3, 10, -1);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 25;
    keyLight.shadow.camera.left = -6;
    keyLight.shadow.camera.right = 6;
    keyLight.shadow.camera.top = 10;
    keyLight.shadow.camera.bottom = -4;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    this.scene.add(keyLight);

    // Cool Sky / Court Fill Light (gentle ambient fill)
    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.85);
    this.scene.add(hemiLight);

    // Target Area Soft Spotlight (dimmed to avoid white hotspot)
    const courtSpot = new THREE.SpotLight(0xffffff, 0.7);
    courtSpot.position.set(0, 10, 7.5);
    courtSpot.target.position.set(0, 0, 7.5);
    courtSpot.angle = Math.PI / 3.5;
    courtSpot.penumbra = 0.6;
    this.scene.add(courtSpot);
    this.scene.add(courtSpot.target);
  }

  private onResize = () => {
    if (!this.container || this.isDisposed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public setOnStateChange(cb: (snapshot: GameSnapshot) => void) {
    this.onStateChangeCallback = cb;
    this.notifyState();
  }

  public notifyState() {
    if (!this.onStateChangeCallback) return;

    // Distances
    let redMin = Infinity;
    let blueMin = Infinity;
    if (this.jackState.thrown) {
      this.redBallsState.forEach((b) => {
        if (b.thrown && b.inBounds) {
          const d = BocciaRules.getDistance(this.jackState.x, this.jackState.z, b.x, b.z);
          if (d < redMin) redMin = d;
        }
      });
      this.blueBallsState.forEach((b) => {
        if (b.thrown && b.inBounds) {
          const d = BocciaRules.getDistance(this.jackState.x, this.jackState.z, b.x, b.z);
          if (d < blueMin) blueMin = d;
        }
      });
    }

    const snapshot: GameSnapshot = {
      phase: this.phase,
      mode: this.mode,
      difficulty: this.difficulty,
      currentTeam: this.currentTeam,
      activeBallId: this.activeBallId,
      redRemaining: this.redBallsState.filter((b) => !b.thrown).length,
      blueRemaining: this.blueBallsState.filter((b) => !b.thrown).length,
      redScore: this.matchScores.red,
      blueScore: this.matchScores.blue,
      currentEnd: this.currentEnd,
      totalEnds: this.totalEnds,
      isAiTurn: this.isAiTurn(),
      aimParams: { ...this.activeThrowParams },
      closestDistance: {
        red: redMin === Infinity ? 0 : Number(redMin.toFixed(2)),
        blue: blueMin === Infinity ? 0 : Number(blueMin.toFixed(2))
      },
      lastMessage: this.statusMessage,
      roundScore: this.currentRoundScore,
      cameraPreset: this.cameraPreset,
      currentBox: this.currentBox,
      isBoxLocked: this.isBoxLocked,
      boxes: this.boxes.map((b) => ({ ...b }))
    };

    this.onStateChangeCallback(snapshot);
  }

  private isAiTurn(): boolean {
    if (this.phase !== 'aiming') return false;
    const isAiMode =
      this.mode === 'solo_ai' ||
      this.mode === 'pairs_ai' ||
      this.mode === 'team_ai' ||
      this.mode === 'vs_ai';
    if (!isAiMode) return false;

    if (this.currentTeam === 'jack') {
      const schedule = BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd);
      return schedule.team === 'blue';
    }
    return this.currentTeam === 'blue';
  }

  /**
   * Set up official boxes and ball allocations for each game mode
   */
  private setupBoxesForMode() {
    const isVsAi =
      this.mode === 'solo_ai' ||
      this.mode === 'pairs_ai' ||
      this.mode === 'team_ai' ||
      this.mode === 'vs_ai';

    if (this.mode === 'team_ai' || this.mode === 'team_pvp') {
      // 6 ends, Boxes 1 to 6 (2 balls each = 6 per team)
      this.boxes = [
        { boxNumber: 1, team: 'red', playerLabel: '赤1 (R1)', ballsTotal: 2, ballsLeft: 2, ballIds: ['red_1', 'red_2'], isAi: false },
        { boxNumber: 2, team: 'blue', playerLabel: '青1 (B1)', ballsTotal: 2, ballsLeft: 2, ballIds: ['blue_1', 'blue_2'], isAi: isVsAi },
        { boxNumber: 3, team: 'red', playerLabel: '赤2 (R2)', ballsTotal: 2, ballsLeft: 2, ballIds: ['red_3', 'red_4'], isAi: false },
        { boxNumber: 4, team: 'blue', playerLabel: '青2 (B2)', ballsTotal: 2, ballsLeft: 2, ballIds: ['blue_3', 'blue_4'], isAi: isVsAi },
        { boxNumber: 5, team: 'red', playerLabel: '赤3 (R3)', ballsTotal: 2, ballsLeft: 2, ballIds: ['red_5', 'red_6'], isAi: false },
        { boxNumber: 6, team: 'blue', playerLabel: '青3 (B3)', ballsTotal: 2, ballsLeft: 2, ballIds: ['blue_5', 'blue_6'], isAi: isVsAi }
      ];
    } else if (this.mode === 'pairs_ai' || this.mode === 'pairs_pvp') {
      // 4 ends, Boxes 2, 4 (Red) & 3, 5 (Blue) (3 balls each = 6 per team)
      this.boxes = [
        { boxNumber: 1, team: 'red', playerLabel: '未使用', ballsTotal: 0, ballsLeft: 0, ballIds: [], isAi: false },
        { boxNumber: 2, team: 'red', playerLabel: '赤1 (R1)', ballsTotal: 3, ballsLeft: 3, ballIds: ['red_1', 'red_2', 'red_3'], isAi: false },
        { boxNumber: 3, team: 'blue', playerLabel: '青1 (B1)', ballsTotal: 3, ballsLeft: 3, ballIds: ['blue_1', 'blue_2', 'blue_3'], isAi: isVsAi },
        { boxNumber: 4, team: 'red', playerLabel: '赤2 (R2)', ballsTotal: 3, ballsLeft: 3, ballIds: ['red_4', 'red_5', 'red_6'], isAi: false },
        { boxNumber: 5, team: 'blue', playerLabel: '青2 (B2)', ballsTotal: 3, ballsLeft: 3, ballIds: ['blue_4', 'blue_5', 'blue_6'], isAi: isVsAi },
        { boxNumber: 6, team: 'blue', playerLabel: '未使用', ballsTotal: 0, ballsLeft: 0, ballIds: [], isAi: false }
      ];
    } else {
      // Individual (Solo) - 4 ends, Box 3 (Red) & Box 4 (Blue) (6 balls each)
      this.boxes = [
        { boxNumber: 1, team: 'red', playerLabel: '未使用', ballsTotal: 0, ballsLeft: 0, ballIds: [], isAi: false },
        { boxNumber: 2, team: 'red', playerLabel: '未使用', ballsTotal: 0, ballsLeft: 0, ballIds: [], isAi: false },
        { boxNumber: 3, team: 'red', playerLabel: '赤 (Red)', ballsTotal: 6, ballsLeft: 6, ballIds: ['red_1', 'red_2', 'red_3', 'red_4', 'red_5', 'red_6'], isAi: false },
        { boxNumber: 4, team: 'blue', playerLabel: '青 (Blue)', ballsTotal: 6, ballsLeft: 6, ballIds: ['blue_1', 'blue_2', 'blue_3', 'blue_4', 'blue_5', 'blue_6'], isAi: isVsAi },
        { boxNumber: 5, team: 'blue', playerLabel: '未使用', ballsTotal: 0, ballsLeft: 0, ballIds: [], isAi: false },
        { boxNumber: 6, team: 'blue', playerLabel: '未使用', ballsTotal: 0, ballsLeft: 0, ballIds: [], isAi: false }
      ];
    }
  }

  /**
   * Update visual highlight of the current throwing box
   */
  private updateBoxHighlight() {
    if (!this.boxHighlightGroup) return;
    const boxX = BocciaRules.getBoxCenterCoord(this.currentBox);
    this.boxHighlightGroup.position.set(boxX, 0.005, 1.25);

    const box = this.boxes.find((b) => b.boxNumber === this.currentBox);
    const planeMat = this.boxHighlightPlane.material as THREE.MeshBasicMaterial;
    const outlineMat = this.boxHighlightOutline.material as THREE.LineBasicMaterial;
    const isRed = box ? box.team === 'red' : this.currentBox % 2 === 1;

    if (this.isBoxLocked) {
      // Confirmed/locked: Glowing Gold
      planeMat.color.setHex(0xfacc15);
      planeMat.opacity = 0.42;
      outlineMat.color.setHex(0xfef08a);
      outlineMat.opacity = 1.0;
    } else {
      // Unlocked: Highlight with team color
      if (isRed) {
        planeMat.color.setHex(0xef4444);
        planeMat.opacity = 0.30;
        outlineMat.color.setHex(0xf87171);
        outlineMat.opacity = 0.95;
      } else {
        planeMat.color.setHex(0x3b82f6);
        planeMat.opacity = 0.30;
        outlineMat.color.setHex(0x60a5fa);
        outlineMat.opacity = 0.95;
      }
    }

    // Update 3D badge canvas texture on floor
    if (this.boxBadgeCanvas && this.boxBadgeTexture) {
      const ctx = this.boxBadgeCanvas.getContext('2d')!;
      ctx.clearRect(0, 0, 512, 128);

      // Badge background pill
      const bgCol = this.isBoxLocked ? 'rgba(217, 119, 6, 0.95)' : isRed ? 'rgba(220, 38, 38, 0.92)' : 'rgba(37, 99, 235, 0.92)';
      ctx.fillStyle = bgCol;
      ctx.beginPath();
      ctx.roundRect(8, 8, 496, 112, 28);
      ctx.fill();

      // Border glow
      ctx.strokeStyle = this.isBoxLocked ? '#fef08a' : '#ffffff';
      ctx.lineWidth = 8;
      ctx.stroke();

      // Text label
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 50px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const statusText = this.isBoxLocked ? '★ 決定済' : '選択中';
      const label = box ? box.playerLabel.split(' ')[0] : `Box ${this.currentBox}`;
      ctx.fillText(`BOX ${this.currentBox} [${label}] ${statusText}`, 256, 64);

      this.boxBadgeTexture.needsUpdate = true;
    }
  }

  /**
   * Move box laterally with arrow keys:
   * Left arrow moves towards Box 1 (Screen left, X = +2.5)
   * Right arrow moves towards Box 6 (Screen right, X = -2.5)
   * Automatically skips opponent team's boxes and inactive boxes
   */
  public moveBox(direction: 'left' | 'right') {
    if (this.phase !== 'aiming' || this.isAiTurn()) return;
    if (this.isBoxLocked) {
      this.statusMessage = 'ボックスは決定済みです。移動するには ← + → 同時押し（または解除ボタン）で解除してください';
      this.notifyState();
      return;
    }

    const targetTeam =
      this.currentTeam === 'jack'
        ? BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd).team
        : this.currentTeam;

    // Filter boxes for the current active team that are eligible in this mode
    // (Jack throw uses the scheduled box; colored balls require ballsLeft > 0)
    const eligibleBoxes = this.boxes
      .filter((b) => {
        if (this.currentTeam === 'jack') {
          const schedule = BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd);
          return b.boxNumber === schedule.boxNumber;
        }
        return b.team === targetTeam && b.ballsLeft > 0;
      })
      .sort((a, b) => a.boxNumber - b.boxNumber);

    if (eligibleBoxes.length === 0) {
      this.statusMessage = `${targetTeam === 'red' ? '赤' : '青'}チームの利用可能なボックスがありません`;
      this.notifyState();
      return;
    }

    if (this.currentTeam === 'jack') {
      const schedule = BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd);
      this.statusMessage = `第${this.currentEnd}エンドのジャック投球は公式ルールによりボックス ${schedule.boxNumber} から行います`;
      this.currentBox = schedule.boxNumber;
      this.activeThrowParams.startX = BocciaRules.getBoxCenterCoord(this.currentBox);
      this.updateBoxHighlight();
      this.notifyState();
      return;
    }

    const currentIdx = eligibleBoxes.findIndex((b) => b.boxNumber === this.currentBox);
    let nextIdx: number;

    if (currentIdx === -1) {
      // If currently on an enemy or invalid box, jump immediately to the nearest eligible box
      nextIdx = direction === 'left' ? 0 : eligibleBoxes.length - 1;
    } else if (direction === 'left') {
      nextIdx = Math.max(0, currentIdx - 1);
    } else {
      nextIdx = Math.min(eligibleBoxes.length - 1, currentIdx + 1);
    }

    if (nextIdx === currentIdx && currentIdx !== -1) {
      const edge = direction === 'left' ? '最左' : '最右';
      this.statusMessage = `${targetTeam === 'red' ? '赤' : '青'}チームの${edge}ボックスです [ボックス ${this.currentBox}]`;
      this.notifyState();
      return;
    }

    this.currentBox = eligibleBoxes[nextIdx].boxNumber;
    this.activeThrowParams.startX = BocciaRules.getBoxCenterCoord(this.currentBox);

    // Update active ball mesh & physics body position
    const body = this.physics.getBall(this.activeBallId!);
    if (body) {
      body.position.set(this.activeThrowParams.startX, 0.08, 2.1);
      body.velocity.set(0, 0, 0);
      body.angularVelocity.set(0, 0, 0);
    }
    this.ballManager.updateFromPhysics(
      this.activeBallId!,
      { x: this.activeThrowParams.startX, y: 0.08, z: 2.1 },
      { x: 0, y: 0, z: 0, w: 1 }
    );

    sound.playClick();
    this.updateBoxHighlight();
    if (this.cameraPreset === 'throw') {
      this.setCameraPreset('throw');
    }
    this.updateAimVisuals();

    const box = this.boxes.find((b) => b.boxNumber === this.currentBox);
    if (box) {
      this.statusMessage = `ボックス ${this.currentBox} [${box.playerLabel}]: 残り${box.ballsLeft}球（←+→ で決定）`;
    }

    this.notifyState();
  }

  /**
   * Toggle box selection (lock / unlock) triggered by simultaneous Left + Right keys
   */
  public toggleBoxSelection() {
    if (this.phase !== 'aiming' || this.isAiTurn()) return;

    if (this.isBoxLocked) {
      // Unlock
      this.isBoxLocked = false;
      sound.playClick();
      this.updateBoxHighlight();
      this.statusMessage = `ボックス ${this.currentBox} の選択を解除しました。← → で移動し、←+→ 同時押しで再決定してください`;
      this.notifyState();
      return;
    }

    // Attempt to lock
    if (this.currentTeam === 'jack') {
      const schedule = BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd);
      if (this.currentBox !== schedule.boxNumber) {
        this.statusMessage = `第${this.currentEnd}エンドのジャック投球は公式ルールによりボックス ${schedule.boxNumber} から行います`;
        this.currentBox = schedule.boxNumber;
        this.activeThrowParams.startX = BocciaRules.getBoxCenterCoord(this.currentBox);
        const body = this.physics.getBall(this.activeBallId!);
        if (body) {
          body.position.set(this.activeThrowParams.startX, 0.08, 2.1);
          body.velocity.set(0, 0, 0);
        }
      }
      this.isBoxLocked = true;
      sound.playThrow(0.4);
      this.updateBoxHighlight();
      this.statusMessage = `ボックス ${this.currentBox} 決定！ジャックボール（白球）を投球してください`;
      this.notifyState();
      return;
    }

    // Colored ball validation
    const box = this.boxes.find((b) => b.boxNumber === this.currentBox);
    if (!box || box.team !== this.currentTeam || box.ballsLeft <= 0) {
      const validBoxes = this.boxes
        .filter((b) => b.team === this.currentTeam && b.ballsLeft > 0)
        .map((b) => b.boxNumber);
      this.statusMessage = `このボックスは選択できません。${
        this.currentTeam === 'red' ? '赤' : '青'
      }チームの有効ボックス（${validBoxes.join(', ')}）を選択してください`;
      this.notifyState();
      return;
    }

    // Lock in!
    this.isBoxLocked = true;
    sound.playThrow(0.4);
    this.updateBoxHighlight();
    this.statusMessage = `ボックス ${this.currentBox} [${box.playerLabel}] 決定！Enter または投球ボタンでスロー`;

    // Ensure active ball is assigned from this box
    const unthrownBallId = box.ballIds.find((id) => {
      const b = [...this.redBallsState, ...this.blueBallsState].find((x) => x.id === id);
      return b && !b.thrown;
    });
    if (unthrownBallId && unthrownBallId !== this.activeBallId) {
      this.activeBallId = unthrownBallId;
      this.spawnActiveBallMesh();
    }

    this.notifyState();
  }

  /**
   * Direct box selection (e.g. from UI buttons)
   */
  public selectBoxDirectly(boxNumber: number) {
    if (this.phase !== 'aiming' || this.isAiTurn()) return;

    const targetTeam =
      this.currentTeam === 'jack'
        ? BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd).team
        : this.currentTeam;

    const targetBox = this.boxes.find((b) => b.boxNumber === boxNumber);
    if (!targetBox || targetBox.team !== targetTeam || targetBox.ballsTotal === 0) {
      sound.playError();
      this.statusMessage = `${targetTeam === 'red' ? '赤' : '青'}チームの有効ボックスのみ選択できます`;
      this.notifyState();
      return;
    }
    if (this.currentTeam !== 'jack' && targetBox.ballsLeft <= 0) {
      sound.playError();
      this.statusMessage = `ボックス ${boxNumber} の球は投げ終わりました`;
      this.notifyState();
      return;
    }

    this.isBoxLocked = false;
    this.currentBox = Math.max(1, Math.min(6, boxNumber));
    this.activeThrowParams.startX = BocciaRules.getBoxCenterCoord(this.currentBox);

    const body = this.physics.getBall(this.activeBallId!);
    if (body) {
      body.position.set(this.activeThrowParams.startX, 0.08, 2.1);
      body.velocity.set(0, 0, 0);
    }
    this.ballManager.updateFromPhysics(
      this.activeBallId!,
      { x: this.activeThrowParams.startX, y: 0.08, z: 2.1 },
      { x: 0, y: 0, z: 0, w: 1 }
    );

    this.updateBoxHighlight();
    if (this.cameraPreset === 'throw') {
      this.setCameraPreset('throw');
    }
    this.updateAimVisuals();
    this.toggleBoxSelection();
  }

  /**
   * Initialize or reset an End
   */
  public resetRound() {
    this.physics.clearAllBalls();
    this.ballManager.clearAll();

    if (this.aiTimeout1) window.clearTimeout(this.aiTimeout1);
    if (this.aiTimeout2) window.clearTimeout(this.aiTimeout2);
    this.isAiThinking = false;

    this.currentRoundScore = null;
    this.phase = 'aiming';
    this.currentTeam = 'jack';
    this.activeBallId = 'jack';

    // Set up boxes and ball allocations
    this.setupBoxesForMode();

    // Determine Jack thrower for current end
    const jackSchedule = BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd);
    this.currentJackTeam = jackSchedule.team;
    this.currentBox = jackSchedule.boxNumber;
    this.isBoxLocked = false;

    const startX = BocciaRules.getBoxCenterCoord(this.currentBox);
    this.activeThrowParams = {
      angle: 0,
      power: 0.52,
      loft: 0,
      spin: 0,
      startX
    };

    // Initialize ball records
    this.jackState = {
      id: 'jack',
      type: 'jack',
      index: 0,
      thrown: false,
      x: startX,
      y: 0.08,
      z: 2.1,
      inBounds: true,
      distanceToJack: 0
    };

    this.redBallsState = [];
    for (let i = 1; i <= 6; i++) {
      this.redBallsState.push({
        id: `red_${i}`,
        type: 'red',
        index: i,
        thrown: false,
        x: startX,
        y: 0.08,
        z: 2.1,
        inBounds: true,
        distanceToJack: 0
      });
    }

    this.blueBallsState = [];
    for (let i = 1; i <= 6; i++) {
      this.blueBallsState.push({
        id: `blue_${i}`,
        type: 'blue',
        index: i,
        thrown: false,
        x: startX,
        y: 0.08,
        z: 2.1,
        inBounds: true,
        distanceToJack: 0
      });
    }

    const teamLabel = jackSchedule.team === 'red' ? '赤チーム' : '青チーム';
    this.statusMessage = `第${this.currentEnd}エンド開始：${teamLabel}（ボックス ${this.currentBox}）がジャックボールを投球します`;

    this.updateBoxHighlight();
    this.spawnActiveBallMesh();
    this.setCameraPreset('throw');
    this.updateAimVisuals();
    this.notifyState();

    if (this.isAiTurn()) {
      this.triggerAiTurn();
    }
  }

  /**
   * Spawns the active ball mesh in throwing position
   */
  private spawnActiveBallMesh() {
    if (!this.activeBallId) return;

    const ballType = this.currentTeam === 'jack' ? 'jack' : this.currentTeam;
    const startX = BocciaRules.getBoxCenterCoord(this.currentBox);
    this.activeThrowParams.startX = startX;

    // Check if ball mesh already created
    if (!this.ballManager.getBallMesh(this.activeBallId)) {
      this.ballManager.createBallMesh(this.activeBallId, ballType, 1);
    }

    // Add to physics
    this.physics.addBall(this.activeBallId, { x: startX, y: 0.08, z: 2.1 });
    this.ballManager.updateFromPhysics(
      this.activeBallId,
      { x: startX, y: 0.08, z: 2.1 },
      { x: 0, y: 0, z: 0, w: 1 }
    );
  }

  /**
   * Update aim guide line and marker
   */
  public updateAimVisuals() {
    if (this.phase !== 'aiming' || !this.activeBallId) {
      this.ballManager.updateAimGuide({ x: 0, y: 0, z: 0 }, { x: 0, z: 1 }, 0, false);
      return;
    }

    const startX = this.activeThrowParams.startX;
    const angle = this.activeThrowParams.angle;
    // In Three.js looking towards +Z, screen right is -X and screen left is +X
    // Positive angle (turning right) corresponds to negative X velocity
    const dir = {
      x: -Math.sin(angle),
      z: Math.cos(angle)
    };

    this.ballManager.updateAimGuide(
      { x: startX, y: 0.08, z: 2.1 },
      dir,
      this.activeThrowParams.power,
      true
    );
  }

  /**
   * Player or AI sets throw angle (-40° to +40°, -MAX_AIM_ANGLE to +MAX_AIM_ANGLE)
   */
  public setAimAngle(angle: number) {
    if (this.phase !== 'aiming') return;
    this.activeThrowParams.angle = Math.max(-MAX_AIM_ANGLE, Math.min(MAX_AIM_ANGLE, angle));
    this.updateAimVisuals();
    this.notifyState();
  }

  /**
   * Player or AI sets throw power (0.1 to 1.0)
   */
  public setAimPower(power: number) {
    if (this.phase !== 'aiming') return;
    this.activeThrowParams.power = Math.max(0.1, Math.min(1.0, power));
    this.updateAimVisuals();
    this.notifyState();
  }

  /**
   * Player sets spin (-1 to +1)
   */
  public setAimSpin(spin: number) {
    if (this.phase !== 'aiming') return;
    this.activeThrowParams.spin = Math.max(-1, Math.min(1, spin));
    this.notifyState();
  }

  /**
   * Player sets loft / throw height
   */
  public setAimLoft(loft: number) {
    if (this.phase !== 'aiming') return;
    this.activeThrowParams.loft = Math.max(0, Math.min(0.3, loft));
    this.notifyState();
  }

  /**
   * Shift lateral release position within throwing box
   */
  public setThrowStartX(xOffset: number) {
    if (this.phase !== 'aiming') return;
    const baseBoxX = this.currentTeam === 'blue' ? -0.5 : 0.5;
    this.activeThrowParams.startX = baseBoxX + Math.max(-0.35, Math.min(0.35, xOffset));
    const body = this.physics.getBall(this.activeBallId!);
    if (body) {
      body.position.set(this.activeThrowParams.startX, 0.08, 2.1);
      body.velocity.set(0, 0, 0);
    }
    this.updateAimVisuals();
    this.notifyState();
  }

  /**
   * Execute throw
   */
  public executeThrow() {
    if (this.phase !== 'aiming' || !this.activeBallId) return;

    if (this.aiTimeout1) window.clearTimeout(this.aiTimeout1);
    if (this.aiTimeout2) window.clearTimeout(this.aiTimeout2);
    this.isAiThinking = false;

    // Auto-confirm box if not locked
    if (!this.isBoxLocked) {
      this.isBoxLocked = true;
      this.updateBoxHighlight();
    }

    // Deduct ball count from throwing box
    if (this.activeBallId !== 'jack') {
      const box = this.boxes.find((b) => b.boxNumber === this.currentBox);
      if (box && box.ballsLeft > 0) {
        box.ballsLeft--;
      }
    }

    this.phase = 'throwing';
    this.ballManager.updateAimGuide({ x: 0, y: 0, z: 0 }, { x: 0, z: 1 }, 0, false);

    // In Three.js looking towards +Z, screen right is -X
    const dir = {
      x: -Math.sin(this.activeThrowParams.angle),
      z: Math.cos(this.activeThrowParams.angle)
    };

    // Play throw swoosh
    sound.playThrow(this.activeThrowParams.power);

    // Apply physics impulse
    this.physics.applyThrow(
      this.activeBallId,
      dir,
      this.activeThrowParams.power,
      this.activeThrowParams.loft,
      this.activeThrowParams.spin
    );

    // Mark ball as thrown
    if (this.activeBallId === 'jack') {
      this.jackState.thrown = true;
    } else {
      const b = [...this.redBallsState, ...this.blueBallsState].find((x) => x.id === this.activeBallId);
      if (b) b.thrown = true;
    }

    // Camera switches to follow thrown ball
    this.followingBallId = this.activeBallId;
    this.phase = 'rolling';
    this.rollCheckCount = 0;
    this.statusMessage = '投球中... ボールが停止するのを待っています';
    this.notifyState();

    // Start checking for physics settlement
    if (this.rollingTimeoutId) window.clearTimeout(this.rollingTimeoutId);
    this.scheduleRollCheck();
  }

  private scheduleRollCheck() {
    this.rollingTimeoutId = window.setTimeout(() => {
      this.checkRollingSettlement();
    }, 400);
  }

  private checkRollingSettlement() {
    if (this.phase !== 'rolling') return;

    this.rollCheckCount++;
    const isMoving = this.physics.isAnythingMoving(0.035);

    // Give at least 1.5 seconds, and maximum 7 seconds before forcing stop
    if (isMoving && this.rollCheckCount < 18) {
      this.scheduleRollCheck();
      return;
    }

    // Balls have stopped rolling!
    this.onBallsSettled();
  }

  /**
   * Called once all balls on court have stopped
   */
  private onBallsSettled() {
    this.followingBallId = null;

    // 1. Update ball positions and boundary checks
    this.syncBallStatesFromPhysics();

    // 2. If it was the Jack ball throw, check V-line validity
    if (this.activeBallId === 'jack') {
      const isValid = BocciaRules.isJackPastVLine(this.jackState.x, this.jackState.z);
      if (!isValid) {
        // Jack didn't reach valid area: place on Center Cross (+) as per Boccia regulation
        this.statusMessage = 'ジャックボールがVライン未到達のため、中央クロス(+)に配置されました';
        const crossBody = this.physics.getBall('jack');
        if (crossBody) {
          crossBody.position.set(BocciaRules.CROSS_X, 0.08, BocciaRules.CROSS_Z);
          crossBody.velocity.set(0, 0, 0);
          crossBody.angularVelocity.set(0, 0, 0);
        }
        this.jackState.x = BocciaRules.CROSS_X;
        this.jackState.z = BocciaRules.CROSS_Z;
        this.jackState.inBounds = true;
      } else {
        this.statusMessage = 'ナイススロー！ジャックボールが有効エリアに配置されました';
      }
    } else {
      // Colored ball check
      const ball = [...this.redBallsState, ...this.blueBallsState].find((b) => b.id === this.activeBallId);
      if (ball && !ball.inBounds) {
        this.statusMessage = `${ball.type === 'red' ? '赤' : '青'}ボールがコート外に出ました（アウト）`;
      }
    }

    // 3. Determine next turn
    const turnResult = BocciaRules.getNextTurn(
      this.jackState,
      this.redBallsState,
      this.blueBallsState,
      this.currentJackTeam
    );

    if (turnResult.isEndOver) {
      // All 12 balls thrown: End scoring!
      this.handleEndOver();
    } else {
      // Next turn
      this.currentTeam = turnResult.nextTeam;
      this.activeBallId = turnResult.nextBallId;
      this.phase = 'aiming';

      // Determine available boxes for this team that have balls remaining
      const availableBoxes = this.boxes.filter(
        (b) => b.team === this.currentTeam && b.ballsLeft > 0
      );

      // Preserve currentBox if it belongs to currentTeam and has balls, otherwise pick first available
      if (availableBoxes.length > 0) {
        const isCurrentValid = availableBoxes.some((b) => b.boxNumber === this.currentBox);
        if (!isCurrentValid) {
          this.currentBox = availableBoxes[0].boxNumber;
        }
      }

      this.isBoxLocked = false;
      this.activeThrowParams.startX = BocciaRules.getBoxCenterCoord(this.currentBox);
      this.activeThrowParams.angle = 0;
      this.activeThrowParams.spin = 0;

      // Spawn ball mesh
      this.spawnActiveBallMesh();

      // Switch to Throw view
      this.updateBoxHighlight();
      this.setCameraPreset('throw');
      this.updateAimVisuals();

      // Team prompt
      const teamName = this.currentTeam === 'red' ? '赤チーム' : '青チーム';
      const box = this.boxes.find((b) => b.boxNumber === this.currentBox);
      const boxLabel = box ? `[ボックス ${this.currentBox}: ${box.playerLabel}]` : `[ボックス ${this.currentBox}]`;
      this.statusMessage = `${teamName}のターンです ${boxLabel}（← → でボックス移動、←+→ 同時押しで決定）`;
      this.notifyState();

      // If AI turn, trigger AI thinking & throw
      this.isAiThinking = false;
      if (this.isAiTurn()) {
        this.triggerAiTurn();
      }
    }
  }

  private syncBallStatesFromPhysics() {
    const jackBody = this.physics.getBall('jack');
    if (jackBody) {
      this.jackState.x = jackBody.position.x;
      this.jackState.y = jackBody.position.y;
      this.jackState.z = jackBody.position.z;
      this.jackState.inBounds = BocciaRules.isPositionInBounds(jackBody.position.x, jackBody.position.z);
    }

    this.redBallsState.forEach((b) => {
      const body = this.physics.getBall(b.id);
      if (body) {
        b.x = body.position.x;
        b.y = body.position.y;
        b.z = body.position.z;
        b.inBounds = BocciaRules.isPositionInBounds(body.position.x, body.position.z);
        b.distanceToJack = BocciaRules.getDistance(this.jackState.x, this.jackState.z, b.x, b.z);
      }
    });

    this.blueBallsState.forEach((b) => {
      const body = this.physics.getBall(b.id);
      if (body) {
        b.x = body.position.x;
        b.y = body.position.y;
        b.z = body.position.z;
        b.inBounds = BocciaRules.isPositionInBounds(body.position.x, body.position.z);
        b.distanceToJack = BocciaRules.getDistance(this.jackState.x, this.jackState.z, b.x, b.z);
      }
    });
  }

  /**
   * AI Player automatically thinks and throws
   */
  private triggerAiTurn() {
    if (this.aiTimeout1) window.clearTimeout(this.aiTimeout1);
    if (this.aiTimeout2) window.clearTimeout(this.aiTimeout2);
    this.isAiThinking = true;

    // AI selects box:
    if (this.currentTeam === 'jack') {
      const schedule = BocciaRules.getJackThrowSchedule(this.mode, this.currentEnd);
      this.currentBox = schedule.boxNumber;
    } else {
      // Pick available AI box (Blue) with balls remaining
      const aiBoxes = this.boxes.filter((b) => b.team === 'blue' && b.ballsLeft > 0);
      if (aiBoxes.length > 0) {
        const hasCurrentBalls = aiBoxes.some((b) => b.boxNumber === this.currentBox);
        if (!hasCurrentBalls) {
          this.currentBox = aiBoxes[0].boxNumber;
        }
      }
    }

    this.isBoxLocked = true;
    this.activeThrowParams.startX = BocciaRules.getBoxCenterCoord(this.currentBox);
    this.updateBoxHighlight();

    const body = this.physics.getBall(this.activeBallId!);
    if (body) {
      body.position.set(this.activeThrowParams.startX, 0.08, 2.1);
      body.velocity.set(0, 0, 0);
    }
    this.ballManager.updateFromPhysics(
      this.activeBallId!,
      { x: this.activeThrowParams.startX, y: 0.08, z: 2.1 },
      { x: 0, y: 0, z: 0, w: 1 }
    );
    if (this.cameraPreset === 'throw') {
      this.setCameraPreset('throw');
    }

    this.statusMessage = `🤖 PC（青チーム ボックス ${this.currentBox}）が戦略を思考中...`;
    this.notifyState();

    this.aiTimeout1 = window.setTimeout(() => {
      if (this.phase !== 'aiming' || !this.isAiTurn()) {
        this.isAiThinking = false;
        return;
      }

      const allBalls = [...this.redBallsState, ...this.blueBallsState];
      const aiParams = BocciaAI.calculateThrow(
        { x: this.activeThrowParams.startX, z: 2.1 },
        this.jackState,
        allBalls,
        this.difficulty
      );

      this.activeThrowParams = { ...aiParams };
      this.updateAimVisuals();
      this.statusMessage = `🤖 PC（青チーム ボックス ${this.currentBox}）が照準・パワーを決定しました！`;
      this.notifyState();

      // Brief aiming pause before throw execution
      this.aiTimeout2 = window.setTimeout(() => {
        this.isAiThinking = false;
        if (this.phase === 'aiming' && this.isAiTurn()) {
          this.executeThrow();
        }
      }, 500);
    }, 650);
  }

  /**
   * End scoring completion
   */
  private handleEndOver() {
    this.phase = 'end_scoring';
    sound.playWhistle();

    // Calculate score
    const score = BocciaRules.calculateEndScore(this.jackState, this.redBallsState, this.blueBallsState);
    this.currentRoundScore = score;

    // Update match scores
    this.matchScores.red += score.redScore;
    this.matchScores.blue += score.blueScore;

    // Play fanfare
    sound.playScoreFanfare(score.points);

    // Switch to top-down view to show measurement rings and laser lines
    this.setCameraPreset('jack_topdown');
    this.showMeasurementOverlay(true);

    if (score.winner === 'tie') {
      this.statusMessage = '同点！このエンドは両チーム0点です';
    } else {
      const winnerName = score.winner === 'red' ? '赤チーム' : '青チーム';
      this.statusMessage = `${winnerName}が ${score.points} 点を獲得しました！`;
    }

    this.notifyState();
  }

  /**
   * Next end transition or finish match
   */
  public nextEndOrFinish() {
    if (this.currentEnd >= this.totalEnds) {
      // Match Over!
      this.phase = 'match_over';
      this.notifyState();
    } else {
      this.currentEnd++;
      this.resetRound();
    }
  }

  /**
   * Set game configuration and start fresh match
   */
  public startNewMatch(mode: GameMode, difficulty: AIDifficulty, totalEnds?: number) {
    this.mode = mode;
    this.difficulty = difficulty;
    if (totalEnds !== undefined && totalEnds > 0) {
      this.totalEnds = totalEnds;
    } else {
      // Official match regulations: Team is 6 ends, Solo & Pairs are 4 ends
      this.totalEnds = (mode === 'team_ai' || mode === 'team_pvp') ? 6 : 4;
    }
    this.currentEnd = 1;
    this.matchScores = { red: 0, blue: 0 };
    this.resetRound();
  }

  /**
   * Camera Presets
   */
  public setCameraPreset(preset: CameraPreset) {
    this.cameraPreset = preset;
    this.controls.enabled = preset === 'free_orbit';

    const jackX = this.jackState.thrown ? this.jackState.x : 0;
    const jackZ = this.jackState.thrown ? this.jackState.z : 7.5;

    switch (preset) {
      case 'throw': {
        const boxX = this.activeThrowParams.startX;
        // Frame all throwing boxes comfortably in lower screen with elevated angle
        this.targetCameraPos.set(boxX * 0.45, 1.95, -1.35);
        this.targetCameraLookAt.set(boxX * 0.35 + jackX * 0.25, 0.15, Math.max(jackZ, 5.8));
        break;
      }
      case 'jack_topdown': {
        // Direct referee top-down inspection view
        // Position camera slightly on the thrower side (jackZ - 0.05) so +Z (far end) remains UP on screen
        this.targetCameraPos.set(jackX, 6.5, jackZ - 0.05);
        this.targetCameraLookAt.set(jackX, 0, jackZ);
        break;
      }
      case 'court_overview': {
        this.targetCameraPos.set(0, 8.5, 0.2);
        this.targetCameraLookAt.set(0, 0, 7.0);
        break;
      }
      case 'free_orbit': {
        // Orbit around jack or court center
        this.controls.target.set(jackX, 0.2, jackZ);
        break;
      }
    }

    this.notifyState();
  }

  /**
   * Toggle measurement overlay
   */
  public showMeasurementOverlay(show: boolean) {
    if (!this.jackState.thrown) {
      this.ballManager.updateMeasurementOverlay(null, [], false);
      return;
    }

    const activeBalls: { id: string; type: 'red' | 'blue'; x: number; z: number; dist: number; scoresPoint: boolean }[] = [];
    this.redBallsState.forEach((b) => {
      if (b.thrown && b.inBounds) {
        const scores = !!this.currentRoundScore?.ballRankings.find((r) => r.ballId === b.id && r.scoresPoint);
        activeBalls.push({ id: b.id, type: 'red', x: b.x, z: b.z, dist: b.distanceToJack, scoresPoint: scores });
      }
    });

    this.blueBallsState.forEach((b) => {
      if (b.thrown && b.inBounds) {
        const scores = !!this.currentRoundScore?.ballRankings.find((r) => r.ballId === b.id && r.scoresPoint);
        activeBalls.push({ id: b.id, type: 'blue', x: b.x, z: b.z, dist: b.distanceToJack, scoresPoint: scores });
      }
    });

    let scoringRadius = 0;
    if (this.currentRoundScore && this.currentRoundScore.winner && this.currentRoundScore.winner !== 'tie') {
      const winner = this.currentRoundScore.winner;
      const loserType = winner === 'red' ? 'blue' : 'red';
      const opponentRanking = this.currentRoundScore.ballRankings.find(r => r.type === loserType);
      if (opponentRanking) {
        scoringRadius = opponentRanking.distance;
      } else {
        // All balls on court belong to winner
        const lastScoring = this.currentRoundScore.ballRankings.filter(r => r.scoresPoint).pop();
        if (lastScoring) scoringRadius = lastScoring.distance + 0.15;
      }
    }

    this.ballManager.updateMeasurementOverlay(
      { x: this.jackState.x, y: 0.08, z: this.jackState.z },
      activeBalls,
      show,
      scoringRadius
    );
  }

  /**
   * Main game animation loop
   */
  private startLoop() {
    const tick = () => {
      if (this.isDisposed) return;

      const rawDt = this.clock.getDelta();
      const dt = Math.min(rawDt, 0.05);

      // 1. Step physics
      this.physics.step(dt);

      // 2. Synchronize ball meshes
      if (this.jackState.thrown || this.activeBallId === 'jack') {
        const body = this.physics.getBall('jack');
        if (body) {
          this.ballManager.updateFromPhysics('jack', body.position, body.quaternion);
        }
      }

      this.redBallsState.forEach((b) => {
        if (b.thrown || b.id === this.activeBallId) {
          const body = this.physics.getBall(b.id);
          if (body) {
            this.ballManager.updateFromPhysics(b.id, body.position, body.quaternion);
          }
        }
      });

      this.blueBallsState.forEach((b) => {
        if (b.thrown || b.id === this.activeBallId) {
          const body = this.physics.getBall(b.id);
          if (body) {
            this.ballManager.updateFromPhysics(b.id, body.position, body.quaternion);
          }
        }
      });

      // 3. Camera kinematics & tracking
      if (this.phase === 'rolling' && this.followingBallId) {
        const followBody = this.physics.getBall(this.followingBallId);
        if (followBody) {
          // Smooth dynamic chase camera behind the ball
          const targetCamX = followBody.position.x * 0.7;
          const targetCamZ = followBody.position.z - 1.8;
          const targetCamY = 1.1;

          this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, targetCamX, 6.0, dt);
          this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, targetCamY, 6.0, dt);
          this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, targetCamZ, 6.0, dt);

          this.currentLookAt.x = THREE.MathUtils.damp(this.currentLookAt.x, followBody.position.x, 8.0, dt);
          this.currentLookAt.y = THREE.MathUtils.damp(this.currentLookAt.y, followBody.position.y + 0.1, 8.0, dt);
          this.currentLookAt.z = THREE.MathUtils.damp(this.currentLookAt.z, followBody.position.z + 1.2, 8.0, dt);
          this.camera.lookAt(this.currentLookAt);
        }
      } else if (this.cameraPreset !== 'free_orbit') {
        // Smooth exponential damping to preset camera positions
        this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, this.targetCameraPos.x, 5.0, dt);
        this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, this.targetCameraPos.y, 5.0, dt);
        this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, this.targetCameraPos.z, 5.0, dt);

        this.currentLookAt.x = THREE.MathUtils.damp(this.currentLookAt.x, this.targetCameraLookAt.x, 5.0, dt);
        this.currentLookAt.y = THREE.MathUtils.damp(this.currentLookAt.y, this.targetCameraLookAt.y, 5.0, dt);
        this.currentLookAt.z = THREE.MathUtils.damp(this.currentLookAt.z, this.targetCameraLookAt.z, 5.0, dt);
        this.camera.lookAt(this.currentLookAt);
      } else {
        // Free OrbitControls
        this.controls.update();
      }

      // 4. Render
      this.renderer.render(this.scene, this.camera);

      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  public dispose() {
    this.isDisposed = true;
    cancelAnimationFrame(this.animFrameId);
    if (this.rollingTimeoutId) clearTimeout(this.rollingTimeoutId);
    window.removeEventListener('resize', this.onResize);
    this.controls.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
