/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Team, RoundScore } from './types';

export interface BallState {
  id: string;
  type: 'jack' | 'red' | 'blue';
  index: number;
  thrown: boolean;
  x: number;
  y: number;
  z: number;
  inBounds: boolean;
  distanceToJack: number;
}

export class BocciaRules {
  public static readonly COURT_MIN_X = -3.0;
  public static readonly COURT_MAX_X = 3.0;
  public static readonly COURT_MIN_Z = 0.0;
  public static readonly COURT_MAX_Z = 12.5;
  public static readonly THROW_LINE_Z = 2.5;
  public static readonly CROSS_X = 0.0;
  public static readonly CROSS_Z = 7.5;
  public static readonly V_LINE_TIP_Z = 4.2;

  /**
   * Check if position is inside the court boundary
   */
  public static isPositionInBounds(x: number, z: number): boolean {
    return (
      x >= this.COURT_MIN_X &&
      x <= this.COURT_MAX_X &&
      z >= this.COURT_MIN_Z &&
      z <= this.COURT_MAX_Z
    );
  }

  /**
   * Check if Jack ball is past the V-Line (valid target area)
   * The V-line apex is at x=0, z=3.0 and angles forward to z=4.3 at the sidelines (x=±3.0)
   */
  public static isJackPastVLine(x: number, z: number): boolean {
    const normX = Math.min(Math.abs(x) / 3.0, 1.0);
    const thresholdZ = 3.0 + normX * 1.3;
    return z >= thresholdZ && this.isPositionInBounds(x, z);
  }

  /**
   * Compute Euclidean distance in 2D/3D
   */
  public static getDistance(x1: number, z1: number, x2: number, z2: number): number {
    const dx = x1 - x2;
    const dz = z1 - z2;
    return Math.sqrt(dx * dx + dz * dz);
  }

  /**
   * Get world X coordinate for a throwing box (1 to 6)
   * Box 1: Left-most (+2.5m)
   * Box 6: Right-most (-2.5m)
   */
  public static getBoxCenterCoord(boxNumber: number): number {
    return 3.5 - Math.max(1, Math.min(6, boxNumber));
  }

  /**
   * Determine Jack throwing box and team for a given end in a match mode
   */
  public static getJackThrowSchedule(mode: string, endNumber: number): { boxNumber: number; team: Team } {
    if (mode === 'team_ai' || mode === 'team_pvp') {
      // 6 ends: Box 1 to 6 sequentially
      const box = ((endNumber - 1) % 6) + 1;
      const team: Team = box % 2 === 1 ? 'red' : 'blue';
      return { boxNumber: box, team };
    } else if (mode === 'pairs_ai' || mode === 'pairs_pvp') {
      // 4 ends: Boxes 2, 3, 4, 5
      const boxes = [2, 3, 4, 5];
      const box = boxes[(endNumber - 1) % 4];
      const team: Team = (box === 2 || box === 4) ? 'red' : 'blue';
      return { boxNumber: box, team };
    } else {
      // Solo: 4 ends: Box 3 (Red), Box 4 (Blue), Box 3 (Red), Box 4 (Blue)
      const isRed = (endNumber % 2) === 1;
      return { boxNumber: isRed ? 3 : 4, team: isRed ? 'red' : 'blue' };
    }
  }

  /**
   * Determine which team should throw next based on official Boccia rules:
   * 1. If Jack not thrown: Scheduled team throws Jack
   * 2. If Jack-throwing team has 0 thrown colored balls: that team throws 1st colored ball
   * 3. If opposing team has 0 thrown colored balls: opposing team throws 1st colored ball
   * 4. Otherwise: the team currently furthest from Jack throws next!
   *    If one team has no balls left, the team with balls remaining throws.
   */
  public static getNextTurn(
    jack: BallState,
    redBalls: BallState[],
    blueBalls: BallState[],
    jackTeam: Team = 'red'
  ): { nextTeam: Team | 'jack'; nextBallId: string | null; isEndOver: boolean } {
    const oppTeam: Team = jackTeam === 'red' ? 'blue' : 'red';
    const jackTeamBalls = jackTeam === 'red' ? redBalls : blueBalls;
    const oppTeamBalls = jackTeam === 'red' ? blueBalls : redBalls;

    // 1. Jack ball not thrown yet
    if (!jack.thrown) {
      return { nextTeam: 'jack', nextBallId: jack.id, isEndOver: false };
    }

    const redRemaining = redBalls.filter((b) => !b.thrown);
    const blueRemaining = blueBalls.filter((b) => !b.thrown);

    // End over if both teams have no balls left
    if (redRemaining.length === 0 && blueRemaining.length === 0) {
      return { nextTeam: 'red', nextBallId: null, isEndOver: true };
    }

    const jackTeamThrown = jackTeamBalls.filter((b) => b.thrown);
    const oppTeamThrown = oppTeamBalls.filter((b) => b.thrown);
    const jackTeamRemaining = jackTeamBalls.filter((b) => !b.thrown);
    const oppTeamRemaining = oppTeamBalls.filter((b) => !b.thrown);

    // 2. The team that threw the Jack throws the 1st colored ball
    if (jackTeamThrown.length === 0 && jackTeamRemaining.length > 0) {
      return { nextTeam: jackTeam, nextBallId: jackTeamRemaining[0].id, isEndOver: false };
    }

    // 3. The opposing team throws their 1st colored ball
    if (oppTeamThrown.length === 0 && oppTeamRemaining.length > 0) {
      return { nextTeam: oppTeam, nextBallId: oppTeamRemaining[0].id, isEndOver: false };
    }

    // If one team has exhausted all balls, the other team continues throwing
    if (redRemaining.length === 0) {
      return { nextTeam: 'blue', nextBallId: blueRemaining[0].id, isEndOver: false };
    }
    if (blueRemaining.length === 0) {
      return { nextTeam: 'red', nextBallId: redRemaining[0].id, isEndOver: false };
    }

    // Both teams have thrown at least 1 ball and have balls remaining:
    // Furthest team from Jack throws!
    const redThrown = redBalls.filter((b) => b.thrown);
    const blueThrown = blueBalls.filter((b) => b.thrown);

    let minRedDist = Infinity;
    redThrown.forEach((b) => {
      if (b.inBounds) {
        const d = this.getDistance(jack.x, jack.z, b.x, b.z);
        if (d < minRedDist) minRedDist = d;
      }
    });

    let minBlueDist = Infinity;
    blueThrown.forEach((b) => {
      if (b.inBounds) {
        const d = this.getDistance(jack.x, jack.z, b.x, b.z);
        if (d < minBlueDist) minBlueDist = d;
      }
    });

    // Furthest throws!
    if (minRedDist < minBlueDist) {
      return { nextTeam: 'blue', nextBallId: blueRemaining[0].id, isEndOver: false };
    } else {
      return { nextTeam: 'red', nextBallId: redRemaining[0].id, isEndOver: false };
    }
  }

  /**
   * Score an End according to official Boccia rules:
   * - Team closest to Jack wins the end.
   * - Winning team receives 1 point for each of their balls closer to Jack
   *   than the closest ball of the losing team.
   */
  public static calculateEndScore(
    jack: BallState,
    redBalls: BallState[],
    blueBalls: BallState[]
  ): RoundScore {
    const activeBalls: { id: string; type: 'red' | 'blue'; distance: number }[] = [];

    redBalls.forEach((b) => {
      if (b.thrown && b.inBounds) {
        const d = this.getDistance(jack.x, jack.z, b.x, b.z);
        activeBalls.push({ id: b.id, type: 'red', distance: d });
      }
    });

    blueBalls.forEach((b) => {
      if (b.thrown && b.inBounds) {
        const d = this.getDistance(jack.x, jack.z, b.x, b.z);
        activeBalls.push({ id: b.id, type: 'blue', distance: d });
      }
    });

    // Sort by distance ascending
    activeBalls.sort((a, b) => a.distance - b.distance);

    if (activeBalls.length === 0) {
      return {
        winner: 'tie',
        points: 0,
        redScore: 0,
        blueScore: 0,
        ballRankings: []
      };
    }

    const winnerType = activeBalls[0].type;
    // Find closest opponent ball
    const opponentBall = activeBalls.find((b) => b.type !== winnerType);
    const opponentMinDist = opponentBall ? opponentBall.distance : Infinity;

    // Count points for balls closer than opponent's closest ball
    let points = 0;
    const rankings = activeBalls.map((b) => {
      const scores = b.type === winnerType && b.distance < opponentMinDist;
      if (scores) points++;
      return {
        ballId: b.id,
        type: b.type,
        distance: b.distance,
        scoresPoint: scores
      };
    });

    return {
      winner: winnerType,
      points,
      redScore: winnerType === 'red' ? points : 0,
      blueScore: winnerType === 'blue' ? points : 0,
      ballRankings: rankings
    };
  }
}
