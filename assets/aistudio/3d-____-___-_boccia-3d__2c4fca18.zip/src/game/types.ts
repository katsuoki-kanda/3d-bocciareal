/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Team = 'red' | 'blue';

export type GamePhase =
  | 'title'
  | 'aiming'
  | 'throwing'
  | 'rolling'
  | 'end_scoring'
  | 'match_over';

export type GameMode =
  | 'solo_ai'     // 1人プレイ（vs AI）
  | 'pairs_ai'    // ペアプレイ（vs AI）
  | 'team_ai'     // チームプレイ（vs AI）
  | 'solo_pvp'    // 1人対戦（赤 vs 青）
  | 'pairs_pvp'   // ペア対戦（赤 vs 青）
  | 'team_pvp'    // チーム対戦（赤 vs 青）
  // Legacy aliases
  | 'vs_ai'
  | 'pass_and_play';

export type AIDifficulty = 'easy' | 'medium' | 'hard';

export interface BoxInfo {
  boxNumber: number; // 1 to 6
  team: Team;
  playerLabel: string; // e.g. "赤1", "青1"
  ballsTotal: number;
  ballsLeft: number;
  ballIds: string[];
  isAi: boolean;
}

export interface BallData {
  id: string;
  type: 'jack' | 'red' | 'blue';
  index: number; // 0 for jack, 1..6 for team balls
  thrown: boolean;
  inBounds: boolean;
  distanceToJack: number;
}

export const MAX_AIM_ANGLE = (40 * Math.PI) / 180; // 40 degrees in radians (~0.69813 rad)

export interface ThrowParams {
  angle: number; // horizontal angle in radians (-40° to +40°, -MAX_AIM_ANGLE to MAX_AIM_ANGLE)
  power: number; // 0.1 to 1.0 (translates to impulse 1.5 to 9.5 m/s)
  loft: number; // 0.0 (low flat roll) to 0.4 (gentle lob over balls)
  spin: number; // -1 (hook left) to +1 (slice right)
  startX: number; // lateral release position in throwing box (-0.4 to 0.4)
}

export interface RoundScore {
  winner: Team | 'tie' | null;
  points: number;
  redScore: number;
  blueScore: number;
  ballRankings: {
    ballId: string;
    type: 'red' | 'blue';
    distance: number;
    scoresPoint: boolean;
  }[];
}

export type CameraPreset = 'throw' | 'jack_topdown' | 'court_overview' | 'free_orbit';
