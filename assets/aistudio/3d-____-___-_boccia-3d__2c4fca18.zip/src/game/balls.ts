/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { createBallTexture, createBallBumpMap } from './textures';
import { getCalibratedDist } from './ai';

export interface BallMeshEntry {
  id: string;
  type: 'jack' | 'red' | 'blue';
  index: number;
  mesh: THREE.Mesh;
  shadow: THREE.Mesh;
  radius: number;
}

export class BallManager {
  public group: THREE.Group;
  public balls: Map<string, BallMeshEntry> = new Map();
  public jackMaterial: THREE.MeshStandardMaterial;
  public redMaterial: THREE.MeshStandardMaterial;
  public blueMaterial: THREE.MeshStandardMaterial;
  public shadowMaterial: THREE.MeshBasicMaterial;

  // Aiming visualizer
  public aimLine: THREE.Line;
  public aimLineGeom: THREE.BufferGeometry;
  public aimTargetMarker: THREE.Mesh;

  // Referee measurement visualization (rings & lines)
  public measurementGroup: THREE.Group;
  private measureRings: THREE.LineSegments[];
  private measureLines: THREE.LineSegments | null = null;

  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'BallManager';

    const bumpMap = createBallBumpMap();

    // Jack Ball: Matte clean off-white leather
    const jackTex = createBallTexture('#f8fafc', '#94a3b8', 'JACK');
    this.jackMaterial = new THREE.MeshStandardMaterial({
      map: jackTex,
      bumpMap,
      bumpScale: 0.003,
      roughness: 0.65,
      metalness: 0.05
    });

    // Red Ball: Scarlet red leather
    const redTex = createBallTexture('#dc2626', '#fca5a5', 'RED');
    this.redMaterial = new THREE.MeshStandardMaterial({
      map: redTex,
      bumpMap,
      bumpScale: 0.003,
      roughness: 0.62,
      metalness: 0.05
    });

    // Blue Ball: Athletic royal blue leather
    const blueTex = createBallTexture('#2563eb', '#bfdbfe', 'BLUE');
    this.blueMaterial = new THREE.MeshStandardMaterial({
      map: blueTex,
      bumpMap,
      bumpScale: 0.003,
      roughness: 0.62,
      metalness: 0.05
    });

    // Contact shadow texture (soft radial gradient)
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sCtx = shadowCanvas.getContext('2d')!;
    const grad = sCtx.createRadialGradient(64, 64, 5, 64, 64, 60);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
    grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.25)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, 128, 128);

    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    this.shadowMaterial = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2
    });

    // Aim Trajectory Line
    this.aimLineGeom = new THREE.BufferGeometry();
    const maxPoints = 50;
    const positions = new Float32Array(maxPoints * 3);
    this.aimLineGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const aimMat = new THREE.LineDashedMaterial({
      color: 0xfacc15, // Golden yellow
      dashSize: 0.2,
      gapSize: 0.1,
      linewidth: 3
    });
    this.aimLine = new THREE.Line(this.aimLineGeom, aimMat);
    this.aimLine.computeLineDistances();
    this.aimLine.visible = false;
    this.group.add(this.aimLine);

    // Aim Target Ring Marker on floor
    const targetRingGeom = new THREE.RingGeometry(0.12, 0.18, 32);
    const targetRingMat = new THREE.MeshBasicMaterial({
      color: 0xfacc15,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.75,
      depthWrite: false
    });
    this.aimTargetMarker = new THREE.Mesh(targetRingGeom, targetRingMat);
    this.aimTargetMarker.rotation.x = -Math.PI / 2;
    this.aimTargetMarker.position.y = 0.005;
    this.aimTargetMarker.visible = false;
    this.group.add(this.aimTargetMarker);

    // Measurement Group
    this.measurementGroup = new THREE.Group();
    this.measurementGroup.visible = false;
    this.measureRings = [];
    this.createMeasurementRings();
    this.group.add(this.measurementGroup);
  }

  private createMeasurementRings() {
    const ringDistances = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0];
    const ringMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.4
    });

    ringDistances.forEach((dist) => {
      const segCount = 64;
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= segCount; i++) {
        const theta = (i / segCount) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta) * dist, 0.006, Math.sin(theta) * dist));
      }
      const geom = new THREE.BufferGeometry().setFromPoints(points);
      const ring = new THREE.LineSegments(geom, ringMat);
      this.measureRings.push(ring);
      this.measurementGroup.add(ring);
    });
  }

  public createBallMesh(id: string, type: 'jack' | 'red' | 'blue', index: number, radius: number = 0.08): BallMeshEntry {
    let mat = this.jackMaterial;
    if (type === 'red') mat = this.redMaterial;
    if (type === 'blue') mat = this.blueMaterial;

    const geom = new THREE.SphereGeometry(radius, 32, 24);
    const mesh = new THREE.Mesh(geom, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    // Contact shadow beneath ball
    const shadowGeom = new THREE.PlaneGeometry(radius * 3.2, radius * 3.2);
    const shadowMesh = new THREE.Mesh(shadowGeom, this.shadowMaterial);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.003;

    this.group.add(mesh);
    this.group.add(shadowMesh);

    const entry: BallMeshEntry = { id, type, index, mesh, shadow: shadowMesh, radius };
    this.balls.set(id, entry);
    return entry;
  }

  public getBallMesh(id: string): BallMeshEntry | undefined {
    return this.balls.get(id);
  }

  public removeBall(id: string) {
    const entry = this.balls.get(id);
    if (entry) {
      this.group.remove(entry.mesh);
      this.group.remove(entry.shadow);
      entry.mesh.geometry.dispose();
      entry.shadow.geometry.dispose();
      this.balls.delete(id);
    }
  }

  public clearAll() {
    this.balls.forEach((entry) => {
      this.group.remove(entry.mesh);
      this.group.remove(entry.shadow);
      entry.mesh.geometry.dispose();
      entry.shadow.geometry.dispose();
    });
    this.balls.clear();
    this.aimLine.visible = false;
    this.aimTargetMarker.visible = false;
    this.measurementGroup.visible = false;
  }

  /**
   * Sync 3D mesh position & orientation from Physics body
   */
  public updateFromPhysics(id: string, pos: { x: number; y: number; z: number }, quat: { x: number; y: number; z: number; w: number }) {
    const entry = this.balls.get(id);
    if (!entry) return;

    entry.mesh.position.set(pos.x, pos.y, pos.z);
    entry.mesh.quaternion.set(quat.x, quat.y, quat.z, quat.w);

    // Keep contact shadow glued to floor directly beneath ball
    entry.shadow.position.set(pos.x, 0.003, pos.z);
    // Scale down shadow if ball is airborne
    const heightAboveGround = Math.max(0, pos.y - entry.radius);
    const shadowScale = Math.max(0.2, 1.0 - heightAboveGround * 1.5);
    entry.shadow.scale.set(shadowScale, shadowScale, shadowScale);
    (entry.shadow.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.7 - heightAboveGround * 0.8);
  }

  /**
   * Update visual aim guide
   */
  public updateAimGuide(
    startPos: { x: number; y: number; z: number },
    dir: { x: number; z: number },
    power: number,
    visible: boolean
  ) {
    this.aimLine.visible = visible;
    this.aimTargetMarker.visible = visible;

    if (!visible) return;

    // Projected distance aligned with calibrated court physics
    const estimatedDist = getCalibratedDist(power);
    const endX = startPos.x + dir.x * estimatedDist;
    const endZ = startPos.z + dir.z * estimatedDist;

    const points: number[] = [];
    const segments = 24;
    for (let i = 0; i <= segments; i++) {
      const frac = i / segments;
      const x = startPos.x + (endX - startPos.x) * frac;
      const z = startPos.z + (endZ - startPos.z) * frac;
      const y = 0.008; // just above floor
      points.push(x, y, z);
    }

    const posAttr = this.aimLineGeom.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < points.length; i++) {
      posAttr.set([points[i]], i);
    }
    posAttr.needsUpdate = true;
    this.aimLine.computeLineDistances();

    // Position ring at estimated landing spot
    this.aimTargetMarker.position.set(endX, 0.005, endZ);
  }

  // Scoring Zone Circle elements
  private scoringZoneMesh: THREE.Mesh | null = null;
  private scoringZoneBorder: THREE.LineLoop | null = null;

  /**
   * Update referee distance measurement rings, connecting laser lines,
   * and the official Scoring Zone Circle (得点圏内サークル)
   */
  public updateMeasurementOverlay(
    jackPos: { x: number; y: number; z: number } | null,
    activeBalls: { id: string; type: 'red' | 'blue'; x: number; z: number; dist: number; scoresPoint: boolean }[],
    show: boolean,
    scoringRadius: number = 0
  ) {
    this.measurementGroup.visible = show;
    if (!show || !jackPos) return;

    // Center concentric rings on Jack
    this.measurementGroup.position.set(jackPos.x, 0, jackPos.z);

    // Clean previous line segments & scoring zone circle
    if (this.measureLines) {
      this.measurementGroup.remove(this.measureLines);
      this.measureLines.geometry.dispose();
      this.measureLines = null;
    }
    if (this.scoringZoneMesh) {
      this.measurementGroup.remove(this.scoringZoneMesh);
      this.scoringZoneMesh.geometry.dispose();
      this.scoringZoneMesh = null;
    }
    if (this.scoringZoneBorder) {
      this.measurementGroup.remove(this.scoringZoneBorder);
      this.scoringZoneBorder.geometry.dispose();
      this.scoringZoneBorder = null;
    }

    // 1. Render Official Scoring Zone Circle (得点圏内サークル) if there's a valid cutoff radius
    if (scoringRadius > 0.05) {
      const segCount = 64;
      const zoneGeom = new THREE.CircleGeometry(scoringRadius, segCount);
      const zoneMat = new THREE.MeshBasicMaterial({
        color: 0x22c55e,
        transparent: true,
        opacity: 0.22,
        side: THREE.DoubleSide,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -3,
        polygonOffsetUnits: -3
      });
      this.scoringZoneMesh = new THREE.Mesh(zoneGeom, zoneMat);
      this.scoringZoneMesh.rotation.x = -Math.PI / 2;
      this.scoringZoneMesh.position.y = 0.005;
      this.measurementGroup.add(this.scoringZoneMesh);

      // Scoring Zone Border Ring
      const borderPoints: THREE.Vector3[] = [];
      for (let i = 0; i <= segCount; i++) {
        const theta = (i / segCount) * Math.PI * 2;
        borderPoints.push(new THREE.Vector3(Math.cos(theta) * scoringRadius, 0.007, Math.sin(theta) * scoringRadius));
      }
      const borderGeom = new THREE.BufferGeometry().setFromPoints(borderPoints);
      const borderMat = new THREE.LineBasicMaterial({
        color: 0xfacc15, // Golden glowing boundary
        linewidth: 3,
        transparent: true,
        opacity: 0.95
      });
      this.scoringZoneBorder = new THREE.LineLoop(borderGeom, borderMat);
      this.measurementGroup.add(this.scoringZoneBorder);
    }

    // 2. Connect Jack to each ball with colored laser lines
    const linePoints: THREE.Vector3[] = [];
    const lineColors: number[] = [];

    activeBalls.forEach((b) => {
      // Vector from Jack to ball in local measurementGroup coords
      const localBallX = b.x - jackPos.x;
      const localBallZ = b.z - jackPos.z;

      linePoints.push(new THREE.Vector3(0, 0.01, 0));
      linePoints.push(new THREE.Vector3(localBallX, 0.01, localBallZ));

      const col = b.scoresPoint ? 0x22c55e : (b.type === 'red' ? 0xef4444 : 0x3b82f6);
      const c = new THREE.Color(col);
      lineColors.push(c.r, c.g, c.b);
      lineColors.push(c.r, c.g, c.b);
    });

    if (linePoints.length > 0) {
      const lineGeom = new THREE.BufferGeometry().setFromPoints(linePoints);
      lineGeom.setAttribute('color', new THREE.Float32BufferAttribute(lineColors, 3));
      const lineMat = new THREE.LineBasicMaterial({
        vertexColors: true,
        linewidth: 2,
        transparent: true,
        opacity: 0.85
      });
      this.measureLines = new THREE.LineSegments(lineGeom, lineMat);
      this.measurementGroup.add(this.measureLines);
    }
  }
}
