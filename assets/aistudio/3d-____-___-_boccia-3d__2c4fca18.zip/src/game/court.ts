/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { createCourtTexture, createSurroundTexture } from './textures';

export function createBocciaCourt(renderer: THREE.WebGLRenderer): THREE.Group {
  const courtGroup = new THREE.Group();
  courtGroup.name = 'BocciaCourt';

  const maxAniso = renderer.capabilities.getMaxAnisotropy();

  // 1. Regulation Boccia Court Plane (6m wide x 12.5m long)
  // Court starts at Z = 0 (back of throwing boxes) to Z = 12.5m (far end)
  // Center is at X = 0, Z = 6.25m
  const courtGeom = new THREE.PlaneGeometry(6.0, 12.5);
  const courtTex = createCourtTexture();
  courtTex.anisotropy = maxAniso;

  const courtMat = new THREE.MeshStandardMaterial({
    map: courtTex,
    roughness: 0.90, // Matte synthetic sports court (no blinding white specular glare)
    metalness: 0.0,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1
  });

  const courtMesh = new THREE.Mesh(courtGeom, courtMat);
  courtMesh.rotation.set(-Math.PI / 2, 0, Math.PI);
  // PlaneGeometry is centered at (0, 0), so center it at Z = 6.25
  courtMesh.position.set(0, 0.002, 6.25);
  courtMesh.receiveShadow = true;
  courtGroup.add(courtMesh);

  // 2. Gymnasium Polished Wood Surround Floor (22m x 28m)
  const surroundGeom = new THREE.PlaneGeometry(22, 28);
  const surroundTex = createSurroundTexture();
  surroundTex.anisotropy = maxAniso;

  const surroundMat = new THREE.MeshStandardMaterial({
    map: surroundTex,
    roughness: 0.45,
    metalness: 0.02
  });

  const surroundMesh = new THREE.Mesh(surroundGeom, surroundMat);
  surroundMesh.rotation.x = -Math.PI / 2;
  surroundMesh.position.set(0, 0, 6.25);
  surroundMesh.receiveShadow = true;
  courtGroup.add(surroundMesh);

  // 3. Court Perimeter Barrier (Low padded boundary boards around the playing area)
  const barrierGroup = new THREE.Group();
  const wallH = 0.35;
  const wallT = 0.12;

  const barrierWoodMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.5,
    metalness: 0.1
  });

  const barrierCapMat = new THREE.MeshStandardMaterial({
    color: 0x3b82f6, // subtle athletic blue trim
    roughness: 0.3,
    metalness: 0.1
  });

  // Helper for composite barrier board (wood base + rounded/capped top)
  const createBarrierSection = (length: number, isAlongZ: boolean) => {
    const section = new THREE.Group();
    const w = isAlongZ ? wallT : length;
    const d = isAlongZ ? length : wallT;

    const baseGeom = new THREE.BoxGeometry(w, wallH, d);
    const baseMesh = new THREE.Mesh(baseGeom, barrierWoodMat);
    baseMesh.position.y = wallH * 0.5;
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    section.add(baseMesh);

    // Top cap
    const capGeom = new THREE.BoxGeometry(w * 1.15, 0.04, d * (isAlongZ ? 1.0 : 1.0));
    const capMesh = new THREE.Mesh(capGeom, barrierCapMat);
    capMesh.position.y = wallH + 0.02;
    capMesh.castShadow = true;
    section.add(capMesh);

    return section;
  };

  // Left Barrier (X = -3.12, Z = 6.25, Length = 13.0)
  const leftBarrier = createBarrierSection(13.0, true);
  leftBarrier.position.set(-3.12, 0, 6.25);
  barrierGroup.add(leftBarrier);

  // Right Barrier (X = 3.12, Z = 6.25, Length = 13.0)
  const rightBarrier = createBarrierSection(13.0, true);
  rightBarrier.position.set(3.12, 0, 6.25);
  barrierGroup.add(rightBarrier);

  // Far End Barrier (X = 0, Z = 12.8, Length = 6.36)
  const farBarrier = createBarrierSection(6.36, false);
  farBarrier.position.set(0, 0, 12.8);
  barrierGroup.add(farBarrier);

  // Back Barrier (Behind throwing box: X = 0, Z = -0.3, Length = 6.36)
  const backBarrier = createBarrierSection(6.36, false);
  backBarrier.position.set(0, 0, -0.3);
  barrierGroup.add(backBarrier);

  courtGroup.add(barrierGroup);

  // 4. Arena Atmosphere (Arena walls, banners, sports lighting truss, referee chair)
  const arenaEnv = new THREE.Group();

  // Dark modern stadium background walls
  const wallGeom = new THREE.BoxGeometry(22, 5, 0.5);
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.8
  });

  const backStadiumWall = new THREE.Mesh(wallGeom, wallMat);
  backStadiumWall.position.set(0, 2.5, 14.5);
  arenaEnv.add(backStadiumWall);

  // Boccia Tournament Banner on back wall
  const bannerCanvas = document.createElement('canvas');
  bannerCanvas.width = 1024;
  bannerCanvas.height = 256;
  const bCtx = bannerCanvas.getContext('2d')!;
  bCtx.fillStyle = '#1e293b';
  bCtx.fillRect(0, 0, 1024, 256);
  bCtx.fillStyle = '#ef4444';
  bCtx.fillRect(0, 0, 512, 12);
  bCtx.fillStyle = '#3b82f6';
  bCtx.fillRect(512, 0, 512, 12);

  bCtx.fillStyle = '#ffffff';
  bCtx.font = 'bold 54px system-ui, sans-serif';
  bCtx.textAlign = 'center';
  bCtx.textBaseline = 'middle';
  bCtx.fillText('BOCCIA CHAMPIONSHIP', 512, 110);
  bCtx.font = '28px system-ui, sans-serif';
  bCtx.fillStyle = '#94a3b8';
  bCtx.fillText('PRECISION & STRATEGY • 3D SIMULATION', 512, 180);

  const bannerTex = new THREE.CanvasTexture(bannerCanvas);
  bannerTex.colorSpace = THREE.SRGBColorSpace;
  const bannerMat = new THREE.MeshStandardMaterial({
    map: bannerTex,
    roughness: 0.4
  });
  const bannerMesh = new THREE.Mesh(new THREE.PlaneGeometry(12, 3), bannerMat);
  bannerMesh.position.set(0, 2.8, 14.2);
  arenaEnv.add(bannerMesh);

  // Side Team Benches & Ball Trays (Red on left, Blue on right)
  const benchGeom = new THREE.BoxGeometry(0.8, 0.45, 2.2);
  const redBenchMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.6 });
  const blueBenchMat = new THREE.MeshStandardMaterial({ color: 0x1e40af, roughness: 0.6 });

  const redBench = new THREE.Mesh(benchGeom, redBenchMat);
  redBench.position.set(-4.2, 0.225, 1.25);
  redBench.castShadow = true;
  redBench.receiveShadow = true;
  arenaEnv.add(redBench);

  const blueBench = new THREE.Mesh(benchGeom, blueBenchMat);
  blueBench.position.set(4.2, 0.225, 1.25);
  blueBench.castShadow = true;
  blueBench.receiveShadow = true;
  arenaEnv.add(blueBench);

  // Ball stand trays near throwing area
  const trayGeom = new THREE.BoxGeometry(0.5, 0.7, 0.8);
  const trayMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4, metalness: 0.3 });

  const redTray = new THREE.Mesh(trayGeom, trayMat);
  redTray.position.set(-3.7, 0.35, 2.0);
  redTray.castShadow = true;
  arenaEnv.add(redTray);

  const blueTray = new THREE.Mesh(trayGeom, trayMat);
  blueTray.position.set(3.7, 0.35, 2.0);
  blueTray.castShadow = true;
  arenaEnv.add(blueTray);

  courtGroup.add(arenaEnv);

  return courtGroup;
}
