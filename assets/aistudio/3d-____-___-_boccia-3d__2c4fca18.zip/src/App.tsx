/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { BocciaGame, GameSnapshot } from './game/BocciaGame';
import { TitleScreen } from './components/TitleScreen';
import { HUD } from './components/HUD';
import { RoundEndModal } from './components/RoundEndModal';
import { RulesModal } from './components/RulesModal';
import { GameMode, AIDifficulty, CameraPreset } from './game/types';
import { sound } from './game/audio';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<BocciaGame | null>(null);

  const [isTitleOpen, setIsTitleOpen] = useState(true);
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Drag interaction refs for direct canvas flick/aim
  const dragStartRef = useRef<{ x: number; y: number; angle: number; power: number } | null>(null);

  // Local copy of snapshot for React HUD
  const [snapshot, setSnapshot] = useState<GameSnapshot>({
    phase: 'title',
    mode: 'solo_ai',
    difficulty: 'medium',
    currentTeam: 'jack',
    activeBallId: 'jack',
    redRemaining: 6,
    blueRemaining: 6,
    redScore: 0,
    blueScore: 0,
    currentEnd: 1,
    totalEnds: 4,
    isAiTurn: false,
    aimParams: { angle: 0, power: 0.52, loft: 0.05, spin: 0, startX: 0.5 },
    closestDistance: { red: 0, blue: 0 },
    lastMessage: 'ジャックボール（白球）を投げてください',
    roundScore: null,
    cameraPreset: 'throw',
    currentBox: 3,
    isBoxLocked: false,
    boxes: []
  });

  // Initialize WebGL scene once on mount
  useEffect(() => {
    if (!mountRef.current) return;

    const game = new BocciaGame(mountRef.current);
    gameRef.current = game;

    game.setOnStateChange((snap) => {
      setSnapshot(snap);
    });

    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  // Direct canvas pointer drag for interactive aiming
  const handlePointerDown = (e: React.PointerEvent) => {
    if (snapshot.phase !== 'aiming' || snapshot.isAiTurn || snapshot.cameraPreset === 'free_orbit') {
      return;
    }
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      angle: snapshot.aimParams.angle,
      power: snapshot.aimParams.power
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragStartRef.current || !gameRef.current) return;
    const dx = e.clientX - dragStartRef.current.x;

    // Horizontal canvas drag shifts angle (dragging right turns right, left turns left)
    const targetAngle = dragStartRef.current.angle + dx * 0.00075;
    gameRef.current.setAimAngle(targetAngle);
  };

  const handlePointerUp = () => {
    dragStartRef.current = null;
  };

  // Actions
  const handleStartGame = (mode: GameMode, difficulty: AIDifficulty, totalEnds: number) => {
    if (!gameRef.current) return;
    gameRef.current.startNewMatch(mode, difficulty, totalEnds);
    setIsTitleOpen(false);
  };

  const handleSetAngle = useCallback((angle: number) => {
    gameRef.current?.setAimAngle(angle);
  }, []);

  const handleSetPower = useCallback((power: number) => {
    gameRef.current?.setAimPower(power);
  }, []);

  const handleSetSpin = useCallback((spin: number) => {
    gameRef.current?.setAimSpin(spin);
  }, []);

  const handleSetLoft = useCallback((loft: number) => {
    gameRef.current?.setAimLoft(loft);
  }, []);

  const handleSetStartX = useCallback((x: number) => {
    gameRef.current?.setThrowStartX(x);
  }, []);

  const handleThrow = useCallback(() => {
    gameRef.current?.executeThrow();
  }, []);

  const handleSetCameraPreset = useCallback((preset: CameraPreset) => {
    gameRef.current?.setCameraPreset(preset);
  }, []);

  const handleToggleMeasurement = useCallback((show: boolean) => {
    gameRef.current?.showMeasurementOverlay(show);
  }, []);

  const handleToggleMute = useCallback(() => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
  }, [isMuted]);

  const handleResetMatch = useCallback(() => {
    setIsTitleOpen(true);
    gameRef.current?.resetRound();
  }, []);

  const handleNextEnd = useCallback(() => {
    gameRef.current?.nextEndOrFinish();
  }, []);

  const handleInspectCourt = useCallback(() => {
    gameRef.current?.setCameraPreset('jack_topdown');
    gameRef.current?.showMeasurementOverlay(true);
  }, []);

  const handleMoveBox = useCallback((direction: 'left' | 'right') => {
    gameRef.current?.moveBox(direction);
  }, []);

  const handleToggleBoxSelection = useCallback(() => {
    gameRef.current?.toggleBoxSelection();
  }, []);

  const handleSelectBoxDirectly = useCallback((boxNumber: number) => {
    gameRef.current?.selectBoxDirectly(boxNumber);
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none touch-none">
      {/* Isolated Three.js WebGL canvas container with pointer drag for aiming */}
      <div
        ref={mountRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="absolute inset-0 w-full h-full z-0 cursor-grab active:cursor-grabbing"
      />

      {/* Title Screen */}
      {isTitleOpen && (
        <TitleScreen
          onStartGame={handleStartGame}
          onOpenRules={() => setIsRulesOpen(true)}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Main Playing HUD Overlay */}
      {!isTitleOpen && (
        <HUD
          snapshot={snapshot}
          onSetAngle={handleSetAngle}
          onSetPower={handleSetPower}
          onSetSpin={handleSetSpin}
          onSetLoft={handleSetLoft}
          onSetStartX={handleSetStartX}
          onThrow={handleThrow}
          onMoveBox={handleMoveBox}
          onToggleBoxSelection={handleToggleBoxSelection}
          onSelectBoxDirectly={handleSelectBoxDirectly}
          onSetCameraPreset={handleSetCameraPreset}
          onToggleMeasurement={handleToggleMeasurement}
          onOpenRules={() => setIsRulesOpen(true)}
          onResetMatch={handleResetMatch}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* End / Match Conclusion Modal */}
      {!isTitleOpen && (snapshot.phase === 'end_scoring' || snapshot.phase === 'match_over') && (
        <RoundEndModal
          isOpen={true}
          roundScore={snapshot.roundScore}
          currentEnd={snapshot.currentEnd}
          totalEnds={snapshot.totalEnds}
          totalRedScore={snapshot.redScore}
          totalBlueScore={snapshot.blueScore}
          isMatchOver={snapshot.phase === 'match_over'}
          onNextEnd={handleNextEnd}
          onRestartMatch={handleResetMatch}
          onInspectCourt={handleInspectCourt}
        />
      )}

      {/* Rules & Guide Modal */}
      <RulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />
    </div>
  );
}
