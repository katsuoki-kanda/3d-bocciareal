import * as THREE from 'three';

// Generate procedural wood texture
export function createWoodTexture(isEndGrain: boolean = false): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#eedab3';
  ctx.fillRect(0, 0, size, size);

  if (isEndGrain) {
    const centerX = size / 2;
    const centerY = size / 2;
    for (let r = 5; r < size * 0.7; r += 3 + Math.random() * 4) {
      ctx.beginPath();
      ctx.arc(centerX + (Math.random() - 0.5) * 6, centerY + (Math.random() - 0.5) * 6, r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(160, 105, 55, ${0.15 + Math.random() * 0.25})`;
      ctx.lineWidth = 1.5 + Math.random() * 2;
      ctx.stroke();
    }
  } else {
    const numLines = 140;
    for (let i = 0; i < numLines; i++) {
      const y = Math.random() * size;
      const alpha = 0.08 + Math.random() * 0.18;
      ctx.strokeStyle = `rgba(150, 95, 45, ${alpha})`;
      ctx.lineWidth = 1 + Math.random() * 3;

      ctx.beginPath();
      ctx.moveTo(0, y);
      let currY = y;
      for (let x = 0; x <= size; x += 30) {
        currY += (Math.random() - 0.5) * 3;
        ctx.lineTo(x, currY);
      }
      ctx.stroke();
    }

    for (let k = 0; k < 2; k++) {
      const kx = 100 + Math.random() * (size - 200);
      const ky = 100 + Math.random() * (size - 200);
      const rad = 6 + Math.random() * 10;
      const grad = ctx.createRadialGradient(kx, ky, 2, kx, ky, rad * 2);
      grad.addColorStop(0, 'rgba(100, 55, 25, 0.6)');
      grad.addColorStop(0.5, 'rgba(140, 85, 40, 0.3)');
      grad.addColorStop(1, 'rgba(229, 196, 148, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.ellipse(kx, ky, rad * 1.5, rad, 0.1, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

// Generate pin top angled face texture with printed Molkky number (1 - 12)
// Maximized font size for supreme legibility at distance
export function createPinNumberTexture(pinNumber: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Birch wood background
  ctx.fillStyle = '#faebd7';
  ctx.fillRect(0, 0, size, size);

  // Concentric wood rings on cut face
  const cx = size / 2;
  const cy = size / 2;
  for (let r = 10; r < size * 0.68; r += 4 + Math.random() * 5) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(165, 110, 60, ${0.10 + Math.random() * 0.15})`;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  // Bark vignette border
  const ringGrad = ctx.createRadialGradient(cx, cy, size * 0.38, cx, cy, size * 0.49);
  ringGrad.addColorStop(0, 'rgba(180, 120, 60, 0)');
  ringGrad.addColorStop(1, 'rgba(80, 40, 15, 0.6)');
  ctx.fillStyle = ringGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.49, 0, Math.PI * 2);
  ctx.fill();

  // Dark circular border line
  ctx.beginPath();
  ctx.arc(cx, cy, size * 0.46, 0, Math.PI * 2);
  ctx.strokeStyle = '#2b1406';
  ctx.lineWidth = 9;
  ctx.stroke();

  // Extra-large bold stamped number
  ctx.save();
  const isDoubleDigit = pinNumber >= 10;
  const fontSize = isDoubleDigit ? 220 : 255;
  ctx.font = `900 ${fontSize}px "Arial Black", "Impact", "Trebuchet MS", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#0a0502';

  const numText = pinNumber.toString();
  ctx.fillText(numText, cx, cy + 6);

  if (pinNumber === 6 || pinNumber === 9) {
    ctx.beginPath();
    ctx.arc(cx + 65, cy + 85, 16, 0, Math.PI * 2);
    ctx.fillStyle = '#0a0502';
    ctx.fill();
  }
  ctx.restore();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// Extra-large crisp front badge texture facing thrower directly
export function createFrontBadgeTexture(num: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, 256, 256);

  const cx = 128;
  const cy = 128;

  // Bright ivory background disc for high contrast
  ctx.beginPath();
  ctx.arc(cx, cy, 118, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.lineWidth = 12;
  ctx.strokeStyle = '#261204';
  ctx.stroke();

  // Inner accent line
  ctx.beginPath();
  ctx.arc(cx, cy, 102, 0, Math.PI * 2);
  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(100, 50, 20, 0.4)';
  ctx.stroke();

  // Extra-large bold number
  ctx.save();
  const isDoubleDigit = num >= 10;
  const fontSize = isDoubleDigit ? 150 : 180;
  ctx.font = `900 ${fontSize}px "Arial Black", "Impact", "Trebuchet MS", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#050201';
  ctx.fillText(num.toString(), cx, cy + 6);

  if (num === 6 || num === 9) {
    ctx.beginPath();
    ctx.arc(cx + 48, cy + 55, 12, 0, Math.PI * 2);
    ctx.fillStyle = '#050201';
    ctx.fill();
  }
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// Procedural grass texture
export function createGrassTexture(): THREE.CanvasTexture {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#497c2c';
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 40000; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const len = 3 + Math.random() * 8;
    const angle = (Math.random() - 0.5) * 0.8 - Math.PI / 2;
    const greens = ['#5a9536', '#3f6d24', '#4e842f', '#65a83d', '#355c1d', '#588e33'];
    ctx.strokeStyle = greens[Math.floor(Math.random() * greens.length)];
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 12);
  return texture;
}

/**
 * Creates a detailed 3D Skittle pin with an authentic sheared top cut.
 * Numbers on both top cut and front badge are maximized in size for extreme legibility.
 */
export function createSkittleMesh(
  pinNumber: number,
  radius: number = 0.08,
  height: number = 0.40,
  woodTex: THREE.CanvasTexture,
  woodEndTex: THREE.CanvasTexture
): THREE.Group {
  const group = new THREE.Group();
  group.name = `skittle-${pinNumber}`;

  // 1. Sheared Cylinder Geometry
  const bodyGeo = new THREE.CylinderGeometry(radius, radius, height, 32, 1, false);
  const pos = bodyGeo.attributes.position;
  const uv = bodyGeo.attributes.uv;
  const idx = bodyGeo.index!;
  const topGroup = bodyGeo.groups[1];

  const cutAngleRad = THREE.MathUtils.degToRad(35);
  const tanAngle = Math.tan(cutAngleRad);

  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i);
    const z = pos.getZ(i);
    if (y > 0) {
      pos.setY(i, height / 2 - 0.02 + z * tanAngle);
    }
  }

  // Remap top cap UVs: un-mirrored and fully visible
  const visited = new Set<number>();
  for (let i = topGroup.start; i < topGroup.start + topGroup.count; i++) {
    const v = idx.getX(i);
    if (!visited.has(v)) {
      visited.add(v);
      const x = pos.getX(v);
      const z = pos.getZ(v);
      uv.setXY(v, 0.5 - x / (2 * radius), 0.5 + z / (2 * radius));
    }
  }

  bodyGeo.computeVertexNormals();

  const woodMaterial = new THREE.MeshStandardMaterial({
    map: woodTex,
    roughness: 0.65,
    metalness: 0.05,
  });

  const topNumTex = createPinNumberTexture(pinNumber);
  const topCapMaterial = new THREE.MeshStandardMaterial({
    map: topNumTex,
    roughness: 0.50,
    metalness: 0.04,
  });

  const bottomCapMaterial = new THREE.MeshStandardMaterial({
    map: woodEndTex,
    roughness: 0.85,
    metalness: 0.02,
  });

  const bodyMesh = new THREE.Mesh(bodyGeo, [woodMaterial, topCapMaterial, bottomCapMaterial]);
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  group.add(bodyMesh);

  // 2. Bottom Ring Bevel
  const bottomRingGeo = new THREE.TorusGeometry(radius * 0.94, radius * 0.06, 12, 32);
  bottomRingGeo.rotateX(Math.PI / 2);
  bottomRingGeo.translate(0, -height / 2 + radius * 0.06, 0);
  const bottomMesh = new THREE.Mesh(bottomRingGeo, bottomCapMaterial);
  group.add(bottomMesh);

  // 3. Extra-Large Front Badge facing player directly at eye-level
  const frontBadgeGeo = new THREE.PlaneGeometry(radius * 1.80, radius * 1.80);
  frontBadgeGeo.scale(-1, 1, 1);
  const frontBadgeTex = createFrontBadgeTexture(pinNumber);
  const frontBadgeMat = new THREE.MeshStandardMaterial({
    map: frontBadgeTex,
    transparent: true,
    roughness: 0.55,
    metalness: 0.02,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });
  const frontBadge = new THREE.Mesh(frontBadgeGeo, frontBadgeMat);
  frontBadge.position.set(0, 0.02, -radius - 0.002);
  frontBadge.rotation.set(0, Math.PI, 0);
  group.add(frontBadge);

  return group;
}

/**
 * Creates the Molkky throwing stick centered at (0, 0, 0), horizontal along X axis
 */
export function createMolkkyStickMesh(
  radius: number = 0.07,
  length: number = 0.42,
  woodTex: THREE.CanvasTexture,
  woodEndTex: THREE.CanvasTexture
): THREE.Group {
  const group = new THREE.Group();
  group.name = 'molkky-stick';

  const woodMat = new THREE.MeshStandardMaterial({
    map: woodTex,
    roughness: 0.55,
    metalness: 0.05,
  });

  const endMat = new THREE.MeshStandardMaterial({
    map: woodEndTex,
    roughness: 0.75,
    metalness: 0.02,
  });

  const cylinderGeo = new THREE.CylinderGeometry(radius, radius, length * 0.9, 32);
  cylinderGeo.rotateZ(Math.PI / 2);
  const cylinder = new THREE.Mesh(cylinderGeo, woodMat);
  cylinder.castShadow = true;
  cylinder.receiveShadow = true;
  group.add(cylinder);

  const capGeo = new THREE.SphereGeometry(radius, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2);

  const leftCap = new THREE.Mesh(capGeo, endMat);
  leftCap.rotation.z = Math.PI / 2;
  leftCap.position.set(-length * 0.45, 0, 0);
  leftCap.castShadow = true;
  group.add(leftCap);

  const rightCap = new THREE.Mesh(capGeo, endMat);
  rightCap.rotation.z = -Math.PI / 2;
  rightCap.position.set(length * 0.45, 0, 0);
  rightCap.castShadow = true;
  group.add(rightCap);

  const ringGeo = new THREE.TorusGeometry(radius + 0.002, 0.005, 12, 32);
  ringGeo.rotateY(Math.PI / 2);
  const ringMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4, // Cyan by default (Player 1)
    roughness: 0.4,
    metalness: 0.1,
  });
  const ring1 = new THREE.Mesh(ringGeo, ringMat);
  ring1.name = 'accent-ring-1';
  ring1.position.set(0.08, 0, 0);
  const ring2 = new THREE.Mesh(ringGeo, ringMat);
  ring2.name = 'accent-ring-2';
  ring2.position.set(-0.08, 0, 0);
  group.add(ring1);
  group.add(ring2);

  return group;
}

export function createThrowingAreaMesh(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'molkkaari';

  const woodMat = new THREE.MeshStandardMaterial({
    color: 0x8b5a2b,
    roughness: 0.8,
    metalness: 0.1,
  });

  const barGeo = new THREE.BoxGeometry(1.2, 0.04, 0.08);
  const bar = new THREE.Mesh(barGeo, woodMat);
  bar.position.set(0, 0.02, 0);
  bar.receiveShadow = true;
  bar.castShadow = true;
  group.add(bar);

  const wingGeo = new THREE.BoxGeometry(0.5, 0.04, 0.08);
  const leftWing = new THREE.Mesh(wingGeo, woodMat);
  leftWing.position.set(-0.7, 0.02, -0.2);
  leftWing.rotation.y = -Math.PI / 4;
  leftWing.receiveShadow = true;
  leftWing.castShadow = true;
  group.add(leftWing);

  const rightWing = new THREE.Mesh(wingGeo, woodMat);
  rightWing.position.set(0.7, 0.02, -0.2);
  rightWing.rotation.y = Math.PI / 4;
  rightWing.receiveShadow = true;
  rightWing.castShadow = true;
  group.add(rightWing);

  return group;
}

export function createParkEnvironment(): THREE.Group {
  const group = new THREE.Group();
  group.name = 'park-environment';

  const postMat = new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.85 });
  const postGeo = new THREE.CylinderGeometry(0.04, 0.05, 0.8, 16);
  postGeo.translate(0, 0.4, 0);

  const perimeterX = [-3.5, 3.5];
  for (let px of perimeterX) {
    for (let z = -2; z <= 14; z += 2.5) {
      const post = new THREE.Mesh(postGeo, postMat);
      post.position.set(px, 0, z);
      post.castShadow = true;
      group.add(post);
    }
  }

  const distances = [
    { z: 0, label: '0m START (Mölkkaari)' },
    { z: 3.5, label: '3.5m PIN ZONE' },
    { z: 6.0, label: '6.0m' },
    { z: 9.0, label: '9.0m' },
    { z: 12.0, label: '12.0m' },
  ];

  distances.forEach(({ z }) => {
    const lineGeo = new THREE.PlaneGeometry(6, 0.04);
    const lineMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.25,
      side: THREE.DoubleSide,
    });
    const lineMesh = new THREE.Mesh(lineGeo, lineMat);
    lineMesh.rotation.x = -Math.PI / 2;
    lineMesh.position.set(0, 0.005, z);
    group.add(lineMesh);
  });

  const trunkGeo = new THREE.CylinderGeometry(0.18, 0.28, 2.2, 12);
  trunkGeo.translate(0, 1.1, 0);
  const foliageGeo1 = new THREE.ConeGeometry(1.6, 2.5, 8);
  foliageGeo1.translate(0, 2.8, 0);
  const foliageGeo2 = new THREE.ConeGeometry(1.2, 2.0, 8);
  foliageGeo2.translate(0, 3.9, 0);

  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x422a1d, roughness: 0.9 });
  const foliageMat = new THREE.MeshStandardMaterial({ color: 0x1f3f1e, roughness: 0.8 });

  const treePositions = [
    { x: -6, z: 8 },
    { x: -7.5, z: 12 },
    { x: -5, z: 16 },
    { x: 6.5, z: 7 },
    { x: 8, z: 11 },
    { x: 5.5, z: 15 },
    { x: 0, z: 18 },
    { x: -3, z: 19 },
    { x: 4, z: 20 },
  ];

  treePositions.forEach(pos => {
    const tree = new THREE.Group();
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    const f1 = new THREE.Mesh(foliageGeo1, foliageMat);
    const f2 = new THREE.Mesh(foliageGeo2, foliageMat);
    trunk.castShadow = true;
    f1.castShadow = true;
    f2.castShadow = true;
    tree.add(trunk);
    tree.add(f1);
    tree.add(f2);
    tree.position.set(pos.x, 0, pos.z);
    const scale = 0.8 + Math.random() * 0.4;
    tree.scale.set(scale, scale, scale);
    group.add(tree);
  });

  return group;
}
