import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { CameraViewMode, ThrowParams } from '../types/game';
import { MolkkyPhysics } from './physics';
import {
  createWoodTexture,
  createGrassTexture,
  createSkittleMesh,
  createMolkkyStickMesh,
  createThrowingAreaMesh,
  createParkEnvironment,
} from './proceduralAssets';

export class MolkkyScene {
  public container: HTMLElement;
  public renderer: THREE.WebGLRenderer;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public physics: MolkkyPhysics;

  public isSoftwareGl: boolean;
  private animFrameId: number = 0;
  private isDisposed = false;

  // 3D Objects
  public skittleMeshes: { [num: number]: THREE.Group } = {};
  public stickMesh: THREE.Group | null = null;
  public trajectoryLine: THREE.Line | null = null;
  public aimIndicatorMesh: THREE.Group | null = null;

  // Camera animation
  public currentViewMode: CameraViewMode = 'thrower';
  private targetCamPos = new THREE.Vector3(0, 1.6, -1.8);
  private targetCamLookAt = new THREE.Vector3(0, 0.4, 4.0);
  private currentCamLookAt = new THREE.Vector3(0, 0.4, 4.0);

  constructor(container: HTMLElement) {
    this.container = container;

    // Detect software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // Three.js WebGLRenderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(this.renderer.domElement);

    // Scene & Camera
    this.scene = new THREE.Scene();
    const skyColor = 0xb4e1f7;
    const fogColor = 0xa4d4be;
    this.scene.background = new THREE.Color(skyColor);
    this.scene.fog = new THREE.FogExp2(fogColor, 0.025);

    this.camera = new THREE.PerspectiveCamera(
      48,
      container.clientWidth / container.clientHeight,
      0.1,
      80
    );
    this.camera.position.copy(this.targetCamPos);
    this.camera.lookAt(this.targetCamLookAt);

    // Studio Environment Reflection via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Lighting Setup
    this.setupLighting();

    // Ground & Park Arena
    this.setupGround();

    // Physics World
    this.physics = new MolkkyPhysics();

    // Generate Skittles (1 to 12) & Molkky Stick
    this.setupGameMeshes();

    // Trajectory & Aim Indicator (Vivid Red per user request)
    this.setupTrajectoryHelpers();

    // Start Loop
    this.startLoop();

    window.addEventListener('resize', this.onResize);
  }

  private setupLighting() {
    const sunLight = new THREE.DirectionalLight(0xfff6e6, 2.3);
    sunLight.position.set(5, 10, -3);
    if (!this.isSoftwareGl) {
      sunLight.castShadow = true;
      sunLight.shadow.mapSize.width = 2048;
      sunLight.shadow.mapSize.height = 2048;
      sunLight.shadow.camera.near = 0.5;
      sunLight.shadow.camera.far = 30;
      const d = 6.5;
      sunLight.shadow.camera.left = -d;
      sunLight.shadow.camera.right = d;
      sunLight.shadow.camera.top = d;
      sunLight.shadow.camera.bottom = -d;
      sunLight.shadow.bias = -0.0005;
      sunLight.shadow.normalBias = 0.02;
    }
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(0xebf8ff, 0x4a7c36, 0.9);
    hemiLight.position.set(0, 15, 0);
    this.scene.add(hemiLight);

    const rimLight = new THREE.DirectionalLight(0xcde3ff, 0.6);
    rimLight.position.set(-6, 6, 12);
    this.scene.add(rimLight);
  }

  private setupGround() {
    const grassTex = createGrassTexture();
    grassTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();

    const groundGeo = new THREE.PlaneGeometry(60, 60);
    const groundMat = new THREE.MeshStandardMaterial({
      map: grassTex,
      roughness: 0.88,
      metalness: 0.02,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    const molkkaari = createThrowingAreaMesh();
    this.scene.add(molkkaari);

    const parkProps = createParkEnvironment();
    this.scene.add(parkProps);
  }

  private setupGameMeshes() {
    const woodTex = createWoodTexture(false);
    const woodEndTex = createWoodTexture(true);
    woodTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    woodEndTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();

    for (let num = 1; num <= 12; num++) {
      const mesh = createSkittleMesh(
        num,
        this.physics.pinRadius,
        this.physics.pinHeight,
        woodTex,
        woodEndTex
      );
      this.scene.add(mesh);
      this.skittleMeshes[num] = mesh;
    }

    this.physics.setupOfficialPinLayout(this.skittleMeshes);

    this.stickMesh = createMolkkyStickMesh(
      this.physics.stickRadius,
      this.physics.stickLength,
      woodTex,
      woodEndTex
    );
    this.scene.add(this.stickMesh);
    this.physics.setupStick(this.stickMesh);
  }

  /**
   * Updates the accent ring color of the Molkky stick based on the active player
   */
  public setStickPlayerColor(colorHex: number) {
    if (!this.stickMesh) return;
    this.stickMesh.traverse(child => {
      if (child instanceof THREE.Mesh && child.name.startsWith('accent-ring')) {
        if (child.material instanceof THREE.MeshStandardMaterial) {
          child.material.color.setHex(colorHex);
        }
      }
    });
  }

  private setupTrajectoryHelpers() {
    const pointsCount = 45;
    const positions = new Float32Array(pointsCount * 3);
    const trajGeo = new THREE.BufferGeometry();
    trajGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const trajMat = new THREE.LineDashedMaterial({
      color: 0xff1e1e, // Vivid Red
      dashSize: 0.12,
      gapSize: 0.06,
      linewidth: 4,
      transparent: true,
      opacity: 0.95,
    });

    this.trajectoryLine = new THREE.Line(trajGeo, trajMat);
    this.trajectoryLine.computeLineDistances();
    this.scene.add(this.trajectoryLine);

    const aimDiscGeo = new THREE.RingGeometry(0.12, 0.22, 24);
    aimDiscGeo.rotateX(-Math.PI / 2);
    const aimDiscMat = new THREE.MeshBasicMaterial({
      color: 0xff1e1e,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.85,
    });
    this.aimIndicatorMesh = new THREE.Group();
    const disc = new THREE.Mesh(aimDiscGeo, aimDiscMat);
    disc.position.y = 0.02;
    this.aimIndicatorMesh.add(disc);

    const arrowGeo = new THREE.ConeGeometry(0.08, 0.25, 16);
    arrowGeo.rotateX(Math.PI / 2);
    const arrow = new THREE.Mesh(arrowGeo, aimDiscMat);
    arrow.position.set(0, 0.02, 0.3);
    this.aimIndicatorMesh.add(arrow);

    this.scene.add(this.aimIndicatorMesh);
  }

  /**
   * Updates visual trajectory curve and ground landing target based on throw parameters
   */
  public updateTrajectory(params: ThrowParams, visible: boolean = true) {
    if (!this.trajectoryLine || !this.aimIndicatorMesh) return;
    this.trajectoryLine.visible = visible;
    this.aimIndicatorMesh.visible = visible;
    if (!visible) return;

    const speed = 1.5 + Math.pow(params.power / 100, 1.25) * 12.8;
    const aimRad = -THREE.MathUtils.degToRad(params.aimAngle);
    const pitchRad = THREE.MathUtils.degToRad(params.pitchAngle);

    const horizSpeed = speed * Math.cos(pitchRad);
    const vx = horizSpeed * Math.sin(aimRad);
    const vy = speed * Math.sin(pitchRad);
    const vz = horizSpeed * Math.cos(aimRad);

    const g = 9.82;
    const startX = 0;
    const startY = 0.7;
    const startZ = -0.2;

    const posAttr = this.trajectoryLine.geometry.attributes.position as THREE.BufferAttribute;
    const count = posAttr.count;

    const totalT = (vy + Math.sqrt(vy * vy + 2 * g * startY)) / g;

    for (let i = 0; i < count; i++) {
      const t = (i / (count - 1)) * totalT;
      const x = startX + vx * t;
      const y = Math.max(0.01, startY + vy * t - 0.5 * g * t * t);
      const z = startZ + vz * t;
      posAttr.setXYZ(i, x, y, z);
    }
    posAttr.needsUpdate = true;
    this.trajectoryLine.computeLineDistances();

    const landX = startX + vx * totalT;
    const landZ = startZ + vz * totalT;
    this.aimIndicatorMesh.position.set(landX, 0.01, landZ);
    this.aimIndicatorMesh.rotation.y = aimRad;
  }

  /**
   * Computes dynamic overhead camera position & height based on skittle spread.
   * Keeps pins large and prominent when tightly clustered, and smoothly scales
   * out to fit all 12 scattered pins when separated, with stable forward orientation.
   */
  public computeOverheadCameraTarget() {
    if (this.physics.pins.length === 0) {
      this.targetCamPos.set(0, 4.5, 4.0);
      this.targetCamLookAt.set(0, 0, 4.2);
      return;
    }

    let minX = Infinity;
    let maxX = -Infinity;
    let minZ = Infinity;
    let maxZ = -Infinity;

    for (const p of this.physics.pins) {
      const px = p.body.position.x;
      const pz = p.body.position.z;
      if (px < minX) minX = px;
      if (px > maxX) maxX = px;
      if (pz < minZ) minZ = pz;
      if (pz > maxZ) maxZ = pz;
    }

    const centerX = (minX + maxX) / 2;
    const centerZ = (minZ + maxZ) / 2;
    // Padding so pins are never cut off by screen boundaries
    const spanX = (maxX - minX) + 0.9;
    const spanZ = (maxZ - minZ) + 0.9;

    const aspect = Math.max(0.5, this.camera.aspect);
    const tanHalfY = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const tanHalfX = tanHalfY * aspect;

    const hZ = (spanZ / 2) / tanHalfY;
    const hX = (spanX / 2) / tanHalfX;
    // Clamped between min 3.8m (prominent, close, not too small) and required max
    const optHeight = Math.max(hZ, hX, 3.8);

    // Look from slightly in front (z - 0.25) towards centerZ:
    // Completely eliminates vertical gimbal lock / sideways orientation flips,
    // ensuring the thrower is ALWAYS at bottom of screen, and field is at top!
    this.targetCamPos.set(centerX, optHeight, centerZ - 0.25);
    this.targetCamLookAt.set(centerX, 0, centerZ);
  }

  /**
   * Computes dynamic side-view camera position & distance.
   * Placed on the -X side so that:
   * - -Z (thrower / start at z=-0.2) is on the LEFT of the screen.
   * - +Z (skittles / landing target at z>=3.5) is on the RIGHT of the screen.
   * This provides a true side elevation view perfectly showing the parabolic arc and pitch angle.
   */
  public computeSideCameraTarget() {
    let maxZ = 4.5;
    if (this.physics.pins.length > 0) {
      for (const p of this.physics.pins) {
        if (p.body.position.z > maxZ) maxZ = p.body.position.z;
      }
    }
    const startZ = -0.3;
    const centerZ = (startZ + maxZ) / 2;
    const spanZ = (maxZ - startZ) + 1.2;

    const aspect = Math.max(0.5, this.camera.aspect);
    const tanHalfY = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const tanHalfX = tanHalfY * aspect;

    // In side view, screen horizontal corresponds to world Z axis
    const distForZ = (spanZ / 2) / tanHalfX;
    // Screen vertical corresponds to Y axis (ground 0 to arc apex ~2.8m)
    const distForY = (2.6 / 2) / tanHalfY;

    const optDist = Math.max(distForZ, distForY, 5.2);

    // Negative X position looks toward +X (0):
    // Left of screen = -Z (thrower), Right of screen = +Z (pins)
    this.targetCamPos.set(-optDist, 1.6, centerZ);
    this.targetCamLookAt.set(0, 0.95, centerZ);
  }

  /**
   * Sets camera view mode
   */
  public setCameraView(mode: CameraViewMode) {
    this.currentViewMode = mode;
    this.camera.up.set(0, 1, 0); // Always ensure stable world up

    switch (mode) {
      case 'thrower':
        this.targetCamPos.set(0, 1.6, -1.8);
        this.targetCamLookAt.set(0, 0.4, 4.0);
        break;
      case 'overhead':
        this.computeOverheadCameraTarget();
        break;
      case 'side':
        this.computeSideCameraTarget();
        break;
      case 'target':
        this.targetCamPos.set(0, 1.3, 1.8);
        this.targetCamLookAt.set(0, 0.35, 4.0);
        break;
      case 'follow':
        break;
    }
  }

  private onResize = () => {
    if (!this.container || this.isDisposed) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    if (this.currentViewMode === 'overhead') {
      this.computeOverheadCameraTarget();
    } else if (this.currentViewMode === 'side') {
      this.computeSideCameraTarget();
    }
  };

  private startLoop() {
    let lastTime = performance.now();

    const tick = () => {
      if (this.isDisposed) return;

      const now = performance.now();
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(rawDt, 0.05);

      // Step physics
      this.physics.step(dt);

      // Dynamic tracking: continuously adjust height & center if pins move
      if (this.currentViewMode === 'overhead') {
        this.computeOverheadCameraTarget();
      } else if (this.currentViewMode === 'side') {
        this.computeSideCameraTarget();
      }

      // Camera Follow behavior when stick is in flight
      if (this.currentViewMode === 'follow' && this.stickMesh && !this.physics.isSettling) {
        const stickPos = this.stickMesh.position;
        this.targetCamPos.set(stickPos.x * 0.7, Math.max(1.2, stickPos.y + 0.6), stickPos.z - 1.4);
        this.targetCamLookAt.set(stickPos.x, stickPos.y, stickPos.z + 0.8);
      }

      // Smooth exponential damping
      const lambda = 6.0;
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, this.targetCamPos.x, lambda, dt);
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, this.targetCamPos.y, lambda, dt);
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, this.targetCamPos.z, lambda, dt);

      this.currentCamLookAt.x = THREE.MathUtils.damp(this.currentCamLookAt.x, this.targetCamLookAt.x, lambda, dt);
      this.currentCamLookAt.y = THREE.MathUtils.damp(this.currentCamLookAt.y, this.targetCamLookAt.y, lambda, dt);
      this.currentCamLookAt.z = THREE.MathUtils.damp(this.currentCamLookAt.z, this.targetCamLookAt.z, lambda, dt);
      this.camera.lookAt(this.currentCamLookAt);

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.animFrameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.animFrameId = requestAnimationFrame(tick);
    }
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.isDisposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.animFrameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.animFrameId = window.setTimeout(cb, 80);
      }
    };
    this.animFrameId = window.setTimeout(poll, 5);
  }

  public dispose() {
    this.isDisposed = true;
    window.removeEventListener('resize', this.onResize);
    cancelAnimationFrame(this.animFrameId);
    clearTimeout(this.animFrameId);
    this.renderer.dispose();
  }
}
