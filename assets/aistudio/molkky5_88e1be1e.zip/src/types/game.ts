export type GameMode = 'two_player' | 'practice';

export type PlayerId = 1 | 2;

export interface PlayerState {
  id: PlayerId;
  name: string;
  score: number;
  missStreak: number;
  color: string; // TailWind color or hex
  accentColor: string; // for borders and highlights
  stickColorHex: number; // Three.js hex color for stick rings
}

export interface SkittleState {
  id: number;
  number: number;
  x: number;
  y: number;
  z: number;
  quaternion: [number, number, number, number];
  isFallen: boolean;
  scoreAwarded?: boolean;
}

export interface ThrowRecord {
  turnIndex: number; // overall turn sequence (1, 2, 3...)
  round: number; // player's individual throw round
  playerId: PlayerId;
  playerName: string;
  fallenCount: number;
  fallenNumbers: number[];
  roundScore: number;
  totalScoreBefore: number;
  totalScoreAfter: number;
  isBust: boolean;
  isMiss: boolean;
}

export type GamePhase = 'title' | 'aiming' | 'throwing' | 'settling' | 'result' | 'victory' | 'gameover';

export type CameraViewMode = 'thrower' | 'overhead' | 'side' | 'target' | 'follow';

export interface ThrowParams {
  aimAngle: number; // Left/Right angle in degrees (-25 to 25)
  pitchAngle: number; // Upwards pitch in degrees (10 to 35)
  power: number; // 30 to 100%
  spin: number; // -10 to 10
}

export interface MatchWinnerInfo {
  winnerId: PlayerId;
  winnerName: string;
  loserId: PlayerId;
  loserName: string;
  reason: 'fifty_points' | 'opponent_disqualified';
}
