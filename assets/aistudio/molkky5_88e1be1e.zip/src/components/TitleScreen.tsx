import React, { useState } from 'react';
import { Play, BookOpen, Volume2, VolumeX, Swords, Users, User, ArrowRight } from 'lucide-react';
import { GameMode } from '../types/game';
import { sound } from '../audio/soundEffects';

interface TitleScreenProps {
  onStartMatch: (mode: GameMode, p1Name: string, p2Name: string) => void;
  onOpenRules: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  defaultP1Name: string;
  defaultP2Name: string;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartMatch,
  onOpenRules,
  soundEnabled,
  onToggleSound,
  defaultP1Name,
  defaultP2Name,
}) => {
  const [p1Name, setP1Name] = useState(defaultP1Name || 'プレイヤー1');
  const [p2Name, setP2Name] = useState(defaultP2Name || 'プレイヤー2');
  const [selectedMode, setSelectedMode] = useState<GameMode>('two_player');

  const handleStart = () => {
    sound.playClick();
    onStartMatch(selectedMode, p1Name.trim() || 'プレイヤー1', p2Name.trim() || 'プレイヤー2');
  };

  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-between p-4 sm:p-8 pointer-events-none select-none overflow-y-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between w-full pointer-events-auto">
        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-stone-900/85 text-amber-200 text-xs font-semibold tracking-wider uppercase border border-amber-500/30 shadow-lg backdrop-blur-sm">
          <span>🪵 Mölkky Official</span>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
          <span className="text-amber-400 font-bold">2人対戦バトル</span>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onToggleSound();
          }}
          className="p-2.5 rounded-full bg-stone-900/80 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-700 transition shadow-lg pointer-events-auto cursor-pointer"
          title={soundEnabled ? 'ミュート' : 'サウンドON'}
        >
          {soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
        </button>
      </div>

      {/* Center Title & Player Config Lockup */}
      <div className="flex flex-col items-center text-center my-auto pointer-events-auto max-w-xl mx-auto w-full py-2">
        {/* Badge & Title */}
        <div className="relative mb-2">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-950/80 text-amber-300 text-xs font-bold tracking-widest uppercase border border-amber-600/40 shadow-inner">
            <Swords size={14} className="text-amber-400" />
            <span>2-Player Match Edition</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-amber-50 drop-shadow-[0_4px_16px_rgba(0,0,0,0.7)] mt-2">
            MÖLKKY 3D
            <span className="block text-2xl sm:text-3xl font-extrabold text-amber-400 mt-1 tracking-normal">
              2人対戦 モルックバトル
            </span>
          </h1>
        </div>

        <p className="text-stone-300 text-xs sm:text-sm font-medium max-w-lg bg-stone-950/75 p-3 rounded-2xl border border-stone-800/80 shadow-lg mb-4">
          1つのフィールドで2人が交互にモルック棒を投げ合う本格対戦！<br />
          散らばったピンの配置を引き継ぎながら、<strong className="text-amber-400 font-bold">ちょうど50点</strong>を先取したプレイヤーが勝利！
        </p>

        {/* Mode Selector Tabs */}
        <div className="w-full max-w-md bg-stone-900/90 p-1 rounded-2xl border border-stone-800 flex items-center mb-4 shadow-md">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setSelectedMode('two_player');
            }}
            className={`flex-1 py-2 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
              selectedMode === 'two_player'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Users size={16} />
            <span>2人対戦モード (推奨)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setSelectedMode('practice');
            }}
            className={`flex-1 py-2 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
              selectedMode === 'practice'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <User size={16} />
            <span>1人練習モード</span>
          </button>
        </div>

        {/* Player Names Input Box */}
        {selectedMode === 'two_player' ? (
          <div className="w-full max-w-md bg-stone-950/85 border border-stone-800 p-4 rounded-3xl shadow-xl mb-5 flex flex-col gap-3">
            <div className="text-xs font-bold text-stone-400 uppercase tracking-wider text-left flex items-center justify-between">
              <span>対戦プレイヤー設定</span>
              <span className="text-[10px] text-amber-400/90 font-normal">先攻・後攻で交互投擲</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Player 1 */}
              <div className="flex flex-col text-left gap-1 bg-cyan-950/30 border border-cyan-800/40 p-2.5 rounded-2xl">
                <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-bold">
                  <span className="w-4 h-4 rounded bg-cyan-500 text-stone-950 text-[10px] font-black flex items-center justify-center">1</span>
                  <span>先攻 (1P)</span>
                </div>
                <input
                  type="text"
                  maxLength={12}
                  value={p1Name}
                  onChange={e => setP1Name(e.target.value)}
                  placeholder="プレイヤー1"
                  className="w-full bg-stone-900 border border-cyan-700/50 rounded-xl px-2.5 py-1.5 text-xs sm:text-sm text-cyan-100 font-bold focus:outline-none focus:border-cyan-400 transition"
                />
              </div>

              {/* Player 2 */}
              <div className="flex flex-col text-left gap-1 bg-rose-950/30 border border-rose-800/40 p-2.5 rounded-2xl">
                <div className="flex items-center gap-1.5 text-rose-400 text-xs font-bold">
                  <span className="w-4 h-4 rounded bg-rose-500 text-white text-[10px] font-black flex items-center justify-center">2</span>
                  <span>後攻 (2P)</span>
                </div>
                <input
                  type="text"
                  maxLength={12}
                  value={p2Name}
                  onChange={e => setP2Name(e.target.value)}
                  placeholder="プレイヤー2"
                  className="w-full bg-stone-900 border border-rose-700/50 rounded-xl px-2.5 py-1.5 text-xs sm:text-sm text-rose-100 font-bold focus:outline-none focus:border-rose-400 transition"
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="w-full max-w-md bg-stone-950/85 border border-stone-800 p-3.5 rounded-3xl shadow-xl mb-5 flex flex-col gap-1 text-left">
            <span className="text-xs font-bold text-amber-300">ソロ練習</span>
            <span className="text-xs text-stone-400">1人で集中して50点ぴったりを目指す投擲練習モードです。</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full max-w-md">
          <button
            onClick={handleStart}
            className="w-full sm:flex-1 py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-stone-950 font-black text-lg tracking-wide shadow-[0_8px_25px_rgba(245,158,11,0.4)] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play size={20} className="fill-current" />
            <span>対戦スタート！ (Enter)</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenRules();
            }}
            className="w-full sm:w-auto py-3.5 px-5 rounded-2xl bg-stone-900/80 hover:bg-stone-800/90 text-stone-200 hover:text-white font-bold text-sm border border-stone-700/80 shadow-lg transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
          >
            <BookOpen size={17} />
            <span>ルール</span>
          </button>
        </div>

        {/* Shortcuts Quick Hint */}
        <div className="mt-4 text-[11px] text-stone-400 font-mono tracking-wide bg-stone-950/70 px-4 py-1.5 rounded-full border border-stone-800 shadow-md">
          Space 投擲 · ← → 狙い · ↑ ↓ パワー · + - 仰角 · / 視点 · * 格納
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-[11px] text-stone-500">
        本格フィンランド公式ルール & 3D物理演算モルックシミュレーター
      </div>
    </div>
  );
};
