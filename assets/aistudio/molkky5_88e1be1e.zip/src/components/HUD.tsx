import React, { useState } from 'react';
import { History, RotateCcw, HelpCircle, X, Swords, User, Zap } from 'lucide-react';
import { PlayerId, PlayerState, ThrowRecord } from '../types/game';
import { sound } from '../audio/soundEffects';

interface HUDProps {
  players: Record<PlayerId, PlayerState>;
  activePlayerId: PlayerId;
  matchTurn: number;
  history: ThrowRecord[];
  lastBanner: { message: string; sub?: string; type: 'success' | 'bust' | 'miss' | 'info' } | null;
  onResetGame: () => void;
  onOpenRules: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  players,
  activePlayerId,
  matchTurn,
  history,
  lastBanner,
  onResetGame,
  onOpenRules,
}) => {
  const [showHistory, setShowHistory] = useState(false);
  const [filterPlayer, setFilterPlayer] = useState<'all' | PlayerId>('all');

  const p1 = players[1];
  const p2 = players[2];

  const filteredHistory = filterPlayer === 'all'
    ? history
    : history.filter(h => h.playerId === filterPlayer);

  return (
    <>
      {/* Top HUD Wrapper */}
      <div className="absolute top-2 left-2 right-2 sm:top-3 sm:left-4 sm:right-4 pointer-events-none select-none z-20 flex flex-col gap-2">
        {/* Row 1: Player 1 (Left) - Match Center Status (Center) - Player 2 (Right) */}
        <div className="flex justify-between items-start w-full">
          {/* Player 1 Card (Cyan Theme) */}
          <div
            className={`pointer-events-auto flex flex-col transition-all duration-300 rounded-2xl p-2 sm:p-2.5 backdrop-blur-md border ${
              activePlayerId === 1
                ? 'bg-cyan-950/90 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.45)] scale-[1.02]'
                : 'bg-stone-950/80 border-stone-800/80 opacity-80'
            }`}
          >
            {/* Player Header */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-lg bg-cyan-500 text-stone-950 font-black text-[11px] flex items-center justify-center shadow-sm">
                  1P
                </span>
                <span className="text-xs sm:text-sm font-black text-cyan-100 max-w-[90px] sm:max-w-[120px] truncate">
                  {p1.name}
                </span>
              </div>
              {activePlayerId === 1 && (
                <span className="animate-pulse px-1.5 py-0.5 rounded-full bg-cyan-400 text-stone-950 font-black text-[9px] uppercase tracking-wider flex items-center gap-0.5 shadow-sm">
                  <Zap size={9} className="fill-current" /> TURN
                </span>
              )}
            </div>

            {/* Score & Progress */}
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-2xl sm:text-3xl font-black tabular-nums tracking-tight text-cyan-300">
                {p1.score}
              </span>
              <span className="text-stone-400 text-xs font-semibold">/ 50</span>
              <span className="text-[10px] font-bold text-cyan-200/90 ml-auto">
                {50 - p1.score === 0 ? '✨ GOAL!' : `あと ${Math.max(0, 50 - p1.score)}`}
              </span>
            </div>

            {/* Mini Progress Bar */}
            <div className="w-28 sm:w-36 h-1.5 bg-stone-850 rounded-full mt-1 overflow-hidden border border-stone-800">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  p1.score > 40
                    ? 'bg-gradient-to-r from-cyan-400 to-yellow-300'
                    : 'bg-gradient-to-r from-cyan-600 to-cyan-400'
                }`}
                style={{ width: `${Math.min(100, (p1.score / 50) * 100)}%` }}
              />
            </div>

            {/* Miss Strikes */}
            <div className="flex items-center justify-between mt-1.5 pt-1 border-t border-cyan-900/30">
              <span className="text-[9px] text-stone-400 font-semibold uppercase">ミス判定</span>
              <div className="flex items-center gap-1">
                {[1, 2, 3].map(i => {
                  const isStrike = p1.missStreak >= i;
                  return (
                    <span
                      key={i}
                      className={`w-3 h-3 rounded-full flex items-center justify-center text-[8px] font-black ${
                        isStrike
                          ? 'bg-red-500 text-white shadow-[0_0_6px_rgba(239,68,68,0.9)]'
                          : 'bg-stone-800 text-stone-600 border border-stone-700'
                      }`}
                    >
                      {isStrike ? '✕' : '•'}
                    </span>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Center: Match Turn Badge, VS Banner & System Action Buttons */}
          <div className="pointer-events-auto flex flex-col items-center gap-1.5 mx-1">
            {/* Round / Turn Badge */}
            <div className="flex items-center gap-1.5">
              <div className="px-2.5 py-1 rounded-xl bg-stone-900/95 border border-stone-800 text-amber-200 text-[11px] font-mono font-bold shadow-md flex items-center gap-1.5">
                <Swords size={12} className="text-amber-400" />
                <span>TURN</span>
                <span className="text-amber-400 text-xs font-black">{matchTurn}</span>
              </div>

              {/* Reset Match Button */}
              <button
                type="button"
                tabIndex={-1}
                onClick={e => {
                  e.currentTarget.blur();
                  sound.playClick();
                  onResetGame();
                }}
                onPointerDown={e => {
                  e.stopPropagation();
                  e.currentTarget.blur();
                }}
                className="p-1.5 rounded-xl bg-stone-900/90 hover:bg-stone-850 text-stone-400 hover:text-white border border-stone-800 shadow-md transition active:scale-95 cursor-pointer outline-none"
                title="対戦をリセット (最初からやり直し)"
              >
                <RotateCcw size={13} />
              </button>

              {/* History Button */}
              <button
                type="button"
                tabIndex={-1}
                onClick={e => {
                  e.currentTarget.blur();
                  sound.playClick();
                  setShowHistory(!showHistory);
                }}
                onPointerDown={e => {
                  e.stopPropagation();
                  e.currentTarget.blur();
                }}
                className="p-1.5 rounded-xl bg-stone-900/90 hover:bg-stone-850 text-stone-300 hover:text-white border border-stone-800 shadow-md transition active:scale-95 cursor-pointer relative outline-none"
                title="対戦の投擲履歴"
              >
                <History size={13} />
                {history.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 text-stone-950 font-black text-[8px] rounded-full flex items-center justify-center">
                    {history.length}
                  </span>
                )}
              </button>

              {/* Rules Button */}
              <button
                type="button"
                tabIndex={-1}
                onClick={e => {
                  e.currentTarget.blur();
                  sound.playClick();
                  onOpenRules();
                }}
                onPointerDown={e => {
                  e.stopPropagation();
                  e.currentTarget.blur();
                }}
                className="p-1.5 rounded-xl bg-stone-900/90 hover:bg-stone-850 text-stone-300 hover:text-white border border-stone-800 shadow-md transition active:scale-95 cursor-pointer outline-none"
                title="モルック対戦ルール説明"
              >
                <HelpCircle size={13} />
              </button>
            </div>

            {/* Active Turn Callout */}
            <div
              className={`px-3 py-1 rounded-full text-[11px] font-black tracking-wide border shadow-sm transition-all flex items-center gap-1.5 ${
                activePlayerId === 1
                  ? 'bg-cyan-950/80 border-cyan-500/70 text-cyan-300'
                  : 'bg-rose-950/80 border-rose-500/70 text-rose-300'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full animate-ping bg-current" />
              <span>{activePlayerId === 1 ? p1.name : p2.name} の投擲番</span>
            </div>
          </div>

          {/* Player 2 Card (Rose/Red Theme) */}
          <div
            className={`pointer-events-auto flex flex-col transition-all duration-300 rounded-2xl p-2 sm:p-2.5 backdrop-blur-md border ${
              activePlayerId === 2
                ? 'bg-rose-950/90 border-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.45)] scale-[1.02]'
                : 'bg-stone-950/80 border-stone-800/80 opacity-80'
            }`}
          >
            {/* Player Header */}
            <div className="flex items-center justify-between gap-2">
              {activePlayerId === 2 && (
                <span className="animate-pulse px-1.5 py-0.5 rounded-full bg-rose-400 text-stone-950 font-black text-[9px] uppercase tracking-wider flex items-center gap-0.5 shadow-sm">
                  <Zap size={9} className="fill-current" /> TURN
                </span>
              )}
              <div className="flex items-center gap-1.5 ml-auto">
                <span className="text-xs sm:text-sm font-black text-rose-100 max-w-[90px] sm:max-w-[120px] truncate">
                  {p2.name}
                </span>
                <span className="w-5 h-5 rounded-lg bg-rose-500 text-white font-black text-[11px] flex items-center justify-center shadow-sm">
                  2P
                </span>
              </div>
            </div>

            {/* Score & Progress */}
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-[10px] font-bold text-rose-200/90 mr-auto">
                {50 - p2.score === 0 ? '✨ GOAL!' : `あと ${Math.max(0, 50 - p2.score)}`}
              </span>
              <span className="text-2xl sm:text-3xl font-black tabular-nums tracking-tight text-rose-300">
                {p2.score}
              </span>
              <span className="text-stone-400 text-xs font-semibold">/ 50</span>
            </div>

            {/* Mini Progress Bar */}
            <div className="w-28 sm:w-36 h-1.5 bg-stone-850 rounded-full mt-1 overflow-hidden border border-stone-800 ml-auto">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  p2.score > 40
                    ? 'bg-gradient-to-r from-rose-400 to-yellow-300'
                    : 'bg-gradient-to-r from-rose-600 to-rose-400'
                }`}
                style={{ width: `${Math.min(100, (p2.score / 50) * 100)}%` }}
              />
            </div>

            {/* Miss Strikes */}
            <div className="flex items-center justify-between mt-1.5 pt-1 border-t border-rose-900/30">
              <div className="flex items-center gap-1">
                {[1, 2, 3].map(i => {
                  const isStrike = p2.missStreak >= i;
                  return (
                    <span
                      key={i}
                      className={`w-3 h-3 rounded-full flex items-center justify-center text-[8px] font-black ${
                        isStrike
                          ? 'bg-red-500 text-white shadow-[0_0_6px_rgba(239,68,68,0.9)]'
                          : 'bg-stone-800 text-stone-600 border border-stone-700'
                      }`}
                    >
                      {isStrike ? '✕' : '•'}
                    </span>
                  );
                })}
              </div>
              <span className="text-[9px] text-stone-400 font-semibold uppercase">ミス判定</span>
            </div>
          </div>
        </div>

        {/* Temporary Banner Message (Center Notification) */}
        {lastBanner && (
          <div className="pointer-events-auto self-center animate-fade-in transition-all max-w-[90vw]">
            <div
              className={`px-4 py-2 rounded-xl shadow-2xl border text-center font-bold text-xs sm:text-sm flex flex-col items-center gap-0.5 ${
                lastBanner.type === 'success'
                  ? 'bg-amber-950/95 border-amber-500/70 text-amber-200'
                  : lastBanner.type === 'bust'
                  ? 'bg-red-950/95 border-red-500/70 text-red-200'
                  : lastBanner.type === 'miss'
                  ? 'bg-stone-900/95 border-stone-600 text-stone-300'
                  : 'bg-stone-900/95 border-amber-600/30 text-amber-100'
              }`}
            >
              <span className="tracking-wide text-white drop-shadow-sm">{lastBanner.message}</span>
              {lastBanner.sub && (
                <span className="text-[11px] font-medium opacity-90">{lastBanner.sub}</span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Throw History Slide-over Drawer (2-Player Turn Log) */}
      {showHistory && (
        <div
          onPointerDown={e => e.stopPropagation()}
          className="absolute inset-y-0 right-0 w-84 max-w-[85vw] bg-stone-950/95 border-l border-stone-800 z-40 p-4 sm:p-5 flex flex-col shadow-2xl text-stone-200"
        >
          <div className="flex items-center justify-between pb-3 border-b border-stone-800">
            <div className="flex items-center gap-2">
              <History size={16} className="text-amber-400" />
              <h2 className="font-bold text-amber-100 text-sm">対戦の投擲履歴</h2>
            </div>
            <button
              type="button"
              tabIndex={-1}
              onClick={e => {
                e.currentTarget.blur();
                setShowHistory(false);
              }}
              onPointerDown={e => e.currentTarget.blur()}
              className="p-1 rounded-lg hover:bg-stone-800 text-stone-400 hover:text-white outline-none cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Player Filter Tabs */}
          <div className="flex items-center gap-1.5 my-3 bg-stone-900/80 p-1 rounded-xl border border-stone-800 text-xs">
            <button
              onClick={() => setFilterPlayer('all')}
              className={`flex-1 py-1 rounded-lg font-bold transition cursor-pointer ${
                filterPlayer === 'all' ? 'bg-amber-500 text-stone-950 shadow-sm' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              全ターン ({history.length})
            </button>
            <button
              onClick={() => setFilterPlayer(1)}
              className={`flex-1 py-1 rounded-lg font-bold transition cursor-pointer flex items-center justify-center gap-1 ${
                filterPlayer === 1 ? 'bg-cyan-500 text-stone-950 shadow-sm' : 'text-cyan-400 hover:text-cyan-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-cyan-400" /> 1P
            </button>
            <button
              onClick={() => setFilterPlayer(2)}
              className={`flex-1 py-1 rounded-lg font-bold transition cursor-pointer flex items-center justify-center gap-1 ${
                filterPlayer === 2 ? 'bg-rose-500 text-white shadow-sm' : 'text-rose-400 hover:text-rose-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-400" /> 2P
            </button>
          </div>

          {/* Record Items */}
          <div className="flex-1 overflow-y-auto my-1 space-y-2 pr-1">
            {filteredHistory.length === 0 ? (
              <div className="text-center text-xs text-stone-500 py-8">
                履歴はありません。
              </div>
            ) : (
              filteredHistory.map((rec, i) => {
                const isP1 = rec.playerId === 1;
                return (
                  <div
                    key={i}
                    className={`p-2.5 rounded-xl border text-xs flex flex-col gap-1 ${
                      rec.isBust
                        ? 'bg-red-950/40 border-red-800/60 text-red-200'
                        : rec.isMiss
                        ? 'bg-stone-900/60 border-stone-800 text-stone-400'
                        : isP1
                        ? 'bg-cyan-950/20 border-cyan-800/40 text-cyan-100'
                        : 'bg-rose-950/20 border-rose-800/40 text-rose-100'
                    }`}
                  >
                    <div className="flex items-center justify-between font-mono">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-black ${
                            isP1 ? 'bg-cyan-500 text-stone-950' : 'bg-rose-500 text-white'
                          }`}
                        >
                          {isP1 ? '1P' : '2P'}
                        </span>
                        <span className="font-bold text-stone-300">{rec.playerName}</span>
                        <span className="text-stone-500 text-[10px]">(T{rec.turnIndex})</span>
                      </div>
                      <span
                        className={`font-black text-sm tabular-nums ${
                          rec.roundScore > 0 ? (isP1 ? 'text-cyan-300' : 'text-rose-300') : 'text-stone-400'
                        }`}
                      >
                        +{rec.roundScore} 点
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span>
                        {rec.fallenCount === 1
                          ? `スキットル [${rec.fallenNumbers[0]}] 撃破`
                          : rec.fallenCount > 1
                          ? `${rec.fallenCount} 本倒した (${rec.fallenNumbers.join(', ')})`
                          : '全ミス (0点)'}
                      </span>
                      <span className="font-bold tabular-nums text-stone-300">
                        計 {rec.totalScoreAfter} 点
                      </span>
                    </div>

                    {rec.isBust && (
                      <div className="text-[10px] text-red-400 font-bold bg-red-900/30 px-2 py-0.5 rounded">
                        ⚠️ 50点超過ペナルティ → 25点へ減点
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Stats */}
          <div className="pt-3 border-t border-stone-800 text-xs text-stone-400 flex justify-between">
            <span>累計: {history.length}投</span>
            <div className="flex gap-2">
              <span className="text-cyan-400 font-bold">1P: {p1.score}点</span>
              <span className="text-stone-600">|</span>
              <span className="text-rose-400 font-bold">2P: {p2.score}点</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
