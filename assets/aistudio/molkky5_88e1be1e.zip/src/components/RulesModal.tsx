import React from 'react';
import { X, Trophy, AlertTriangle, Target, RefreshCw } from 'lucide-react';
import { sound } from '../audio/soundEffects';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm select-none animate-fade-in">
      <div className="bg-stone-900 border border-stone-700/80 rounded-3xl w-full max-w-xl max-h-[85vh] overflow-y-auto p-6 shadow-2xl text-stone-100 flex flex-col gap-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              🪵
            </div>
            <div>
              <h2 className="text-xl font-black text-amber-100">モルック（Mölkky）公式ルール</h2>
              <p className="text-xs text-stone-400">フィンランド伝統の木製アウトドアスポーツ</p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-xl hover:bg-stone-800 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content Sections */}
        <div className="space-y-4 text-xs sm:text-sm">
          {/* Rule 1: Goal */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex items-start gap-3">
            <Trophy className="text-amber-400 shrink-0 mt-0.5" size={20} />
            <div>
              <h3 className="font-bold text-amber-300 text-sm">1. ちょうど「50点」で勝利！</h3>
              <p className="text-stone-300 mt-1 leading-relaxed">
                投擲を繰り返し、累計得点が<strong className="text-amber-400 font-bold">ぴったり50点</strong>になった時点で勝利となります。
              </p>
            </div>
          </div>

          {/* Rule 2: Scoring */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex items-start gap-3">
            <Target className="text-emerald-400 shrink-0 mt-0.5" size={20} />
            <div className="flex-1">
              <h3 className="font-bold text-emerald-300 text-sm">2. 得点の計算ルール</h3>
              <ul className="mt-2 space-y-2 text-stone-300">
                <li className="bg-stone-900/80 p-2.5 rounded-xl border border-stone-800">
                  <div className="font-bold text-amber-300">🎯 1本だけ倒した場合</div>
                  <div className="text-xs text-stone-300 mt-0.5">
                    そのスキットルに書かれた<strong>数字そのものが得点</strong>になります。<br />
                    （例：【12】のピンを1本だけ倒すと、そのまま <strong className="text-amber-400">12点</strong> 獲得！）
                  </div>
                </li>

                <li className="bg-stone-900/80 p-2.5 rounded-xl border border-stone-800">
                  <div className="font-bold text-amber-300">🎳 2本以上倒した場合</div>
                  <div className="text-xs text-stone-300 mt-0.5">
                    数字に関係なく、倒れた<strong>「本数」が得点</strong>になります。<br />
                    （例：3本倒した場合は <strong className="text-amber-400">3点</strong> 獲得）
                  </div>
                </li>
              </ul>
            </div>
          </div>

          {/* Rule 3: 50 Bust Penalty */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex items-start gap-3">
            <AlertTriangle className="text-rose-400 shrink-0 mt-0.5" size={20} />
            <div>
              <h3 className="font-bold text-rose-300 text-sm">3. 50点オーバーで「25点」にペナルティ！</h3>
              <p className="text-stone-300 mt-1 leading-relaxed">
                もし合計得点が50点を超えてしまった場合（例：45点から8点獲得＝53点）、
                ペナルティとして<strong className="text-rose-400 font-bold">25点まで減点</strong>されてしまいます。
                終盤はどのピンを倒すか精密なコントロールが鍵です！
              </p>
            </div>
          </div>

          {/* Rule 4: 3 Consecutive Misses */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex items-start gap-3">
            <div className="text-red-400 font-black text-base shrink-0 mt-0.5">❌❌❌</div>
            <div>
              <h3 className="font-bold text-rose-300 text-sm">4. 3回連続ミスで即「失格」</h3>
              <p className="text-stone-300 mt-1 leading-relaxed">
                1本も倒せなかった投擲が<strong className="text-rose-400 font-bold">3回連続</strong>すると、失格（ゲームオーバー）になります。
                安全に手前のピンを狙うか、勝負に出るかの判断が重要です。
              </p>
            </div>
          </div>

          {/* Rule 5: Repositioning */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-stone-800/80 flex items-start gap-3">
            <RefreshCw className="text-cyan-400 shrink-0 mt-0.5" size={20} />
            <div>
              <h3 className="font-bold text-cyan-300 text-sm">5. 倒れたピンはその場で立て直す</h3>
              <p className="text-stone-300 mt-1 leading-relaxed">
                モルック最大の面白さはこれ！
                倒れたスキットルは、<strong>倒れて止まった位置でそのまま立ち上がり</strong>ます。
                ゲームが進むにつれてピンが散らばり、高得点ピンを単独で狙いやすくなります。
              </p>
            </div>
          </div>

          {/* Rule 6: 2-Player Match Dynamics */}
          <div className="bg-stone-950/60 p-4 rounded-2xl border border-amber-500/40 flex items-start gap-3">
            <div className="text-amber-400 font-black text-lg shrink-0 mt-0.5">⚔️</div>
            <div>
              <h3 className="font-bold text-amber-300 text-sm">6. 2人対戦バトルの駆け引き</h3>
              <p className="text-stone-300 mt-1 leading-relaxed">
                2人が<strong>1つのフィールドで交互にモルック棒を投げ合います</strong>。
                相手が動かしたピンの配置をそのまま利用して高得点を狙うか、相手が狙っているピンを弾き飛ばして邪魔するか、白熱の心理戦が楽しめます！
                先にぴったり50点に到達したプレイヤーが勝利です。
              </p>
            </div>
          </div>
        </div>

        {/* Footer Close Button */}
        <div className="pt-2">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-full py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-sm tracking-wide transition active:scale-95 cursor-pointer shadow-lg"
          >
            ルールを理解した！ ゲームに戻る
          </button>
        </div>
      </div>
    </div>
  );
};
