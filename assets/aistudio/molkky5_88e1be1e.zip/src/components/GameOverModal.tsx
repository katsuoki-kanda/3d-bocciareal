import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, RotateCcw, Home, Award, Swords, Skull } from 'lucide-react';
import { MatchWinnerInfo, PlayerId, PlayerState, ThrowRecord } from '../types/game';
import { sound } from '../audio/soundEffects';

interface GameOverModalProps {
  winnerInfo: MatchWinnerInfo | null;
  players: Record<PlayerId, PlayerState>;
  history: ThrowRecord[];
  onRestart: () => void;
  onBackToTitle: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  winnerInfo,
  players,
  history,
  onRestart,
  onBackToTitle,
}) => {
  const p1 = players[1];
  const p2 = players[2];

  const winner = winnerInfo ? players[winnerInfo.winnerId] : p1;
  const isP1Winner = winnerInfo?.winnerId === 1;

  useEffect(() => {
    sound.playVictoryFanfare();

    // Dual celebratory confetti bursts
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    const t1 = setTimeout(() => {
      confetti({
        particleCount: 60,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
      });
      confetti({
        particleCount: 60,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
      });
    }, 350);

    return () => clearTimeout(t1);
  }, []);

  // Compute stats per player
  const p1History = history.filter(h => h.playerId === 1);
  const p2History = history.filter(h => h.playerId === 2);

  const p1Best = p1History.reduce((max, h) => Math.max(max, h.roundScore), 0);
  const p2Best = p2History.reduce((max, h) => Math.max(max, h.roundScore), 0);

  const p1Busts = p1History.filter(h => h.isBust).length;
  const p2Busts = p2History.filter(h => h.isBust).length;

  const p1Misses = p1History.filter(h => h.isMiss).length;
  const p2Misses = p2History.filter(h => h.isMiss).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/85 backdrop-blur-sm select-none animate-fade-in">
      <div className="bg-stone-900 border border-stone-700 rounded-3xl w-full max-w-lg p-6 sm:p-7 shadow-2xl text-stone-100 flex flex-col items-center text-center gap-4">
        {/* Trophy / Victory Badge */}
        <div
          className={`w-20 h-20 rounded-3xl flex items-center justify-center shadow-xl ${
            isP1Winner
              ? 'bg-gradient-to-tr from-cyan-600 via-sky-400 to-cyan-300 text-stone-950 shadow-[0_8px_30px_rgba(6,182,212,0.5)]'
              : 'bg-gradient-to-tr from-rose-600 via-pink-400 to-rose-300 text-white shadow-[0_8px_30px_rgba(244,63,94,0.5)]'
          }`}
        >
          <Trophy size={42} />
        </div>

        {/* Winner Announcement Header */}
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold uppercase tracking-wider mb-1">
            <Swords size={13} />
            <span>2人対戦 決着！</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-amber-50">
            🏆 {winner.name} ({isP1Winner ? '1P' : '2P'}) の勝利！
          </h2>
          <p className="text-stone-300 text-xs sm:text-sm mt-1">
            {winnerInfo?.reason === 'fifty_points'
              ? '見事なコントロールでちょうど50点ジャストゴールを達成！'
              : `相手プレイヤーが3連続ミスで失格となったため勝利！`}
          </p>
        </div>

        {/* 2-Player Comparative Stats Table */}
        <div className="w-full bg-stone-950/70 border border-stone-800 rounded-2xl p-3 sm:p-4 text-xs">
          <div className="grid grid-cols-3 text-stone-400 font-bold uppercase pb-2 border-b border-stone-800 text-[11px]">
            <div className={`text-left ${isP1Winner ? 'text-cyan-400' : 'text-stone-400'}`}>
              1P: {p1.name} {isP1Winner && '👑'}
            </div>
            <div>項目</div>
            <div className={`text-right ${!isP1Winner ? 'text-rose-400' : 'text-stone-400'}`}>
              {!isP1Winner && '👑 '}2P: {p2.name}
            </div>
          </div>

          <div className="divide-y divide-stone-850">
            {/* Score */}
            <div className="grid grid-cols-3 py-2 items-center">
              <div className="text-left font-black text-lg text-cyan-300 tabular-nums">
                {p1.score} 点
              </div>
              <div className="text-stone-400 font-semibold">最終得点</div>
              <div className="text-right font-black text-lg text-rose-300 tabular-nums">
                {p2.score} 点
              </div>
            </div>

            {/* Throws */}
            <div className="grid grid-cols-3 py-2 items-center">
              <div className="text-left font-bold text-stone-200 tabular-nums">
                {p1History.length} 投
              </div>
              <div className="text-stone-400 font-semibold">投擲数</div>
              <div className="text-right font-bold text-stone-200 tabular-nums">
                {p2History.length} 投
              </div>
            </div>

            {/* Best Single Throw */}
            <div className="grid grid-cols-3 py-2 items-center">
              <div className="text-left font-bold text-emerald-400 tabular-nums">
                +{p1Best} 点
              </div>
              <div className="text-stone-400 font-semibold">最高一撃</div>
              <div className="text-right font-bold text-emerald-400 tabular-nums">
                +{p2Best} 点
              </div>
            </div>

            {/* Bust Penalties */}
            <div className="grid grid-cols-3 py-2 items-center">
              <div className="text-left font-bold text-rose-400 tabular-nums">
                {p1Busts} 回
              </div>
              <div className="text-stone-400 font-semibold">50点超過バースト</div>
              <div className="text-right font-bold text-rose-400 tabular-nums">
                {p2Busts} 回
              </div>
            </div>

            {/* Miss Strikes */}
            <div className="grid grid-cols-3 py-2 items-center">
              <div className="text-left font-bold text-stone-400 tabular-nums">
                {p1Misses} 回
              </div>
              <div className="text-stone-400 font-semibold">ミス投擲</div>
              <div className="text-right font-bold text-stone-400 tabular-nums">
                {p2Misses} 回
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col sm:flex-row gap-2.5 pt-1">
          <button
            onClick={() => {
              sound.playClick();
              onRestart();
            }}
            className="flex-1 py-3.5 px-5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-stone-950 font-black text-sm sm:text-base shadow-[0_6px_22px_rgba(245,158,11,0.4)] active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw size={18} />
            同じ相手ともう一度対戦！
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onBackToTitle();
            }}
            className="py-3 px-4 rounded-2xl bg-stone-800 hover:bg-stone-750 text-stone-300 hover:text-white font-bold text-xs sm:text-sm border border-stone-700 transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Home size={16} />
            タイトルへ戻る
          </button>
        </div>
      </div>
    </div>
  );
};
