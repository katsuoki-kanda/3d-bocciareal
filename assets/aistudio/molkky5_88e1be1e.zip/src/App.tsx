/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { MolkkyScene } from './game/MolkkyScene';
import {
  CameraViewMode,
  GameMode,
  GamePhase,
  MatchWinnerInfo,
  PlayerId,
  PlayerState,
  ThrowParams,
  ThrowRecord,
} from './types/game';
import { TitleScreen } from './components/TitleScreen';
import { HUD } from './components/HUD';
import { ControlDock } from './components/ControlDock';
import { RulesModal } from './components/RulesModal';
import { GameOverModal } from './components/GameOverModal';
import { sound } from './audio/soundEffects';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<MolkkyScene | null>(null);

  // Match & Players state
  const [gameMode, setGameMode] = useState<GameMode>('two_player');
  const [players, setPlayers] = useState<Record<PlayerId, PlayerState>>({
    1: {
      id: 1,
      name: 'プレイヤー1',
      score: 0,
      missStreak: 0,
      color: 'cyan',
      accentColor: '#06b6d4',
      stickColorHex: 0x06b6d4,
    },
    2: {
      id: 2,
      name: 'プレイヤー2',
      score: 0,
      missStreak: 0,
      color: 'rose',
      accentColor: '#f43f5e',
      stickColorHex: 0xf43f5e,
    },
  });
  const [activePlayerId, setActivePlayerId] = useState<PlayerId>(1);
  const [matchTurn, setMatchTurn] = useState<number>(1);
  const [history, setHistory] = useState<ThrowRecord[]>([]);
  const [winnerInfo, setWinnerInfo] = useState<MatchWinnerInfo | null>(null);

  // Game Phase
  const [phase, setPhase] = useState<GamePhase>('title');

  // Controls & View settings
  const [throwParams, setThrowParams] = useState<ThrowParams>({
    aimAngle: 0,
    pitchAngle: 22,
    power: 55,
    spin: 0,
  });
  const [cameraView, setCameraView] = useState<CameraViewMode>('thrower');
  const [showTrajectory, setShowTrajectory] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isControlsCollapsed, setIsControlsCollapsed] = useState<boolean>(false);

  // Throw Safety Cooldown: Prevents accidental Space/Enter throws immediately upon game start or turn change
  const [isThrowCooldown, setIsThrowCooldown] = useState<boolean>(false);
  const throwCooldownUntilRef = useRef<number>(0);

  // UI Modals & Banners
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [lastBanner, setLastBanner] = useState<{
    message: string;
    sub?: string;
    type: 'success' | 'bust' | 'miss' | 'info';
  } | null>(null);
  const [isWaitingNextTurn, setIsWaitingNextTurn] = useState<boolean>(false);

  // Mouse / Touch drag on canvas to aim
  const dragStartRef = useRef<{ x: number; y: number; aim: number; power: number } | null>(null);

  // Keep latest state in ref for callbacks
  const stateRef = useRef({
    players,
    activePlayerId,
    matchTurn,
    history,
    throwParams,
    phase,
    cameraView,
    isWaitingNextTurn,
    gameMode,
  });
  useEffect(() => {
    stateRef.current = {
      players,
      activePlayerId,
      matchTurn,
      history,
      throwParams,
      phase,
      cameraView,
      isWaitingNextTurn,
      gameMode,
    };
  }, [players, activePlayerId, matchTurn, history, throwParams, phase, cameraView, isWaitingNextTurn, gameMode]);

  // Activate throw safety cooldown whenever entering aiming mode
  const activateThrowCooldown = useCallback((durationMs: number = 750) => {
    throwCooldownUntilRef.current = Date.now() + durationMs;
    setIsThrowCooldown(true);
    setTimeout(() => {
      setIsThrowCooldown(false);
    }, durationMs);
  }, []);

  // Initialize Three.js scene once
  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new MolkkyScene(mountRef.current);
    sceneRef.current = scene;

    scene.updateTrajectory(throwParams, showTrajectory);
    scene.setStickPlayerColor(players[1].stickColorHex);

    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
  }, []);

  // Sync trajectory line when parameters change
  useEffect(() => {
    if (sceneRef.current) {
      sceneRef.current.updateTrajectory(throwParams, showTrajectory && phase === 'aiming');
    }
  }, [throwParams, showTrajectory, phase]);

  // Handle camera view change
  const handleChangeCameraView = useCallback((mode: CameraViewMode) => {
    setCameraView(mode);
    if (sceneRef.current) {
      sceneRef.current.setCameraView(mode);
    }
  }, []);

  // Cycle camera view sequentially with / key
  const handleCycleCameraView = useCallback(() => {
    const cur = stateRef.current.cameraView;
    const views: CameraViewMode[] = ['thrower', 'overhead', 'side', 'target'];
    const curIdx = views.indexOf(cur);
    const nextIdx = (curIdx + 1) % views.length;
    const nextMode = views[nextIdx];
    handleChangeCameraView(nextMode);
  }, [handleChangeCameraView]);

  // Sound toggle
  const handleToggleSound = useCallback(() => {
    setSoundEnabled(prev => {
      const next = !prev;
      sound.enabled = next;
      return next;
    });
  }, []);

  // Trajectory toggle
  const handleToggleTrajectory = useCallback(() => {
    setShowTrajectory(prev => !prev);
  }, []);

  // Reset pins to starting cluster (practice/reset feature)
  const handleResetPins = useCallback(() => {
    if (sceneRef.current) {
      sceneRef.current.physics.resetToStartingCluster();
      setLastBanner({
        message: 'スキットルを初期密集配置にリセットしました',
        type: 'info',
      });
      setTimeout(() => setLastBanner(null), 2500);
      activateThrowCooldown(600);
    }
  }, [activateThrowCooldown]);

  // Handle Round Settlement when all objects stop moving
  const handleRoundSettled = useCallback((fallenPins: number[]) => {
    const { players: curPlayers, activePlayerId: curActiveId, matchTurn: curTurn, gameMode: curMode } = stateRef.current;
    const activeP = curPlayers[curActiveId];
    const fallenCount = fallenPins.length;

    let roundScore = 0;
    let isBust = false;
    let isMiss = false;
    let nextScore = activeP.score;
    let nextMissStreak = activeP.missStreak;

    const opponentId: PlayerId = curActiveId === 1 ? 2 : 1;
    const opponentP = curPlayers[opponentId];

    if (fallenCount === 0) {
      isMiss = true;
      nextMissStreak = activeP.missStreak + 1;
      sound.playMissSound();

      if (nextMissStreak >= 3) {
        // Disqualification rule!
        const updatedPlayers = {
          ...curPlayers,
          [curActiveId]: { ...activeP, missStreak: 3 },
        };
        setPlayers(updatedPlayers);

        if (curMode === 'two_player') {
          // Opponent wins!
          setWinnerInfo({
            winnerId: opponentId,
            winnerName: opponentP.name,
            loserId: curActiveId,
            loserName: activeP.name,
            reason: 'opponent_disqualified',
          });
          setPhase('victory');
        } else {
          setPhase('gameover');
        }
        return;
      } else {
        setLastBanner({
          message: `❌ 全ミス！ 0本倒れ [${activeP.name}] (ストライク ${nextMissStreak}/3)`,
          sub: '3回連続ミスで失格になります',
          type: 'miss',
        });
      }
    } else if (fallenCount === 1) {
      const pinNum = fallenPins[0];
      roundScore = pinNum;
      nextMissStreak = 0;
      const testScore = activeP.score + roundScore;

      if (testScore === 50) {
        nextScore = 50;
        const updatedPlayers = {
          ...curPlayers,
          [curActiveId]: { ...activeP, score: 50, missStreak: 0 },
        };
        setPlayers(updatedPlayers);
        setWinnerInfo({
          winnerId: curActiveId,
          winnerName: activeP.name,
          loserId: opponentId,
          loserName: opponentP.name,
          reason: 'fifty_points',
        });
        setPhase('victory');
        return;
      } else if (testScore > 50) {
        isBust = true;
        nextScore = 25;
        sound.playBustSound();
        setLastBanner({
          message: `💥 50点オーバー！ [${activeP.name}: ${testScore}点]`,
          sub: '公式ルールにより25点に減点ペナルティ！',
          type: 'bust',
        });
      } else {
        nextScore = testScore;
        sound.playScoreChime(roundScore);
        setLastBanner({
          message: `🎯 【${pinNum}】を1本撃破！ [${activeP.name}] +${roundScore}点`,
          sub: `合計: ${nextScore}点 (あと ${50 - nextScore}点)`,
          type: 'success',
        });
      }
    } else {
      roundScore = fallenCount;
      nextMissStreak = 0;
      const testScore = activeP.score + roundScore;

      if (testScore === 50) {
        nextScore = 50;
        const updatedPlayers = {
          ...curPlayers,
          [curActiveId]: { ...activeP, score: 50, missStreak: 0 },
        };
        setPlayers(updatedPlayers);
        setWinnerInfo({
          winnerId: curActiveId,
          winnerName: activeP.name,
          loserId: opponentId,
          loserName: opponentP.name,
          reason: 'fifty_points',
        });
        setPhase('victory');
        return;
      } else if (testScore > 50) {
        isBust = true;
        nextScore = 25;
        sound.playBustSound();
        setLastBanner({
          message: `💥 50点オーバー！ [${activeP.name}: ${testScore}点]`,
          sub: '公式ルールにより25点に減点ペナルティ！',
          type: 'bust',
        });
      } else {
        nextScore = testScore;
        sound.playScoreChime(roundScore);
        setLastBanner({
          message: `🎳 ${fallenCount}本倒した！ [${activeP.name}] +${roundScore}点`,
          sub: `倒れたピン: [${fallenPins.sort((a, b) => a - b).join(', ')}] 計 ${nextScore}点`,
          type: 'success',
        });
      }
    }

    // Save throw record
    const record: ThrowRecord = {
      turnIndex: curTurn,
      round: Math.ceil(curTurn / (curMode === 'two_player' ? 2 : 1)),
      playerId: curActiveId,
      playerName: activeP.name,
      fallenCount,
      fallenNumbers: [...fallenPins],
      roundScore,
      totalScoreBefore: activeP.score,
      totalScoreAfter: nextScore,
      isBust,
      isMiss,
    };

    setHistory(prev => [record, ...prev]);

    // Update active player's score & strikes
    setPlayers(prev => ({
      ...prev,
      [curActiveId]: {
        ...prev[curActiveId],
        score: nextScore,
        missStreak: nextMissStreak,
      },
    }));

    setIsWaitingNextTurn(true);
  }, []);

  // Prepare next throw: stand pins up at their current landing spots, switch player, reset stick
  const handleNextTurnReady = useCallback(() => {
    if (!sceneRef.current) return;
    setIsWaitingNextTurn(false);
    setLastBanner(null);

    // 1. Stand pins up where they landed (Authentic Molkky rules: shared field!)
    sceneRef.current.physics.standPinsBackUpAtCurrentPositions();
    sceneRef.current.physics.resetStickPosition();
    sceneRef.current.setCameraView('thrower');
    setCameraView('thrower');

    const { gameMode: curMode, activePlayerId: curActiveId, players: curPlayers } = stateRef.current;

    // 2. Switch player in 2-player mode
    const nextPlayerId: PlayerId = curMode === 'two_player' ? (curActiveId === 1 ? 2 : 1) : 1;
    const nextP = curPlayers[nextPlayerId];

    setActivePlayerId(nextPlayerId);
    setMatchTurn(t => t + 1);

    // 3. Update stick accent ring color to next player's theme
    sceneRef.current.setStickPlayerColor(nextP.stickColorHex);

    // 4. Play cheerful player transition sound
    sound.playTurnSwitch();

    // 5. Brief banner announcing turn switch
    setLastBanner({
      message: `🔔 ${nextP.name} (${nextPlayerId === 1 ? '1P' : '2P'}) の番です`,
      sub: `現在: ${nextP.score}点 (あと ${Math.max(0, 50 - nextP.score)}点)`,
      type: 'info',
    });
    setTimeout(() => {
      setLastBanner(prev => (prev?.type === 'info' ? null : prev));
    }, 2800);

    setPhase('aiming');
    activateThrowCooldown(750);
  }, [activateThrowCooldown]);

  // Throw action: Protected against premature or accidental triggers
  const handleThrow = useCallback(() => {
    if (phase !== 'aiming' || isWaitingNextTurn || !sceneRef.current) return;

    if (Date.now() < throwCooldownUntilRef.current) {
      return;
    }

    setPhase('throwing');
    setIsWaitingNextTurn(false);
    setLastBanner(null);

    sceneRef.current.setCameraView('follow');
    setCameraView('follow');

    sceneRef.current.physics.throwStick(
      throwParams.aimAngle,
      throwParams.pitchAngle,
      throwParams.power,
      throwParams.spin,
      fallenPins => {
        handleRoundSettled(fallenPins);
      }
    );
  }, [phase, isWaitingNextTurn, throwParams, handleRoundSettled]);

  // Restart match with same players
  const handleRestartGame = useCallback(() => {
    setPlayers(prev => ({
      1: { ...prev[1], score: 0, missStreak: 0 },
      2: { ...prev[2], score: 0, missStreak: 0 },
    }));
    setActivePlayerId(1);
    setMatchTurn(1);
    setHistory([]);
    setWinnerInfo(null);
    setIsWaitingNextTurn(false);
    setLastBanner({
      message: '対戦を初期状態にリセットしました (先攻: 1P)',
      type: 'info',
    });
    setTimeout(() => setLastBanner(null), 2500);
    setPhase('aiming');

    if (sceneRef.current) {
      sceneRef.current.physics.resetToStartingCluster();
      sceneRef.current.physics.resetStickPosition();
      sceneRef.current.setStickPlayerColor(players[1].stickColorHex);
      sceneRef.current.setCameraView('thrower');
      setCameraView('thrower');
    }
    activateThrowCooldown(800);
  }, [activateThrowCooldown, players]);

  // Start game from title with selected mode and custom names
  const handleStartGame = useCallback(
    (mode: GameMode, p1Name: string, p2Name: string) => {
      setGameMode(mode);
      setPlayers(prev => ({
        1: { ...prev[1], name: p1Name || 'プレイヤー1', score: 0, missStreak: 0 },
        2: { ...prev[2], name: p2Name || 'プレイヤー2', score: 0, missStreak: 0 },
      }));
      setActivePlayerId(1);
      setMatchTurn(1);
      setHistory([]);
      setWinnerInfo(null);
      setIsWaitingNextTurn(false);
      setLastBanner({
        message: `対戦開始！ 先攻: ${p1Name || 'プレイヤー1'} の投擲`,
        sub: 'ちょうど50点を目指して交互に投げ合おう！',
        type: 'info',
      });
      setTimeout(() => setLastBanner(null), 3000);

      setPhase('aiming');
      if (sceneRef.current) {
        sceneRef.current.physics.resetToStartingCluster();
        sceneRef.current.physics.resetStickPosition();
        sceneRef.current.setStickPlayerColor(players[1].stickColorHex);
        sceneRef.current.setCameraView('thrower');
        setCameraView('thrower');
      }
      activateThrowCooldown(800);
    },
    [activateThrowCooldown, players]
  );

  // Return to Title Screen (for changing player names or mode)
  const handleBackToTitle = useCallback(() => {
    setPhase('title');
    setWinnerInfo(null);
    setIsWaitingNextTurn(false);
    setLastBanner(null);
    if (sceneRef.current) {
      sceneRef.current.physics.resetToStartingCluster();
      sceneRef.current.physics.resetStickPosition();
      sceneRef.current.setCameraView('thrower');
      setCameraView('thrower');
    }
  }, []);

  // High-priority global keyboard event listener with CAPTURE phase:
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;

      // 1. '*' key ALWAYS toggles control dock collapse
      const isAsterisk =
        e.key === '*' ||
        e.code === 'NumpadMultiply' ||
        e.keyCode === 106 ||
        (e.shiftKey && (e.code === 'Digit8' || e.key === '*'));
      if (isAsterisk) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        sound.playClick();
        setIsControlsCollapsed(prev => !prev);
        return;
      }

      // 2. '/' key ALWAYS cycles camera views
      const isSlash =
        e.key === '/' ||
        e.code === 'Slash' ||
        e.code === 'NumpadDivide' ||
        e.keyCode === 191 ||
        e.keyCode === 111;
      if (isSlash) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();
        sound.playClick();
        handleCycleCameraView();
        return;
      }

      // 3. Arrow keys: Adjust Aim and Power without being trapped by inputs
      // (Only when not typing inside an input element)
      const isInputActive =
        document.activeElement instanceof HTMLInputElement ||
        document.activeElement instanceof HTMLTextAreaElement;

      if (!isInputActive) {
        if (e.code === 'ArrowLeft' || e.keyCode === 37) {
          e.preventDefault();
          e.stopPropagation();
          setThrowParams(prev => ({
            ...prev,
            aimAngle: Math.max(-25, Number((prev.aimAngle - 1).toFixed(1))),
          }));
          return;
        }
        if (e.code === 'ArrowRight' || e.keyCode === 39) {
          e.preventDefault();
          e.stopPropagation();
          setThrowParams(prev => ({
            ...prev,
            aimAngle: Math.min(25, Number((prev.aimAngle + 1).toFixed(1))),
          }));
          return;
        }
        if (e.code === 'ArrowUp' || e.keyCode === 38) {
          e.preventDefault();
          e.stopPropagation();
          setThrowParams(prev => ({
            ...prev,
            power: Math.min(100, prev.power + 3),
          }));
          return;
        }
        if (e.code === 'ArrowDown' || e.keyCode === 40) {
          e.preventDefault();
          e.stopPropagation();
          setThrowParams(prev => ({
            ...prev,
            power: Math.max(30, prev.power - 3),
          }));
          return;
        }

        // 4. '+' / '-' keys: Pitch (山なり / 低空)
        const isPlus =
          e.key === '+' ||
          e.key === ';' ||
          e.code === 'Equal' ||
          e.code === 'NumpadAdd' ||
          e.keyCode === 187 ||
          e.keyCode === 107;
        const isMinus =
          e.key === '-' ||
          e.code === 'Minus' ||
          e.code === 'NumpadSubtract' ||
          e.keyCode === 189 ||
          e.keyCode === 109;

        if (isPlus) {
          e.preventDefault();
          e.stopPropagation();
          setThrowParams(prev => ({
            ...prev,
            pitchAngle: Math.min(35, prev.pitchAngle + 1),
          }));
          return;
        }
        if (isMinus) {
          e.preventDefault();
          e.stopPropagation();
          setThrowParams(prev => ({
            ...prev,
            pitchAngle: Math.max(10, prev.pitchAngle - 1),
          }));
          return;
        }
      }

      // 5. Space / Enter logic:
      const isSpace = e.code === 'Space' || e.key === ' ' || e.keyCode === 32;
      const isEnter = e.code === 'Enter' || e.key === 'Enter' || e.keyCode === 13;

      if ((isSpace || isEnter) && !isInputActive) {
        e.preventDefault();
        e.stopPropagation();
        (document.activeElement as HTMLElement)?.blur();

        if (isEnter && phase === 'title') {
          handleStartGame('two_player', players[1].name, players[2].name);
          return;
        }

        if (isWaitingNextTurn) {
          handleNextTurnReady();
          return;
        }

        if (phase === 'aiming' && !isWaitingNextTurn) {
          if (Date.now() >= throwCooldownUntilRef.current) {
            handleThrow();
          }
          return;
        }
      }

      // Direct Camera Numbers
      if (!isInputActive) {
        if (e.code === 'Digit1') {
          handleChangeCameraView('thrower');
        } else if (e.code === 'Digit2') {
          handleChangeCameraView('overhead');
        } else if (e.code === 'Digit3') {
          handleChangeCameraView('side');
        } else if (e.code === 'Digit4') {
          handleChangeCameraView('target');
        } else if (e.code === 'KeyR' && e.shiftKey) {
          handleRestartGame();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown, { capture: true });
    return () => window.removeEventListener('keydown', handleKeyDown, { capture: true });
  }, [
    phase,
    isWaitingNextTurn,
    handleStartGame,
    handleNextTurnReady,
    handleThrow,
    handleChangeCameraView,
    handleCycleCameraView,
    handleRestartGame,
    players,
  ]);

  // Mouse & Touch Drag on Canvas ONLY
  const handleCanvasPointerDown = (e: React.PointerEvent) => {
    if (phase !== 'aiming' || isWaitingNextTurn) return;
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      aim: throwParams.aimAngle,
      power: throwParams.power,
    };
  };

  const handleCanvasPointerMove = (e: React.PointerEvent) => {
    if (!dragStartRef.current || phase !== 'aiming' || isWaitingNextTurn) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;

    const deltaAim = (dx / window.innerWidth) * 45;
    const newAim = Math.max(-25, Math.min(25, Number((dragStartRef.current.aim + deltaAim).toFixed(1))));

    const deltaPower = (-dy / window.innerHeight) * 75;
    const newPower = Math.max(30, Math.min(100, Math.round(dragStartRef.current.power + deltaPower)));

    setThrowParams(prev => ({
      ...prev,
      aimAngle: newAim,
      power: newPower,
    }));
  };

  const handleCanvasPointerUp = () => {
    dragStartRef.current = null;
  };

  const activePlayer = players[activePlayerId];
  const nextPlayerId: PlayerId = gameMode === 'two_player' ? (activePlayerId === 1 ? 2 : 1) : 1;
  const nextPlayer = players[nextPlayerId];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-stone-950 font-sans select-none">
      {/* 1. Dedicated WebGL Canvas Container with isolated pointer drag handlers */}
      <div
        ref={mountRef}
        className="absolute inset-0 z-0 touch-none cursor-grab active:cursor-grabbing"
        onPointerDown={handleCanvasPointerDown}
        onPointerMove={handleCanvasPointerMove}
        onPointerUp={handleCanvasPointerUp}
        onPointerCancel={handleCanvasPointerUp}
      />

      {/* 2. Title Screen Overlay */}
      {phase === 'title' && (
        <TitleScreen
          onStartMatch={handleStartGame}
          onOpenRules={() => setIsRulesOpen(true)}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          defaultP1Name={players[1].name}
          defaultP2Name={players[2].name}
        />
      )}

      {/* 3. In-Game 2-Player HUD */}
      {phase !== 'title' && (
        <HUD
          players={players}
          activePlayerId={activePlayerId}
          matchTurn={matchTurn}
          history={history}
          lastBanner={lastBanner}
          onResetGame={handleRestartGame}
          onOpenRules={() => setIsRulesOpen(true)}
        />
      )}

      {/* 4. Unified Ergonomic Bottom Control Dock */}
      {phase !== 'title' && phase !== 'victory' && phase !== 'gameover' && (
        <ControlDock
          throwParams={throwParams}
          onChangeParams={setThrowParams}
          onThrow={handleThrow}
          canThrow={phase === 'aiming' && !isWaitingNextTurn && !isThrowCooldown}
          isSettling={phase === 'throwing'}
          cameraView={cameraView}
          onChangeCameraView={handleChangeCameraView}
          showTrajectory={showTrajectory}
          onToggleTrajectory={handleToggleTrajectory}
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          onResetPinsToStarting={handleResetPins}
          isWaitingNextTurn={isWaitingNextTurn}
          onNextTurnReady={handleNextTurnReady}
          isCollapsed={isControlsCollapsed}
          onToggleCollapsed={() => setIsControlsCollapsed(c => !c)}
          isThrowCooldown={isThrowCooldown}
          activePlayer={activePlayer}
          nextPlayer={nextPlayer}
        />
      )}

      {/* 5. Rules Modal */}
      <RulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />

      {/* 6. Victory / Game Over Modal */}
      {(phase === 'victory' || phase === 'gameover') && (
        <GameOverModal
          winnerInfo={winnerInfo}
          players={players}
          history={history}
          onRestart={handleRestartGame}
          onBackToTitle={handleBackToTitle}
        />
      )}
    </div>
  );
}
